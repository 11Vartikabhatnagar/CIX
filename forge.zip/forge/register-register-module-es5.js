(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["register-register-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/register/home/home.component.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/register/home/home.component.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRegisterHomeHomeComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"container-fluid pattern-bg\">\r\n    <div class=\"row g-mt-50 g-mb-50 g-pt-10 g-pb-50\">\r\n        <div class=\"col-sm-1\"></div>\r\n        <div class=\"col-sm-10\">\r\n            <div class=\"g-pt-40 g-pb-30\">\r\n                <div class=\"primary-green-clr g-fs-20 g-fw-500 text-center\">\r\n                    Welcome to Ci<sup class=\"g-fs-10\">X</sup>\r\n                </div>\r\n            </div>\r\n            <div class=\"row \">\r\n                <div class=\"col-sm-3\"></div>\r\n                <div class=\"col-sm-3\">\r\n                    <div class=\"card g-w-bg g-bdrrad-6px g-bdr-01 g-black13-brdr signup-card\">\r\n                        <div class=\"card-body\">\r\n                            <div class=\"img-wrapper text-center g-pt-25\">\r\n                                <img src=\"/assets/img/seekers.png\" alt=\"Icon\" class=\"\">\r\n                            </div>\r\n                            <div class=\"g-mt-06\">\r\n                                <div class=\"text-center g-p-clr g-fs-12 g-fw-500\">City Administrators</div>\r\n                            </div>\r\n                            <div class=\"g-pl-15 g-pr-15 g-mt-05 user-role-desp g-fw-500\">\r\n                                <div class=\"g-fs-08 g-black11-clr\"><i class=\"far fa-check-circle\"\r\n                                        aria-hidden=\"true\"></i>&nbsp; Administrators\r\n                                </div>\r\n                                <div class=\"g-fs-08 g-black11-clr\"><i class=\"far fa-check-circle\"\r\n                                        aria-hidden=\"true\"></i>&nbsp; Urban Local Bodies\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"g-pl-05 g-pr-05 g-mt-10 g-pb-03\">\r\n                                <a class=\"btn g-blue6-bg g-p-clr g-fw-500 g-fs-09 g-w-100per signup-btn\"\r\n                                    href=\"seeker-signup.html\" [routerLink]=\"[ '/register/seeker']\">Sign Up</a>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-sm-3\">\r\n                    <div class=\"card g-w-bg g-bdrrad-6px g-bdr-01 g-black13-brdr signup-card\">\r\n                        <div class=\"card-body\">\r\n                            <div class=\"img-wrapper text-center g-pt-25\">\r\n                                <img src=\"/assets/img/providers.png\" alt=\"Icon\" class=\"\">\r\n                            </div>\r\n                            <div class=\"g-mt-06\">\r\n                                <div class=\"text-center g-p-clr g-fs-12 g-fw-500\">Innovators</div>\r\n                            </div>\r\n                            <div class=\"g-pl-15 g-pr-15 g-mt-05 user-role-desp g-fw-500\">\r\n                                <div class=\"g-fs-08 g-black11-clr\"><i class=\"far fa-check-circle\"\r\n                                        aria-hidden=\"true\"></i>&nbsp; Startups</div>\r\n                                <div class=\"g-fs-08 g-black11-clr\"><i class=\"far fa-check-circle\"\r\n                                        aria-hidden=\"true\"></i>&nbsp; Corporates</div>\r\n                                <div class=\"g-fs-08 g-black11-clr\"><i class=\"far fa-check-circle\"\r\n                                        aria-hidden=\"true\"></i>&nbsp; MSMEs</div>\r\n                                <div class=\"g-fs-08 g-black11-clr\"><i class=\"far fa-check-circle\"\r\n                                        aria-hidden=\"true\"></i>&nbsp; Individual Innovators\r\n                                        <div class=\"g-fs-06\">\r\n                                            Innovators, Professionals, Researchers, Academicians\r\n                                        </div>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"g-pl-05 g-pr-05 g-mt-10 g-pb-03\">\r\n                                <a class=\"btn g-blue6-bg g-p-clr g-fw-500 g-fs-09 g-w-100per signup-btn\"\r\n                                    [routerLink]=\"[ '/register/provider']\">Sign Up</a>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-sm-3\"></div>\r\n            </div>\r\n        </div>\r\n        <div class=\"col-sm-1\"></div>\r\n    </div>\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html":
  /*!****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html ***!
    \****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRegisterRegisterComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<router-outlet></router-outlet>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/register/seekers/seekers.component.html":
  /*!***********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/register/seekers/seekers.component.html ***!
    \***********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRegisterSeekersSeekersComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"container-fluid g-pb-50 g-pt-40 g-mb-10 g-mt-10\">\r\n  <div class=\"row\">\r\n    <div class=\"col-sm-1\"></div>\r\n    <div class=\"col-sm-10\">\r\n      <div class=\"row\">\r\n        <div class=\"col-sm-3\"></div>\r\n        <div class=\"col-md-6 col-sm-12\">\r\n          <div>\r\n            <ul class=\"a-step-form-active-list text-center g-p-0\">\r\n              <li\r\n                class=\"g-w-24 g-h-05 g-bdrrad-10px g-ml-03 g-mr-03\"\r\n                [ngClass]=\"{\r\n                  'g-p-bg': !seeker_stp_1,\r\n                  'primary-grey-bg': seeker_stp_1\r\n                }\"\r\n              ></li>\r\n              <li\r\n                class=\"g-w-24 g-h-05 g-bdrrad-10px g-ml-03 g-mr-03\"\r\n                [ngClass]=\"{\r\n                  'g-p-bg': !seeker_stp_2,\r\n                  'primary-grey-bg': seeker_stp_2\r\n                }\"\r\n              ></li>\r\n              <li\r\n                class=\"g-w-24 g-h-05 g-bdrrad-10px g-ml-03 g-mr-03\"\r\n                [ngClass]=\"{\r\n                  'g-p-bg': !seeker_stp_3,\r\n                  'primary-grey-bg': seeker_stp_3\r\n                }\"\r\n              ></li>\r\n              <li\r\n                class=\"g-w-24 g-h-05 g-bdrrad-10px g-ml-03 g-mr-03\"\r\n                [ngClass]=\"{\r\n                  'g-p-bg': !seeker_stp_4,\r\n                  'primary-grey-bg': seeker_stp_4\r\n                }\"\r\n              ></li>\r\n            </ul>\r\n          </div>\r\n          <div class=\"g-mt-35\">\r\n            <div class=\"card g-w-bg card-wrp\" [hidden]=\"seeker_stp_1\">\r\n              <div class=\"card-body\">\r\n                <!-- step 1 -->\r\n                <form\r\n                  [formGroup]=\"seekerForm.Step1\"\r\n                  (ngSubmit)=\"onSubmit('Step1')\"\r\n                >\r\n                  <div class=\"form-wrapper g-pl-20 g-pr-20\">\r\n                    <div class=\"g-pt-30\">\r\n                      <div class=\"g-fs-18 g-fw-500 title-clr\">\r\n                        Seeker Sign Up\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"row g-mt-10\">\r\n                      <div class=\"col-sm-8 col-xs-12\">\r\n                        <div class=\"form-group g-mt-03\">\r\n                          <label class=\"g-fs-07 g-black14-clr g-fw-500\"\r\n                            >Full Name *</label\r\n                          >\r\n                          <input\r\n                            type=\"text\"\r\n                            class=\"form-control\"\r\n                            formControlName=\"fullname\"\r\n                            [ngClass]=\"{\r\n                              error:\r\n                                (formControlStep1.fullname.touched ||\r\n                                  isSubmitted.Step1) &&\r\n                                formControlStep1.fullname?.errors\r\n                            }\"\r\n                            placeholder=\"ex: John Doe\"\r\n                          />\r\n                          <div class=\"err-resp\">\r\n                            <span\r\n                              class=\"field-err\"\r\n                              *ngIf=\"\r\n                                (formControlStep1.fullname.touched ||\r\n                                  isSubmitted.Step1) &&\r\n                                formControlStep1.fullname.errors?.required\r\n                              \"\r\n                            >\r\n                              Full Name is required\r\n                            </span>\r\n                            <span\r\n                              class=\"field-err\"\r\n                              *ngIf=\"\r\n                                formControlStep1.fullname.touched &&\r\n                                formControlStep1.fullname.errors?.pattern\r\n                              \"\r\n                            >\r\n                              Enter a valid name\r\n                            </span>\r\n                          </div>\r\n                        </div>\r\n                      </div>\r\n                      <div class=\"col-sm-4 text-center hidden-xs\">\r\n                        <div class=\"avatar-upload\">\r\n                          <img\r\n                            [src]=\"avatar_preview\"\r\n                            alt=\"avatar\"\r\n                            class=\"g-w-100per g-bdrrad-50per\"\r\n                          />\r\n                          <div class=\"avatar-upload-mdl-tgr\">\r\n                            <div\r\n                              class=\"add-avatar\"\r\n                              data-toggle=\"modal\"\r\n                              data-target=\"#imageModal\"\r\n                            >\r\n                              <i class=\"fa fa-plus\" aria-hidden=\"true\"></i>\r\n                            </div>\r\n                          </div>\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"form-group g-mt-03\">\r\n                      <label for=\"email\" class=\"g-fs-07 g-black14-clr g-fw-500\"\r\n                        >Email *</label\r\n                      >\r\n                      <input\r\n                        type=\"email\"\r\n                        class=\"form-control\"\r\n                        formControlName=\"email\"\r\n                        [ngClass]=\"{\r\n                          error:\r\n                            (formControlStep1.email.touched ||\r\n                              isSubmitted.Step1) &&\r\n                            formControlStep1.email?.errors\r\n                        }\"\r\n                        placeholder=\"ex: yourmail@domain.com\"\r\n                      />\r\n                      <div class=\"err-resp\">\r\n                        <span\r\n                          class=\"field-err\"\r\n                          *ngIf=\"\r\n                            (formControlStep1.email.touched ||\r\n                              isSubmitted.Step1) &&\r\n                            formControlStep1.email.errors?.required\r\n                          \"\r\n                        >\r\n                          Email is required\r\n                        </span>\r\n                        <span\r\n                          class=\"field-err\"\r\n                          *ngIf=\"\r\n                            (formControlStep1.email.touched &&\r\n                              formControlStep1.email.errors?.email) ||\r\n                            formControlStep1.email.errors?.pattern\r\n                          \"\r\n                        >\r\n                          Enter a valid email address\r\n                        </span>\r\n                        <span\r\n                          class=\"field-err\"\r\n                          *ngIf=\"\r\n                            formControlStep1.email.touched &&\r\n                            formControlStep1.email.errors?.emailAlreadyExist\r\n                          \"\r\n                        >\r\n                          Email already exist\r\n                        </span>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"form-group g-mt-03\">\r\n                      <label for=\"number\" class=\"g-fs-07 g-black14-clr g-fw-500\"\r\n                        >Phone *</label\r\n                      >\r\n                      <div class=\"row\">\r\n                        <div class=\"col-sm-2 col-xs-4\">\r\n                          <input\r\n                            type=\"text\"\r\n                            class=\"form-control phone-code\"\r\n                            required\r\n                            value=\"+91\"\r\n                            disabled\r\n                          />\r\n                        </div>\r\n                        <div class=\"col-sm-10 col-xs-8\">\r\n                          <input\r\n                            type=\"text\"\r\n                            class=\"form-control\"\r\n                            formControlName=\"phnum\"\r\n                            [ngClass]=\"{\r\n                              error:\r\n                                (formControlStep1.phnum.touched ||\r\n                                  isSubmitted.Step1) &&\r\n                                formControlStep1.phnum?.errors\r\n                            }\"\r\n                            placeholder=\"ex: 9255333586\"\r\n                          />\r\n                          <div class=\"err-resp\">\r\n                            <span\r\n                              class=\"field-err\"\r\n                              *ngIf=\"\r\n                                (formControlStep1.phnum.touched ||\r\n                                  isSubmitted.Step1) &&\r\n                                formControlStep1.phnum.errors?.required\r\n                              \"\r\n                            >\r\n                              Phone number is required\r\n                            </span>\r\n                            <span\r\n                              class=\"field-err\"\r\n                              *ngIf=\"\r\n                                formControlStep1.phnum.touched &&\r\n                                formControlStep1.phnum.errors?.pattern\r\n                              \"\r\n                            >\r\n                              Enter a valid phone number\r\n                            </span>\r\n                            <span\r\n                              class=\"field-err\"\r\n                              *ngIf=\"\r\n                                formControlStep1.phnum.touched &&\r\n                                formControlStep1.phnum.errors\r\n                                  ?.phonenumAlreadyExist\r\n                              \"\r\n                            >\r\n                              Phone number already exist\r\n                            </span>\r\n                          </div>\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"form-group g-mt-03\">\r\n                      <label class=\"g-fs-07 g-black14-clr g-fw-500\">\r\n                        Landline\r\n                      </label>\r\n                      <div class=\"row\">\r\n                        <div class=\"col-sm-2 col-xs-4\">\r\n                          <input\r\n                            type=\"number\"\r\n                            class=\"form-control phone-code\"\r\n                            formControlName=\"landlineCode\"\r\n                            [ngClass]=\"{\r\n                              error:\r\n                                (formControlStep1.landlineCode.touched ||\r\n                                  isSubmitted.Step1) &&\r\n                                formControlStep1.landlineCode?.errors\r\n                            }\"\r\n                          />\r\n                        </div>\r\n                        <div class=\"col-sm-10 col-xs-8\">\r\n                          <input\r\n                            type=\"text\"\r\n                            class=\"form-control\"\r\n                            formControlName=\"landlineNumber\"\r\n                            [ngClass]=\"{\r\n                              error:\r\n                                (formControlStep1.landlineNumber.touched ||\r\n                                  isSubmitted.Step1) &&\r\n                                formControlStep1.landlineNumber?.errors\r\n                            }\"\r\n                            placeholder=\"ex:25666868\"\r\n                          />\r\n                          <div class=\"err-resp\">\r\n                            <span\r\n                              class=\"field-err\"\r\n                              *ngIf=\"\r\n                                formControlStep1.landlineNumber.touched &&\r\n                                formControlStep1.landlineNumber.errors?.pattern\r\n                              \"\r\n                            >\r\n                              Enter a valid phone number\r\n                            </span>\r\n                          </div>\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"g-pb-20 g-mt-20\">\r\n                      <button\r\n                        type=\"submit\"\r\n                        class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\"\r\n                        (click)=\"ShowNextStep('step2')\"\r\n                      >\r\n                        Next\r\n                      </button>\r\n                    </div>\r\n                  </div>\r\n                </form>\r\n                <div\r\n                  class=\"widget-grey-bg g-pt-10 g-pb-10 text-center back-login\"\r\n                >\r\n                  <div class=\"g-fs-08\">\r\n                    Back to&nbsp;<a\r\n                      [routerLink]=\"['/login']\"\r\n                      class=\"g-p-clr g-fw-500\"\r\n                      >Login</a\r\n                    >\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <!-- step 2 -->\r\n            <div class=\"card g-w-bg card-wrp\" [hidden]=\"seeker_stp_2\">\r\n              <div class=\"card-body\">\r\n                <form\r\n                  [formGroup]=\"seekerForm.Step2\"\r\n                  (ngSubmit)=\"onSubmit('Step2')\"\r\n                >\r\n                  <div class=\"form-wrapper g-pl-20 g-pr-20\">\r\n                    <div class=\"g-pt-25\">\r\n                      <div class=\"g-fs-18 g-fw-500 g-black7-clr text-center\">\r\n                        Hello !\r\n                        <span class=\"primary-green-clr\">{{\r\n                          user_name | titlecase\r\n                        }}</span>\r\n                      </div>\r\n                      <div class=\"g-fs-18 g-fw-500 g-black7-clr text-center\">\r\n                        tell us where you work.\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"form-group g-mt-20\">\r\n                      <label for=\"city\" class=\"g-fs-07 g-black14-clr g-fw-500\"\r\n                        >Which city are you affiliated with? *</label\r\n                      >\r\n                      <select\r\n                        class=\"form-control\"\r\n                        formControlName=\"city\"\r\n                        [ngClass]=\"{\r\n                          error:\r\n                            (formControlStep2.city.touched ||\r\n                              isSubmitted.Step2) &&\r\n                            formControlStep2.city.errors\r\n                        }\"\r\n                      >\r\n                        <option selected=\"selected\" value=\"\">\r\n                          Select City\r\n                        </option>\r\n                        <ng-container *ngFor=\"let city of smartCities?.data\">\r\n                          <option [value]=\"city.id\">\r\n                            {{ city.name | titlecase }}\r\n                          </option>\r\n                        </ng-container>\r\n                      </select>\r\n                      <div class=\"err-resp\">\r\n                        <span\r\n                          class=\"field-err\"\r\n                          *ngIf=\"\r\n                            (formControlStep2.city.touched ||\r\n                              isSubmitted.Step2) &&\r\n                            formControlStep2.city.errors\r\n                          \"\r\n                        >\r\n                          City is required\r\n                        </span>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"form-group g-mt-03\">\r\n                      <label for=\"dept\" class=\"g-fs-07 g-black14-clr g-fw-500\"\r\n                        >Department\r\n                      </label>\r\n                      <input\r\n                        type=\"text\"\r\n                        class=\"form-control\"\r\n                        formControlName=\"department\"\r\n                        [ngClass]=\"{\r\n                          error:\r\n                            (formControlStep2.department.touched ||\r\n                              isSubmitted.Step2) &&\r\n                            formControlStep2.department.errors?.pattern\r\n                        }\"\r\n                        placeholder=\"ex: Electricity\"\r\n                      />\r\n                      <div class=\"err-resp\">\r\n                        <span\r\n                          class=\"field-err\"\r\n                          *ngIf=\"\r\n                            formControlStep2.department.touched &&\r\n                            formControlStep2.department.errors?.pattern\r\n                          \"\r\n                        >\r\n                          Enter a valid department name\r\n                        </span>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"form-group g-mt-03\">\r\n                      <label\r\n                        for=\"designation\"\r\n                        class=\"g-fs-07 g-black14-clr g-fw-500\"\r\n                        >Your Designation\r\n                      </label>\r\n                      <input\r\n                        type=\"text\"\r\n                        class=\"form-control\"\r\n                        name=\"designation\"\r\n                        placeholder=\"ex: Professor\"\r\n                        formControlName=\"designation\"\r\n                        [ngClass]=\"{\r\n                          error:\r\n                            (formControlStep2.designation.touched ||\r\n                              isSubmitted.Step2) &&\r\n                            formControlStep2.designation.errors?.pattern\r\n                        }\"\r\n                      />\r\n                      <div class=\"err-resp\">\r\n                        <span\r\n                          class=\"field-err\"\r\n                          *ngIf=\"\r\n                            formControlStep2.designation.touched &&\r\n                            formControlStep2.designation.errors?.pattern\r\n                          \"\r\n                        >\r\n                          Enter a valid designation\r\n                        </span>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"g-mt-20 g-pb-25\">\r\n                      <button\r\n                        type=\"submit\"\r\n                        class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\"\r\n                        (click)=\"ShowNextStep('step3')\"\r\n                      >\r\n                        Next\r\n                      </button>\r\n                    </div>\r\n                  </div>\r\n                </form>\r\n              </div>\r\n            </div>\r\n            <!-- step 3 -->\r\n            <div class=\"card g-w-bg card-wrp\" [hidden]=\"seeker_stp_3\">\r\n              <div class=\"card-body\">\r\n                <form\r\n                  [formGroup]=\"seekerForm.Step3\"\r\n                  (ngSubmit)=\"onSubmit('Step3')\"\r\n                >\r\n                  <div class=\"form-wrapper g-pl-20 g-pr-20\">\r\n                    <div class=\"g-pt-30\">\r\n                      <div class=\"g-fs-18 g-fw-500 g-black7-clr text-center\">\r\n                        Let’s set your\r\n                      </div>\r\n                      <div\r\n                        class=\"g-fs-18 g-fw-500 primary-green-clr text-center\"\r\n                      >\r\n                        password.\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"form-group g-mt-13\">\r\n                      <label\r\n                        for=\"password\"\r\n                        class=\"g-fs-07 g-black14-clr g-fw-500\"\r\n                      >\r\n                        Password *</label\r\n                      >\r\n                      <input\r\n                        type=\"password\"\r\n                        class=\"form-control\"\r\n                        name=\"password\"\r\n                        formControlName=\"password\"\r\n                        [ngClass]=\"{\r\n                          error:\r\n                            (formControlStep3.password.touched ||\r\n                              isSubmitted.Step3) &&\r\n                            formControlStep3.password.errors\r\n                        }\"\r\n                      />\r\n                      <div class=\"err-resp\">\r\n                        <span\r\n                          class=\"field-err\"\r\n                          *ngIf=\"\r\n                            (formControlStep3.password.touched ||\r\n                              isSubmitted.Step3) &&\r\n                            formControlStep3.password.errors?.required\r\n                          \"\r\n                        >\r\n                          Password is required\r\n                        </span>\r\n                        <span\r\n                          class=\"field-err\"\r\n                          *ngIf=\"\r\n                            formControlStep3.password.touched &&\r\n                            formControlStep3.password.errors?.pattern\r\n                          \"\r\n                        >\r\n                          Password should have minimum 8 characters, at least\r\n                          one special character, one number and one capital letter\r\n                        </span>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"form-group g-mt-13\">\r\n                      <label\r\n                        for=\"confirmPassword\"\r\n                        class=\"g-fs-07 g-black14-clr g-fw-500\"\r\n                      >\r\n                        Confirm Password *</label\r\n                      >\r\n                      <input\r\n                        type=\"password\"\r\n                        class=\"form-control\"\r\n                        name=\"confirmPassword\"\r\n                        formControlName=\"confirmPassword\"\r\n                        [ngClass]=\"{\r\n                          error:\r\n                            (formControlStep3.confirmPassword.touched ||\r\n                              isSubmitted.Step3) &&\r\n                            formControlStep3.confirmPassword.errors\r\n                        }\"\r\n                      />\r\n                      <div class=\"err-resp\">\r\n                        <span\r\n                          class=\"field-err\"\r\n                          *ngIf=\"\r\n                            (formControlStep3.confirmPassword.touched ||\r\n                              isSubmitted.Step3) &&\r\n                            formControlStep3.confirmPassword.errors?.required\r\n                          \"\r\n                        >\r\n                          Confirm Password is required\r\n                        </span>\r\n                        <span\r\n                          class=\"field-err\"\r\n                          *ngIf=\"\r\n                            formControlStep3.confirmPassword.touched &&\r\n                            formControlStep3.confirmPassword.errors\r\n                              ?.passwordMismatch\r\n                          \"\r\n                        >\r\n                          Passwords doesn't match\r\n                        </span>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"g-mt-20 g-pb-25\">\r\n                      <button\r\n                        type=\"submit\"\r\n                        class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\"\r\n                        (click)=\"saveUser()\"\r\n                      >\r\n                        Next&nbsp;\r\n                        <i\r\n                          class=\"fas fa-circle-notch fa-spin\"\r\n                          *ngIf=\"loading\"\r\n                        ></i>\r\n                      </button>\r\n                    </div>\r\n                  </div>\r\n                </form>\r\n              </div>\r\n            </div>\r\n            <!-- step 4 -->\r\n            <div class=\"card g-w-bg card-wrp otp\" [hidden]=\"seeker_stp_4\">\r\n              <div class=\"card-body\">\r\n                <form\r\n                  [formGroup]=\"seekerForm.Step4\"\r\n                  (ngSubmit)=\"onSubmit('Step4')\"\r\n                >\r\n                  <div class=\"form-wrapper g-pl-20 g-pr-20\">\r\n                    <div class=\"g-pt-30\">\r\n                      <div class=\"g-fs-18 g-fw-500 title-clr text-center\">\r\n                        You are almost done!\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"g-pl-20 g-pr-20 g-mt-06\">\r\n                      <div class=\"g-fs-07 g-fw-500 g-black5-clr text-center\">\r\n                        A verification email has been sent to your email\r\n                        address. Please copy the verification code in the email\r\n                        and paste here to verify your account.\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"verification-code-wrp\">\r\n                      <div class=\"g-mt-20 g-mb-10\">\r\n                        <div class=\"g-fs-07 g-black14-clr g-fw-500\">\r\n                          Enter verification code\r\n                        </div>\r\n                      </div>\r\n                      <div class=\"form-group g-mb-0\">\r\n                        <input\r\n                          type=\"text\"\r\n                          class=\"form-control g-pt-5 g-pb-5 g-wht-bg\"\r\n                          name=\"email-otp\"\r\n                          formControlName=\"otp\"\r\n                          [ngClass]=\"{\r\n                            error:\r\n                              (formControlStep4.otp.touched ||\r\n                                isSubmitted.Step4) &&\r\n                              formControlStep4.otp.errors\r\n                          }\"\r\n                        />\r\n                        <div class=\"err-resp\">\r\n                          <span\r\n                            class=\"field-err\"\r\n                            *ngIf=\"\r\n                              (formControlStep4.otp.touched ||\r\n                                isSubmitted.Step4) &&\r\n                              formControlStep4.otp.errors?.required\r\n                            \"\r\n                          >\r\n                            Verification code is required\r\n                          </span>\r\n                          <span\r\n                            class=\"field-err\"\r\n                            *ngIf=\"\r\n                              formControlStep4.otp.touched &&\r\n                              formControlStep4.otp.errors?.minlength\r\n                            \"\r\n                          >\r\n                            Verification code should have 6 characters\r\n                          </span>\r\n                        </div>\r\n                        <div class=\"resend-verification-code text-right\">\r\n                          <span\r\n                            class=\"g-fs-06 g-fw-500 primary-green-clr g-cursor-pointer\"\r\n                            (click)=\"resendCode()\"\r\n                          >\r\n                            Resend verification code&nbsp;\r\n                            <i\r\n                              class=\"fas fa-circle-notch fa-spin\"\r\n                              *ngIf=\"resendCodeLoading\"\r\n                            ></i>\r\n                          </span>\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"g-pb-40 g-mt-30\">\r\n                      <button\r\n                        type=\"submit\"\r\n                        class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\"\r\n                        (click)=\"verifyOtp()\"\r\n                      >\r\n                        Verify Code&nbsp;\r\n                        <i\r\n                          class=\"fas fa-circle-notch fa-spin\"\r\n                          *ngIf=\"loading\"\r\n                        ></i>\r\n                      </button>\r\n                    </div>\r\n                  </div>\r\n                </form>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"col-sm-3\"></div>\r\n      </div>\r\n    </div>\r\n    <div class=\"col-sm-1\"></div>\r\n  </div>\r\n</div>\r\n<div\r\n  class=\"modal g-mt-30 fade avatar-upload-modal\"\r\n  id=\"imageModal\"\r\n  role=\"dialog\"\r\n>\r\n  <div class=\"modal-dialog modal-md\">\r\n    <!-- Modal content-->\r\n    <div class=\"modal-content\">\r\n      <div class=\"modal-header\">\r\n        <span class=\"modal-title g-fs-12 g-black14-clr g-fw-400\">\r\n          Set Avatar\r\n        </span>\r\n        <button\r\n          type=\"button\"\r\n          class=\"close g-fs-12 g-black14-clr g-fw-400\"\r\n          data-dismiss=\"modal\"\r\n          aria-label=\"Close\"\r\n        >\r\n          <span aria-hidden=\"true\">&times;</span>\r\n        </button>\r\n      </div>\r\n      <div class=\"modal-body\">\r\n        <!-- cropper widget -->\r\n        <div class=\"cropper-widget\">\r\n          <div class=\"cropper-col-left\">\r\n            <div class=\"cropper-wrp\">\r\n              <image-cropper\r\n                [imageChangedEvent]=\"imageChangedEvent\"\r\n                [maintainAspectRatio]=\"true\"\r\n                [aspectRatio]=\"1 / 1\"\r\n                resizeToWidth=\"256\"\r\n                roundCropper=\"true\"\r\n                format=\"png\"\r\n                (imageCropped)=\"imageCropped($event)\"\r\n                (imageLoaded)=\"imageLoaded()\"\r\n                (cropperReady)=\"cropperReady()\"\r\n                (loadImageFailed)=\"loadImageFailed()\"\r\n              >\r\n              </image-cropper>\r\n            </div>\r\n          </div>\r\n          <div class=\"cropper-col-right\">\r\n            <div class=\"cropper-preview\">\r\n              <img [src]=\"croppedImage\" />\r\n            </div>\r\n            <hr />\r\n            <div class=\"g-pb-06\">\r\n              <label\r\n                for=\"avatar\"\r\n                class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\"\r\n              >\r\n                <i class=\"fas fa-image\" aria-hidden=\"true\"></i>&nbsp;&nbsp;\r\n                <span\r\n                  *ngIf=\"fileLoaded; then changePicture; else addPicture\"\r\n                ></span>\r\n                <ng-template #addPicture>Add Image</ng-template>\r\n                <ng-template #changePicture>Change Image</ng-template>\r\n              </label>\r\n              <input\r\n                type=\"file\"\r\n                id=\"avatar\"\r\n                name=\"avatar\"\r\n                accept=\"image/png, image/jpeg\"\r\n                class=\"hidden\"\r\n                (change)=\"fileChangeEvent($event)\"\r\n              />\r\n            </div>\r\n            <div class=\"g-pb-06\" *ngIf=\"fileLoaded\">\r\n              <div class=\"g-fs-12 g-black14-clr g-fw-400\">\r\n                <button\r\n                  type=\"button\"\r\n                  (click)=\"saveCropedImage()\"\r\n                  class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\"\r\n                >\r\n                  <i class=\"far fa-save\" aria-hidden=\"true\"></i>&nbsp;&nbsp;Save\r\n                  Image\r\n                </button>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div></div>\r\n";
    /***/
  },

  /***/
  "./src/app/register/home/home.component.css":
  /*!**************************************************!*\
    !*** ./src/app/register/home/home.component.css ***!
    \**************************************************/

  /*! exports provided: default */

  /***/
  function srcAppRegisterHomeHomeComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".pattern-bg{\r\n    background-image: url('pattern-bg.png');\r\n    background-position: center;\r\n    background-repeat: no-repeat;\r\n    background-size: 57%;\r\n}\r\n\r\n.signup-card,\r\n.signup-card a{\r\n    -webkit-transition:all 0.2s ease;\r\n    transition:all 0.2s ease;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVnaXN0ZXIvaG9tZS9ob21lLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSx1Q0FBMkQ7SUFDM0QsMkJBQTJCO0lBQzNCLDRCQUE0QjtJQUM1QixvQkFBb0I7QUFDeEI7O0FBRUE7O0lBRUksZ0NBQXdCO0lBQXhCLHdCQUF3QjtBQUM1QiIsImZpbGUiOiJzcmMvYXBwL3JlZ2lzdGVyL2hvbWUvaG9tZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnBhdHRlcm4tYmd7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uLy4uL2Fzc2V0cy9pbWcvcGF0dGVybi1iZy5wbmcnKTtcclxuICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IDU3JTtcclxufVxyXG5cclxuLnNpZ251cC1jYXJkLFxyXG4uc2lnbnVwLWNhcmQgYXtcclxuICAgIHRyYW5zaXRpb246YWxsIDAuMnMgZWFzZTtcclxufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/register/home/home.component.ts":
  /*!*************************************************!*\
    !*** ./src/app/register/home/home.component.ts ***!
    \*************************************************/

  /*! exports provided: HomeComponent */

  /***/
  function srcAppRegisterHomeHomeComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomeComponent", function () {
      return HomeComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    let HomeComponent = class HomeComponent {
      constructor() {}

      ngOnInit() {}

    };
    HomeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-home',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./home.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/register/home/home.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./home.component.css */
      "./src/app/register/home/home.component.css")).default]
    })], HomeComponent);
    /***/
  },

  /***/
  "./src/app/register/register-routing.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/register/register-routing.module.ts ***!
    \*****************************************************/

  /*! exports provided: RegisterRoutingModule */

  /***/
  function srcAppRegisterRegisterRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RegisterRoutingModule", function () {
      return RegisterRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _home_home_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./home/home.component */
    "./src/app/register/home/home.component.ts");
    /* harmony import */


    var _register_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./register.component */
    "./src/app/register/register.component.ts");
    /* harmony import */


    var _seekers_seekers_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./seekers/seekers.component */
    "./src/app/register/seekers/seekers.component.ts");

    const routes = [{
      path: '',
      component: _register_component__WEBPACK_IMPORTED_MODULE_4__["RegisterComponent"],
      children: [{
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
      }, {
        path: 'home',
        component: _home_home_component__WEBPACK_IMPORTED_MODULE_3__["HomeComponent"]
      }, {
        path: 'seeker',
        component: _seekers_seekers_component__WEBPACK_IMPORTED_MODULE_5__["SeekersComponent"]
      }, {
        path: 'provider',
        loadChildren: './provider/provider.module#ProviderModule'
      }, {
        path: 'via',
        loadChildren: './startup-india/startup-india.module#StartupIndiaModule'
      }]
    }];
    let RegisterRoutingModule = class RegisterRoutingModule {};
    RegisterRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], RegisterRoutingModule);
    /***/
  },

  /***/
  "./src/app/register/register.component.css":
  /*!*************************************************!*\
    !*** ./src/app/register/register.component.css ***!
    \*************************************************/

  /*! exports provided: default */

  /***/
  function srcAppRegisterRegisterComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlZ2lzdGVyL3JlZ2lzdGVyLmNvbXBvbmVudC5jc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/register/register.component.ts":
  /*!************************************************!*\
    !*** ./src/app/register/register.component.ts ***!
    \************************************************/

  /*! exports provided: RegisterComponent */

  /***/
  function srcAppRegisterRegisterComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RegisterComponent", function () {
      return RegisterComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    let RegisterComponent = class RegisterComponent {
      constructor() {}

      ngOnInit() {}

    };
    RegisterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-register',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./register.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./register.component.css */
      "./src/app/register/register.component.css")).default]
    })], RegisterComponent);
    /***/
  },

  /***/
  "./src/app/register/register.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/register/register.module.ts ***!
    \*********************************************/

  /*! exports provided: RegisterModule */

  /***/
  function srcAppRegisterRegisterModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RegisterModule", function () {
      return RegisterModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _register_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./register-routing.module */
    "./src/app/register/register-routing.module.ts");
    /* harmony import */


    var _register_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./register.component */
    "./src/app/register/register.component.ts");
    /* harmony import */


    var _seekers_seekers_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./seekers/seekers.component */
    "./src/app/register/seekers/seekers.component.ts");
    /* harmony import */


    var _home_home_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./home/home.component */
    "./src/app/register/home/home.component.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var ngx_image_cropper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ngx-image-cropper */
    "./node_modules/ngx-image-cropper/fesm2015/ngx-image-cropper.js");
    /* harmony import */


    var _ckeditor_ckeditor5_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @ckeditor/ckeditor5-angular */
    "./node_modules/@ckeditor/ckeditor5-angular/fesm2015/ckeditor-ckeditor5-angular.js");

    let RegisterModule = class RegisterModule {};
    RegisterModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      declarations: [_register_component__WEBPACK_IMPORTED_MODULE_4__["RegisterComponent"], _seekers_seekers_component__WEBPACK_IMPORTED_MODULE_5__["SeekersComponent"], _home_home_component__WEBPACK_IMPORTED_MODULE_6__["HomeComponent"]],
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _register_routing_module__WEBPACK_IMPORTED_MODULE_3__["RegisterRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ReactiveFormsModule"], ngx_image_cropper__WEBPACK_IMPORTED_MODULE_8__["ImageCropperModule"], _ckeditor_ckeditor5_angular__WEBPACK_IMPORTED_MODULE_9__["CKEditorModule"]]
    })], RegisterModule);
    /***/
  },

  /***/
  "./src/app/register/seekers/seekers.component.css":
  /*!********************************************************!*\
    !*** ./src/app/register/seekers/seekers.component.css ***!
    \********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppRegisterSeekersSeekersComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".card-wrp{\r\n    max-width:520px;\r\n    margin-left: auto;\r\n    margin-right:auto;\r\n    box-shadow: 5px 5px 20px rgba(172, 177, 193, 0.4);\r\n    border-radius: 10px;\r\n}\r\n\r\n.card-wrp.otp{\r\n    max-width:600px;\r\n}\r\n\r\n.card-wrp .back-login{\r\n    border-bottom-right-radius: 10px;\r\n    border-bottom-left-radius: 10px;\r\n}\r\n\r\n.verification-code-wrp{\r\n    max-width:240px;\r\n    margin: auto;\r\n}\r\n\r\n.verification-code-wrp input{\r\n    border: 1px solid #C2C7C8 !important;\r\n    width:100%;\r\n}\r\n\r\n.verification-code-wrp input.error{\r\n    border-color: #f8483d !important;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVnaXN0ZXIvc2Vla2Vycy9zZWVrZXJzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixpREFBaUQ7SUFDakQsbUJBQW1CO0FBQ3ZCOztBQUVBO0lBQ0ksZUFBZTtBQUNuQjs7QUFFQTtJQUNJLGdDQUFnQztJQUNoQywrQkFBK0I7QUFDbkM7O0FBRUE7SUFDSSxlQUFlO0lBQ2YsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLG9DQUFvQztJQUNwQyxVQUFVO0FBQ2Q7O0FBRUE7SUFDSSxnQ0FBZ0M7QUFDcEMiLCJmaWxlIjoic3JjL2FwcC9yZWdpc3Rlci9zZWVrZXJzL3NlZWtlcnMuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jYXJkLXdycHtcclxuICAgIG1heC13aWR0aDo1MjBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgbWFyZ2luLXJpZ2h0OmF1dG87XHJcbiAgICBib3gtc2hhZG93OiA1cHggNXB4IDIwcHggcmdiYSgxNzIsIDE3NywgMTkzLCAwLjQpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxufVxyXG5cclxuLmNhcmQtd3JwLm90cHtcclxuICAgIG1heC13aWR0aDo2MDBweDtcclxufVxyXG5cclxuLmNhcmQtd3JwIC5iYWNrLWxvZ2lue1xyXG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDEwcHg7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAxMHB4O1xyXG59XHJcblxyXG4udmVyaWZpY2F0aW9uLWNvZGUtd3Jwe1xyXG4gICAgbWF4LXdpZHRoOjI0MHB4O1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG59XHJcblxyXG4udmVyaWZpY2F0aW9uLWNvZGUtd3JwIGlucHV0e1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI0MyQzdDOCAhaW1wb3J0YW50O1xyXG4gICAgd2lkdGg6MTAwJTtcclxufVxyXG5cclxuLnZlcmlmaWNhdGlvbi1jb2RlLXdycCBpbnB1dC5lcnJvcntcclxuICAgIGJvcmRlci1jb2xvcjogI2Y4NDgzZCAhaW1wb3J0YW50O1xyXG59Il19 */";
    /***/
  },

  /***/
  "./src/app/register/seekers/seekers.component.ts":
  /*!*******************************************************!*\
    !*** ./src/app/register/seekers/seekers.component.ts ***!
    \*******************************************************/

  /*! exports provided: SeekersComponent */

  /***/
  function srcAppRegisterSeekersSeekersComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SeekersComponent", function () {
      return SeekersComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var ngx_toastr__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ngx-toastr */
    "./node_modules/ngx-toastr/fesm2015/ngx-toastr.js");
    /* harmony import */


    var _seekers_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./seekers.service */
    "./src/app/register/seekers/seekers.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _services_customvalidation_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../services/customvalidation.service */
    "./src/app/services/customvalidation.service.ts");
    /* harmony import */


    var ngx_image_cropper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ngx-image-cropper */
    "./node_modules/ngx-image-cropper/fesm2015/ngx-image-cropper.js");

    let SeekersComponent = class SeekersComponent {
      constructor(_ss, toastr, router, fb, customValidator) {
        this._ss = _ss;
        this.toastr = toastr;
        this.router = router;
        this.fb = fb;
        this.customValidator = customValidator;
        this.seekerForm = {
          Step1: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"],
          Step2: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"],
          Step3: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"],
          Step4: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]
        };
        this.isSubmitted = {
          Step1: false,
          Step2: false,
          Step3: false,
          Step4: false,
          Step5: false
        };
        this.verifyingOTP = false;
        this.loading = false;
        this.created_user = {};
        this.user_name = "";
        this.avatar_preview = "./assets/img/default-avatar.jpg";
        this.imageChangedEvent = "";
        this.croppedImage = "";
        this.fileLoaded = false;
        this.resendCodeLoading = false;
      }

      ngOnInit() {
        this.listSmartCities();
        this.seeker_stp_1 = false;
        this.seeker_stp_2 = true;
        this.seeker_stp_3 = true;
        this.seeker_stp_4 = true;
        this.seekerForm = {
          Step1: this.fb.group({
            fullname: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].pattern("[a-zA-Z .]*")]],
            email: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].email, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')], this.customValidator.emailAvailabilityValidator.bind(this.customValidator)],
            phnum: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].pattern("(0|91)?[5-9][0-9]{9}")], this.customValidator.phoneAvailabilityValidator.bind(this.customValidator)],
            landlineCode: ["00", _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].pattern("^\\d{2,8}$")],
            landlineNumber: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].pattern("^\\d{8}$")]
          }),
          Step2: this.fb.group({
            city: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].min(1)]],
            department: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].pattern("^[a-zA-Z]+$")],
            designation: ["", _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].pattern("^[a-zA-Z]+$")]
          }),
          Step3: this.fb.group({
            password: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].pattern("^(?=.*[0-9])(?=.*[!@#$%^&*])(?=.*[A-Z])[a-zA-Z0-9!@#$%^&*]{8,}$")]],
            confirmPassword: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required]]
          }, {
            validator: this.customValidator.MatchPassword("password", "confirmPassword")
          }),
          Step4: this.fb.group({
            otp: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].minLength(6)]]
          })
        };
      }

      listSmartCities() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
          try {
            this.smartCities = yield this._ss.getSmartCities(); // console.log(this.smartCities);
          } catch (err) {
            console.log(err);
            this.toastr.error("", "Something went wrong please try again");
          }
        });
      }

      onSubmit(formIndex) {
        switch (formIndex) {
          case "Step1":
            {
              this.isSubmitted.Step1 = true;
              break;
            }

          case "Step2":
            {
              this.isSubmitted.Step2 = true;
              break;
            }

          case "Step3":
            {
              this.isSubmitted.Step3 = true;
              break;
            }

          case "Step4":
            {
              this.isSubmitted.Step4 = true;
              break;
            }
        }
      }

      get formControlStep1() {
        return this.seekerForm.Step1.controls;
      }

      get formControlStep2() {
        return this.seekerForm.Step2.controls;
      }

      get formControlStep3() {
        return this.seekerForm.Step3.controls;
      }

      get formControlStep4() {
        return this.seekerForm.Step4.controls;
      }

      get formControlStep5() {
        return this.seekerForm.Step5.controls;
      }

      ShowNextStep(step) {
        if (step == "step2" && this.seekerForm.Step1.valid) {
          this.user_name = this.seekerForm.Step1.value.fullname;
          this.seeker_stp_1 = true;
          this.seeker_stp_2 = false;
        } else if (step == "step3" && this.seekerForm.Step2.valid) {
          this.seeker_stp_2 = true;
          this.seeker_stp_3 = false;
        } else if (step == "step4" && this.seekerForm.Step3.valid) {
          this.seeker_stp_3 = true;
          this.seeker_stp_4 = false;
        } else {
          this.toastr.error("", "Please provide the required values to proceed further");
        }
      }

      ShowPreviousStep(step) {
        if (step == "step2") {
          this.seeker_stp_1 = false;
          this.seeker_stp_2 = true;
        } else if (step == "step3") {
          this.seeker_stp_2 = false;
          this.seeker_stp_3 = true;
        }
      }

      setChosenFile(event) {
        if (event.target.files && event.target.files[0]) {
          this.file = event.target.files[0];
          const reader = new FileReader();
          reader.readAsDataURL(this.file); // console.log("File", this.file);

          reader.onload = e => {
            this.avatar_preview = reader.result;
          };

          document.getElementById("imageModal").click();
        }
      }

      fileChangeEvent(event) {
        this.imageChangedEvent = event;
      }

      imageCropped(event) {
        this.croppedImage = event.base64;
      }

      imageLoaded() {
        this.fileLoaded = true;
      }

      cropperReady() {// cropper ready
      }

      loadImageFailed() {// show message
      }

      saveCropedImage() {
        const fileBeforeCrop = this.imageChangedEvent.target.files[0];
        this.file = new File([Object(ngx_image_cropper__WEBPACK_IMPORTED_MODULE_7__["base64ToFile"])(this.croppedImage)], fileBeforeCrop.name, {
          type: fileBeforeCrop.type
        });
        this.avatar_preview = this.croppedImage;
        document.getElementById("imageModal").click();
      }

      gotoStep(step) {
        switch (step) {
          case "step1":
            {
              this.seeker_stp_1 = false;
              this.seeker_stp_2 = true;
              this.seeker_stp_3 = true;
              this.seeker_stp_4 = true;
              break;
            }

          case "step2":
            {
              this.seeker_stp_1 = true;
              this.seeker_stp_2 = false;
              this.seeker_stp_3 = true;
              this.seeker_stp_4 = true;
              break;
            }

          case "step3":
            {
              this.seeker_stp_1 = true;
              this.seeker_stp_2 = true;
              this.seeker_stp_3 = false;
              this.seeker_stp_4 = true;
              break;
            }

          case "step4":
            {
              this.seeker_stp_1 = true;
              this.seeker_stp_2 = true;
              this.seeker_stp_3 = true;
              this.seeker_stp_4 = false;
              break;
            }
        }
      }

      saveUser() {
        if (this.seekerForm.Step1.valid && this.seekerForm.Step2.valid && this.seekerForm.Step3.valid) {
          this.loading = true;
          var post_data = {
            data: {
              email: this.seekerForm.Step1.value.email,
              mobile_code: "+91",
              mobile: this.seekerForm.Step1.value.phnum,
              password: this.seekerForm.Step3.value.password,
              role_seeker: true,
              social_signup_via: ""
            }
          };
          var seeker_post_data = {
            data: {
              fullname: this.seekerForm.Step1.value.fullname,
              frg_smart_city_id: this.seekerForm.Step2.value.city,
              department: this.seekerForm.Step2.value.department,
              designation: this.seekerForm.Step2.value.designation,
              phone_code: "+91",
              phone: this.seekerForm.Step1.value.phnum,
              landline_num: this.seekerForm.Step1.value.landlineCode == "" || this.seekerForm.Step1.value.landlineNumber == "" ? "" : "".concat(this.seekerForm.Step1.value.landlineCode, "-").concat(this.seekerForm.Step1.value.landlineNumber),
              frg_user_id: null
            }
          };

          this._ss.saveUserApi(post_data).subscribe(response => {
            if (response.status == true) {
              this.created_user = response.data;
              seeker_post_data.data.frg_user_id = response.data.id;

              this._ss.saveSeekerApi(seeker_post_data).subscribe(seekerResponse => {
                this.seeker_data = seekerResponse.data;
                this.saveAvatar();
                this.loading = false;
                this.ShowNextStep("step4");
              });
            }
          }, response => {
            this.loading = false; // console.log(response);

            if (response.error.data.code === "E_UNIQUE" && response.error.status === false) {
              this.toastr.error("", response.error.msg);
            } else {
              this.toastr.error("", "Something went wrong please try again");
            }
          });
        } else {
          this.toastr.error("", "Please provide the required values to proceed further");
        }
      }

      saveAvatar() {
        if (this.file) {
          let formData = new FormData();
          formData.append("slug", this.seeker_data.id);
          formData.append("avatar", this.file, this.file.name); // console.log("FornData", formData);

          this._ss.uploadAvataar(formData).subscribe(response => {// console.log("Save Avatar", response);
          });
        }
      }

      resendCode() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
          try {
            this.resendCodeLoading = true;
            let resp = yield this._ss.resendVerficationCode({
              slug: {
                id: this.created_user.id
              }
            });
            this.resendCodeLoading = false;

            if (resp.status == true) {
              this.toastr.info("", resp.msg);
            } else {
              this.toastr.error("", resp.msg);
            }
          } catch (err) {
            this.resendCodeLoading = false;
            console.log(err);
            this.toastr.error("", "Something went wrong please try again");
          }
        });
      }

      verifyOtp() {
        if (this.seekerForm.Step1.valid && this.seekerForm.Step2.valid && this.seekerForm.Step3.valid && this.seekerForm.Step4.valid) {
          let post_data = {
            slug: {
              id: this.created_user.id
            },
            data: {
              email_otp: this.seekerForm.Step4.value.otp
            }
          };
          this.verifyingOTP = true;

          this._ss.verifyOtp(post_data).subscribe(response => {
            this.verifyingOTP = false;

            if (response.status == true) {
              // this.toastr.success("", "User verified successfully");
              this.router.navigate(["/login"]).then(() => {
                this.toastr.warning("Your account is being reviewed by the Admin and is pending approval. You will receive an email once it is approved.", "Pending for Approval");
              });
            } else {
              this.toastr.error("", "Verification code entered is invalid");
            }
          });
        } else {
          this.verifyingOTP = false;
          this.toastr.error("", "Please provide the required values to proceed further");
        }
      }

    };

    SeekersComponent.ctorParameters = () => [{
      type: _seekers_service__WEBPACK_IMPORTED_MODULE_4__["SeekersService"]
    }, {
      type: ngx_toastr__WEBPACK_IMPORTED_MODULE_3__["ToastrService"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]
    }, {
      type: _services_customvalidation_service__WEBPACK_IMPORTED_MODULE_6__["CustomvalidationService"]
    }];

    SeekersComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: "app-seekers",
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./seekers.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/register/seekers/seekers.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./seekers.component.css */
      "./src/app/register/seekers/seekers.component.css")).default]
    })], SeekersComponent);
    /***/
  }
}]);
//# sourceMappingURL=register-register-module-es5.js.map