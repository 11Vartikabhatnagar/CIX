(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./provider/provider.module": [
		"./src/app/register/provider/provider.module.ts",
		"default~challenge-challenge-module~provider-provider-module~seeker-seeker-module~startup-india-start~e8be73ad",
		"default~provider-provider-module~solution-solution-module",
		"common",
		"provider-provider-module"
	],
	"./register/register.module": [
		"./src/app/register/register.module.ts",
		"common",
		"register-register-module"
	],
	"./startup-india/startup-india.module": [
		"./src/app/register/startup-india/startup-india.module.ts",
		"default~challenge-challenge-module~provider-provider-module~seeker-seeker-module~startup-india-start~e8be73ad",
		"common",
		"startup-india-startup-india-module"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn-bd": "./node_modules/moment/locale/bn-bd.js",
	"./bn-bd.js": "./node_modules/moment/locale/bn-bd.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-in": "./node_modules/moment/locale/en-in.js",
	"./en-in.js": "./node_modules/moment/locale/en-in.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./en-sg": "./node_modules/moment/locale/en-sg.js",
	"./en-sg.js": "./node_modules/moment/locale/en-sg.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-mx": "./node_modules/moment/locale/es-mx.js",
	"./es-mx.js": "./node_modules/moment/locale/es-mx.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fil": "./node_modules/moment/locale/fil.js",
	"./fil.js": "./node_modules/moment/locale/fil.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-deva": "./node_modules/moment/locale/gom-deva.js",
	"./gom-deva.js": "./node_modules/moment/locale/gom-deva.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./oc-lnc": "./node_modules/moment/locale/oc-lnc.js",
	"./oc-lnc.js": "./node_modules/moment/locale/oc-lnc.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tk": "./node_modules/moment/locale/tk.js",
	"./tk.js": "./node_modules/moment/locale/tk.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-mo": "./node_modules/moment/locale/zh-mo.js",
	"./zh-mo.js": "./node_modules/moment/locale/zh-mo.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-header></app-header>\r\n<router-outlet></router-outlet>\r\n<app-footer></app-footer>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/challenge/challenges-multi-select/challenges-multi-select.component.html":
/*!********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/challenge/challenges-multi-select/challenges-multi-select.component.html ***!
  \********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"g-blue3-bg\">\r\n    <div class=\"container g-pt-20 g-pb-20\">\r\n        <!-- <div class=\"col-xs-1\"></div> -->\r\n        <!-- <div class=\"\"> -->\r\n            <div class=\"row\">\r\n                <div class=\"col-xs-9 g-pr-0\">\r\n                    <input type=\"text\" class=\"form-control search-input g-h-24\" id=\"search\" placeholder=\"Search for Challenges\">\r\n                </div>\r\n                <div class=\"col-xs-1 g-p-0\">\r\n                    <button type=\"button\" class=\"btn g-p-bg g-w-clr g-pl-08 g-pr-08 search-btn g-h-24\"><i class=\"fa fa-search\" aria-hidden=\"true\"></i></button>\r\n                </div>\r\n                <div class=\"col-xs-2\">\r\n                    <button type=\"button\" class=\"btn g-white-bg g-blue4-clr g-fw-500 g-w-100per g-pt-07 g-pb-07\"><i class=\"fa fa-plus\" aria-hidden=\"true\"></i> &nbsp;Create Challenge</button>\r\n                </div>\r\n            </div>\r\n        <!-- </div> -->\r\n        <!-- <div class=\"col-xs-1\"></div> -->\r\n    </div>\r\n</div>\r\n<div class=\"container g-blue5-bg g-pt-38 g-pb-50\">\r\n    <!-- <div class=\"col-xs-1\"></div> -->\r\n    <!-- <div class=\"col-xs-10\"> -->\r\n        <div class=\"card g-pt-20\">\r\n            <div class=\"card-body\">\r\n                <div class=\"row\">\r\n                    <div class=\"col-sm-6\">\r\n                        <div class=\"g-fs-12 g-fw-500 g-black5-clr\"> Water bodies preservation and monitoring</div>\r\n                        <div class=\"g-mt-06\">\r\n                            <div class=\"g-fs-06 g-fw-700 g-bdr-005 g-p-04 g-black5-brdr g-bdrrad-4px g-trans-bg g-w-200px text-center g-grey3-clr\">WATER MANAGEMENT</div>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"col-sm-2\">\r\n                        <div class=\"g-fs-14 g-fw-500 text-center\">\r\n                            3\r\n                        </div>\r\n                        <div class=\"g-pt-04\">\r\n                            <div class=\"g-fs-06 g-fw-500 text-center g-black5-clr\">\r\n                                Offerings\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"col-sm-2\">\r\n                        <div class=\"g-fs-14 g-fw-500 text-center\">\r\n                            0\r\n                        </div>\r\n                        <div class=\"g-pt-04\">\r\n                            <div class=\"g-fs-06 g-fw-500 text-center g-black5-clr\">\r\n                                Applications\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"col-sm-2\">\r\n                        <div class=\"g-fs-14 g-fw-500 text-center\">\r\n                            3\r\n                        </div>\r\n                        <div class=\"g-pt-04\">\r\n                            <div class=\"g-fs-06 g-fw-500 text-center g-black5-clr\">\r\n                                Pilots\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n\r\n        <div class=\"g-bdr-005 g-black5-brdr g-bdrrad-5px g-mt-50 g-pt-11 g-pb-11\">\r\n            <div class=\"text-center\">\r\n                <span class=\"g-fs-07 g-fw-700 g-black5-clr\">ADD ANCHOR</span>&nbsp;\r\n                <span class=\"g-fs-07 g-fw-700 g-black5-clr\"><i class=\"fa fa-plus g-fs-08\" aria-hidden=\"true\"></i></span>&nbsp;\r\n                <span class=\"g-fs-07 g-fw-700 g-black5-clr\">FOR</span>&nbsp;\r\n                <span class=\"g-fs-06 g-w-clr g-fw-600 g-p-bg g-pt-02 g-pb-02 g-pl-03 g-pr-03 g-bdrrad-10per\">DELHI</span>\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\"g-mt-17\">\r\n            <!-- <ul class=\"nav nav-tabs offering-nav-tabs\">\r\n                <li class=\"active\"><a data-toggle=\"tab\" href=\"#home\" class=\"g-fs-07\">Your Anchor</a></li>\r\n                <li><a data-toggle=\"tab\" href=\"#menu1\" class=\"g-fs-07\">Other Anchors & Offerings</a></li>\r\n            </ul> -->\r\n        \r\n            <div class=\"panel g-pt-09 g-pb-10 g-pl-12 g-pr-12 g-w-bg g-bdr-01 g-brdr-grey g-bdrrad-5px\">\r\n                <div class=\"panel-body g-p-0\">\r\n                    <div class=\"row\">\r\n                        <div class=\"col-sm-5\">\r\n                            <div class=\"g-fs-08 g-lh-10 g-fw-500\">Pellentesque quis neque vitae metus convallis tristique non vel velit. Proin consectetur odio quis auctor auctor. Phasellus iaculis urna nec maximus pretium.</div>\r\n                        </div>\r\n                        <div class=\"col-sm-7\">\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"row g-mt-27\">\r\n                        <div class=\"col-sm-6\">\r\n                            <div class=\"g-mt-10\">\r\n                                <div class=\"g-fs-07 g-lh-08 g-grey3-clr\">\r\n                                    Anchored by Ravi Shankar for \r\n                                    <span class=\"g-fw-500\">TRICHY</span>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-sm-6 text-right\">\r\n                            <div>\r\n                                <button class=\"btn g-bdr-005 g-w-bg g-black5-brdr g-pt-05 g-pb-05 g-pl-10 g-pr-10 view-application-btn g-fw-700\">VIEW APPLICATIONS &nbsp;<i class=\"fa fa-arrow-right  g-grey3-clr\" aria-hidden=\"true\"></i></button>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n\r\n        <div class=\"g-mt-32\">\r\n            <div class=\"row\">\r\n                <div class=\"col-md-5 hidden-sm g-pr-0\">\r\n                    <div class=\"g-blue3-bg g-h-01 g-mt-10\"></div>\r\n                </div>\r\n                <div class=\"col-md-2 text-center\">\r\n                    <div class=\"g-fs-09 g-lh-11 g-blue3-clr g-fw-700 g-mt-05\">OFFERINGS</div>\r\n                </div>\r\n                <div class=\"col-md-3 hidden-sm g-p-0\">\r\n                    <div class=\"g-blue3-bg g-h-01 g-mt-10\"></div>\r\n                </div>\r\n                <div class=\"col-md-2 g-pl-0\">\r\n                    <div class=\"pull-right\">\r\n                        <button class=\"btn g-bdr-005 g-trans-bg g-grey3-brdr g-pt-05 g-pb-05 g-pl-10 g-pr-10 g-bdrrad-6px g-fs-07 g-lh-08 g-fw-700\">SEND EOI &nbsp;<i class=\"fa fa-arrow-right  g-grey3-clr\" aria-hidden=\"true\"></i></button>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            \r\n        </div>\r\n        <div class=\"offerings-card-wrapper\">\r\n            <div class=\"row g-pt-28\">\r\n                <div class=\"col-sm-6\">\r\n                    <div class=\"panel g-bdrrad-10px challenges-some-anchor-card\">\r\n                        <div class=\"panel-body g-p-0\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col-xs-5 g-pr-0\">\r\n                                    <img src=\"assets/img/offerings-img2.png\" alt=\"Image\" class=\"\" >\r\n                                </div>\r\n                                <div class=\"col-xs-7 g-pl-10  g-pr-10\">\r\n                                    <div class=\"g-pt-09\">\r\n                                        <div class=\"g-fs-08 g-lh-09 g-fw-500 g-black5-clr\">Lorem ipsum dolor sit amet, consectr adipiscing elit.</div>\r\n                                    </div>\r\n                                    <div class=\"g-pt-04\">\r\n                                        <div class=\"g-fs-07 g-lh-08 g-fw-400 g-grey4-clr\">by Neer Tech Solutions</div>\r\n                                    </div>\r\n                                    <div class=\"g-pt-08\">\r\n                                        <button type=\"button\" class=\"btn g-fs-06 g-yellow-bg text-center g-w-clr g-pt-02 g-pb-02 g-pl-04 g-pr-04 g-fw-700\">PRE PILOT</button>\r\n                                    </div>\r\n                                    <div class=\"g-pt-31 g-pb-12\">\r\n                                        <div class=\"g-fs-06\">Posted on 13 Aug 2020</div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-sm-6\">\r\n                    <div class=\"panel g-bdrrad-10px challenges-some-anchor-card\">\r\n                        <div class=\"panel-body g-p-0\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col-xs-5 g-pr-0\">\r\n                                    <img src=\"assets/img/offerings-img2.png\" alt=\"Image\" class=\"\" >\r\n                                </div>\r\n                                <div class=\"col-xs-7 g-pl-10  g-pr-10\">\r\n                                    <div class=\"g-pt-09\">\r\n                                        <div class=\"g-fs-08 g-lh-09 g-fw-500 g-black5-clr\">Lorem ipsum dolor sit amet, consectr adipiscing elit.</div>\r\n                                    </div>\r\n                                    <div class=\"g-pt-04\">\r\n                                        <div class=\"g-fs-07 g-lh-08 g-fw-400 g-grey4-clr\">by Neer Tech Solutions</div>\r\n                                    </div>\r\n                                    <div class=\"g-pt-08\">\r\n                                        <button type=\"button\" class=\"btn g-fs-06 g-yellow-bg text-center g-w-clr g-pt-02 g-pb-02 g-pl-04 g-pr-04 g-fw-700\">PRE PILOT</button>\r\n                                    </div>\r\n                                    <div class=\"g-pt-31 g-pb-12\">\r\n                                        <div class=\"g-fs-06\">Posted on 13 Aug 2020</div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"row g-pt-08\">\r\n                <div class=\"col-sm-6\">\r\n                    <div class=\"panel g-bdrrad-10px challenges-some-anchor-card\">\r\n                        <div class=\"panel-body g-p-0\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col-xs-5 g-pr-0\">\r\n                                    <img src=\"assets/img/offerings-img2.png\" alt=\"Image\" class=\"\" >\r\n                                </div>\r\n                                <div class=\"col-xs-7 g-pl-10  g-pr-10\">\r\n                                    <div class=\"g-pt-09\">\r\n                                        <div class=\"g-fs-08 g-lh-09 g-fw-500 g-black5-clr\">Lorem ipsum dolor sit amet, consectr adipiscing elit.</div>\r\n                                    </div>\r\n                                    <div class=\"g-pt-04\">\r\n                                        <div class=\"g-fs-07 g-lh-08 g-fw-400 g-grey4-clr\">by Neer Tech Solutions</div>\r\n                                    </div>\r\n                                    <div class=\"g-pt-08\">\r\n                                        <button type=\"button\" class=\"btn g-fs-06 g-green-bg text-center g-w-clr g-pt-02 g-pb-02 g-pl-04 g-pr-04 g-fw-700\">PILOT READY</button>\r\n                                    </div>\r\n                                    <div class=\"g-pt-31 g-pb-12\">\r\n                                        <div class=\"g-fs-06\">Posted on 13 Aug 2020</div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-sm-6\">\r\n                    <div class=\"panel g-bdrrad-10px challenges-some-anchor-card\">\r\n                        <div class=\"panel-body g-p-0\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col-xs-5 g-pr-0\">\r\n                                    <img src=\"assets/img/offerings-img2.png\" alt=\"Image\" class=\"\" >\r\n                                </div>\r\n                                <div class=\"col-xs-7 g-pl-10  g-pr-10\">\r\n                                    <div class=\"g-pt-09\">\r\n                                        <div class=\"g-fs-08 g-lh-09 g-fw-500 g-black5-clr\">Lorem ipsum dolor sit amet, consectr adipiscing elit.</div>\r\n                                    </div>\r\n                                    <div class=\"g-pt-04\">\r\n                                        <div class=\"g-fs-07 g-lh-08 g-fw-400 g-grey4-clr\">by Neer Tech Solutions</div>\r\n                                    </div>\r\n                                    <div class=\"g-pt-08\">\r\n                                        <button type=\"button\" class=\"btn g-fs-06 g-yellow-bg text-center g-w-clr g-pt-02 g-pb-02 g-pl-04 g-pr-04 g-fw-700\">PRE PILOT</button>\r\n                                    </div>\r\n                                    <div class=\"g-pt-31 g-pb-12\">\r\n                                        <div class=\"g-fs-06\">Posted on 13 Aug 2020</div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    <!-- </div>         -->\r\n    <!-- <div class=\"col-xs-1\"></div> -->\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages-partial/footer/footer.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages-partial/footer/footer.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"g-p-drkbg g-pt-20 t-app-footer\">\r\n  <div class=\"container\">\r\n    <hr style=\"opacity: 0.4; border-width: 0.8px\" class=\"g-w-bg\" />\r\n    <div class=\"row g-pb-10\">\r\n      <div class=\"col-sm-6\">\r\n        <div class=\"footer-logo\">\r\n          <a>\r\n            <img\r\n              src=\"../assets/img/ftr_smart_city_logo.png\"\r\n              alt=\"Image\"\r\n              class=\"img-resposnive\"\r\n          /></a>\r\n        </div>\r\n      </div>\r\n      <div class=\"col-md-6 col-sm-12 text-right\">\r\n        <div class=\"footer-links g-pb-10\">\r\n          <a href=\"http://smartcities.gov.in/\" target=\"_blank\" class=\"g-fs-075\">\r\n            Smart Cities Mission\r\n          </a>\r\n          <a class=\"g-fs-075\">Privacy Policy</a>\r\n          <a class=\"g-fs-075\">Disclaimer</a>\r\n        </div>\r\n        <div class=\"ftr_social_icons\">\r\n          <a href=\"https://twitter.com/cityinx\" target=\"_blank\" class=\"g-fs-18 g-pl-12\"\r\n            ><i class=\"fa fa-twitter g-w-clr\" aria-hidden=\"true\"></i\r\n          ></a>\r\n          <a href=\"https://www.linkedin.com/company/cityinx/\" target=\"_blank\" class=\"g-fs-18 g-pl-12\"\r\n            ><i class=\"fa fa-linkedin g-w-clr\" aria-hidden=\"true\"></i\r\n          ></a>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"row g-pb-15 a-ftr-sct-3\">\r\n      <div class=\"col-md-4 col-sm-12\">\r\n        <div class=\"footer-links\">© All Rights Reserved, 2021</div>\r\n      </div>\r\n      <div class=\"col-md-4 col-sm-12\">\r\n        <div class=\"footer-links text-center\">Powered by NUIS</div>\r\n      </div>\r\n      <div class=\"col-md-4 col-sm-12\">\r\n        <div class=\"footer-links text-right\">\r\n          Designed & Developed by\r\n          <a class=\"g-m-0\" style=\"text-decoration: underline !important\"\r\n            >Frozen Iris.</a\r\n          >\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages-partial/header/header.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages-partial/header/header.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"g-white-bg t-app-header\">\r\n\t<div class=\"container g-pt-07 g-pb-02\">\r\n\t\t<div class=\"d-flex a-justify-space-between a-align-item-center hidden-xs g-pb-08\">\r\n\t\t\t<div class=\"cix-logo\">\r\n\t\t\t\t<img src=\"assets/img/home/cix-logo.png\" alt=\"Cityinx Logo\" class=\"g-w-100per\">\r\n\t\t\t</div>\r\n\t\t\t<div class=\"mohua-logo\">\r\n\t\t\t\t<a href=\"https://mohua.gov.in\" target=\"_blank\"><img src=\"assets/img/home/mohua-logo.png\" alt=\"Mohua Logo\" class=\"g-w-100per\"></a>\r\n\t\t\t</div>\r\n\t\t\t<div  class=\"d-flex\">\r\n\t\t\t\t<div class=\"scm-logo g-mr-28\">\r\n\t\t\t\t\t<a href=\"https://smartcities.gov.in\" target=\"_blank\"><img src=\"assets/img/home/scm-logo.jpeg\" alt=\"SCM Logo\" class=\"g-w-100per\"></a>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"forge-logo\">\r\n\t\t\t\t\t<img src=\"assets/img/home/forge-logo.png\" alt=\"Forge Logo\" class=\"g-w-100per\">\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div class=\"row hidden-xs\">\r\n\t\t\t<!-- <div class=\"col-sm-3\" [innerHTML]=\"logo$\"></div> -->\r\n\t\t\t<div class=\"col-sm-3\"></div>\r\n\t\t\t<div class=\"col-sm-5\">\r\n\t\t\t\t<div class=\"text-center pull-right\">\r\n\t\t\t\t\t<ul class=\"nav navbar-nav header-nav\">\r\n\t\t\t\t\t\t<li class=\"g-pl-10 g-pr-10 menu-item\">\r\n\t\t\t\t\t\t\t<a class=\"g-fs-07 g-black-clr g-bdrb-025 g-trans-brdr\" [routerLink]=\"['/home']\" [routerLinkActive]=\"['is-active']\">Home</a>\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t<ng-container *ngIf=\"currentUserData.isLoggedIn\">\r\n\t\t\t\t\t\t\t<ng-container *ngIf=\"currentUserData.userType == 'provider'\">\r\n\t\t\t\t\t\t\t\t<li class=\"g-pl-10 g-pr-10\">\r\n\t\t\t\t\t\t\t\t\t<a class=\"g-fs-07 g-black-clr g-bdrb-025 g-trans-brdr\" [routerLink]=\"['/provider/user/'] + currentUserData.slug + ['/dashboard']\" [routerLinkActive]=\"['is-active']\">Dashboard</a>\r\n\t\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t\t</ng-container>\r\n\t\t\t\t\t\t\t<ng-container *ngIf=\"currentUserData.userType == 'seeker'\">\r\n\t\t\t\t\t\t\t\t<li class=\"g-pl-10 g-pr-10\">\r\n\t\t\t\t\t\t\t\t\t<a class=\"g-fs-07 g-black-clr g-bdrb-025 g-trans-brdr\" [routerLink]=\"['/seeker/user/'] + currentUserData.slug + ['/dashboard']\" [routerLinkActive]=\"['is-active']\">Dashboard</a>\r\n\t\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t\t</ng-container>\r\n\t\t\t\t\t\t</ng-container>\r\n\t\t\t\t\t\t<li class=\"g-pl-10 g-pr-10 menu-item\">\r\n\t\t\t\t\t\t\t<a class=\"g-fs-07 g-black-clr g-bdrb-025 g-trans-brdr\" [routerLink]=\"['/discover']\" [routerLinkActive]=\"['is-active']\">Discover</a>\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t<li class=\"g-pl-10 g-pr-10 menu-item\">\r\n\t\t\t\t\t\t\t<a class=\"g-fs-07 g-black-clr g-bdrb-025 g-trans-brdr\" [routerLink]=\"['/cities']\" [routerLinkActive]=\"['is-active']\">Cities</a>\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"col-sm-4\">\r\n\t\t\t\t<div class=\"pull-right\">\r\n\t\t\t\t\t<ul class=\"nav navbar-nav sign-inout-menu\">\r\n\t\t\t\t\t\t<ng-container *ngIf=\"!currentUserData.isLoggedIn\">\r\n\t\t\t\t\t\t\t<li class=\"g-pl-10 g-pr-10\">\r\n\t\t\t\t\t\t\t\t<a class=\"g-fs-07 g-fw-400 g-black-clr g-bdrb-025 g-trans-brdr\" [routerLink]=\"['/help']\" [routerLinkActive]=\"['is-active']\">Resources & Support</a>\r\n\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t\t<li class=\"g-pl-10 g-pr-10\" *ngIf=\"!hideLogin\">\r\n\t\t\t\t\t\t\t\t<button class=\"login_cta_btn\" [routerLink]=\"['/login']\">Log In / Sign Up</button>\r\n\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t</ng-container>\r\n\t\t\t\t\t\t<ng-container *ngIf=\"currentUserData.isLoggedIn\">\r\n\t\t\t\t\t\t\t<app-notifier></app-notifier>\r\n\t\t\t\t\t\t\t<li class=\"g-pl-10 g-pr-10\">\r\n\t\t\t\t\t\t\t\t<div class=\"current-user dropdown g-pt-06\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"user-meta-avatar\">\r\n\t\t\t\t\t\t\t\t\t\t<img [src]=\"currentUserData.avatar\" alt=\"profile\" />\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t<span class=\"name dropdown-toggle\" data-toggle=\"dropdown\"\r\n\t\t\t\t\t\t\t\t\t\t>Hello <span class=\"g-fw-500\">{{ currentUserData.name.split(\" \")[0] | titlecase }}</span\r\n\t\t\t\t\t\t\t\t\t\t>&nbsp;\r\n\t\t\t\t\t\t\t\t\t\t<span class=\"caret\"></span>\r\n\t\t\t\t\t\t\t\t\t</span>\r\n\t\t\t\t\t\t\t\t\t<ul class=\"dropdown-menu\">\r\n\t\t\t\t\t\t\t\t\t\t<ng-container *ngIf=\"currentUserData.userType == 'provider'\">\r\n\t\t\t\t\t\t\t\t\t\t\t<li>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<a [routerLink]=\"['/provider/user/'] + currentUserData.slug\" [routerLinkActive]=\"['is-active']\"> View Profile </a>\r\n\t\t\t\t\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t\t\t\t\t</ng-container>\r\n\t\t\t\t\t\t\t\t\t\t<ng-container *ngIf=\"currentUserData.userType == 'seeker'\">\r\n\t\t\t\t\t\t\t\t\t\t\t<li>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<a [routerLink]=\"['/seeker/user/'] + currentUserData.slug\" [routerLinkActive]=\"['is-active']\"> View Profile </a>\r\n\t\t\t\t\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t\t\t\t\t</ng-container>\r\n\t\t\t\t\t\t\t\t\t\t<li><a [routerLink]=\"['/help']\" [routerLinkActive]=\"['is-active']\">Help</a></li>\r\n\t\t\t\t\t\t\t\t\t\t<li><a (click)=\"logout()\">Sign Out</a></li>\r\n\t\t\t\t\t\t\t\t\t</ul>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t</ng-container>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div class=\"visible-xs\">\r\n\t\t\t<nav class=\"navbar\">\r\n\t\t\t\t<div class=\"container-fluid\">\r\n\t\t\t\t\t<div class=\"navbar-header\">\r\n\t\t\t\t\t\t<button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#myNavbar\">\r\n\t\t\t\t\t\t\t<span class=\"icon-bar g-p-bg\"></span>\r\n\t\t\t\t\t\t\t<span class=\"icon-bar g-p-bg\"></span>\r\n\t\t\t\t\t\t\t<span class=\"icon-bar g-p-bg\"></span>\r\n\t\t\t\t\t\t</button>\r\n\t\t\t\t\t\t<a class=\"\"><img src=\"assets/img/SCMLogo.png\" alt=\"Logo\" /> </a>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"collapse navbar-collapse\" id=\"myNavbar\">\r\n\t\t\t\t\t\t<ul class=\"nav navbar-nav header-nav-collapse\">\r\n\t\t\t\t\t\t\t<li class=\"g-w-10per\">\r\n\t\t\t\t\t\t\t\t<a class=\"g-fs-07 g-pl-0 g-fs-400 g-black-clr g-bdrb-025 g-trans-brdr\" (click)=\"navigate()\">Home</a>\r\n\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t\t<li class=\"g-w-10per menu-item\">\r\n\t\t\t\t\t\t\t\t<a class=\"g-fs-07 g-pl-0 g-fs-400 g-black-clr g-bdrb-025 g-trans-brdr\" [routerLink]=\"['/discover-challenge-provider']\" [routerLinkActive]=\"['is-active']\">Discover</a>\r\n\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t\t<li class=\"g-w-10per menu-item\">\r\n\t\t\t\t\t\t\t\t<a class=\"g-fs-07 g-pl-0 g-fs-400 g-black-clr g-bdrb-025 g-trans-brdr\" [routerLink]=\"['/discover-cities']\" [routerLinkActive]=\"['is-active']\">Cities</a>\r\n\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t</ul>\r\n\t\t\t\t\t\t<ul class=\"nav navbar-nav navbar-right\">\r\n\t\t\t\t\t\t\t<li class=\"g-w-10per\" *ngIf=\"!currentUserData.isLoggedIn\">\r\n\t\t\t\t\t\t\t\t<a class=\"g-fs-07 g-pl-0 g-fs-400 g-black-clr g-bdrb-025 g-trans-brdr\" [routerLink]=\"['/login']\" [routerLinkActive]=\"['is-active']\">Login</a>\r\n\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t\t<li class=\"g-w-10per\" *ngIf=\"!currentUserData.isLoggedIn\">\r\n\t\t\t\t\t\t\t\t<a class=\"g-fs-07 g-pl-0 g-fs-400 g-black-clr g-bdrb-025 g-trans-brdr\" (click)=\"logout()\">Logout</a>\r\n\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t</ul>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</nav>\r\n\t\t</div>\r\n\t</div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/city-stats/city-stats.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/city-stats/city-stats.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"g-pl-20 g-pr-20\">\r\n    <div class=\"stat-search-box\">\r\n        <form #searchCityForm=\"ngForm\" (ngSubmit)=\"searchCity()\">\r\n            <div class=\"search-input-wrp\">\r\n                <div class=\"search-box\">\r\n                    <input type=\"text\" placeholder=\"Search for Smart city\" [(ngModel)]=\"cityKeyWord\"\r\n                        [ngModelOptions]=\"{standalone: true}\" (ngModelChange)=\"autoComplete($event)\" />\r\n                    <ng-container *ngIf='autoSuggestions?.data.length > 0 && cityKeyWord.length > 3'>\r\n                        <div class=\"search-auto-complete-wrp\">\r\n                            <ul>\r\n                                <ng-container *ngFor=\"let suggestion of autoSuggestions.data\">\r\n                                    <li>\r\n                                        <div (click)='searchAutoSuggestion(suggestion.name)'>\r\n                                            <i class=\"fa fa-search\" aria-hidden=\"true\"></i>&nbsp;&nbsp;\r\n                                            {{(suggestion.name)}}\r\n                                        </div>\r\n                                    </li>\r\n                                </ng-container>\r\n                            </ul>\r\n                        </div>\r\n                    </ng-container>\r\n                </div>\r\n            </div>\r\n            <button type=\"submit\">\r\n                <i class=\"fa fa-search\" aria-hidden=\"true\"></i>\r\n            </button>\r\n        </form>\r\n    </div>\r\n    <div class=\"stats-section\" *ngIf=\"!loading && cityData\">\r\n        <div class=\"g-mt-20\">\r\n            <div class=\"g-fs-16 g-fw-700 g-blue10-clr\">\r\n                {{cityData?.name}}\r\n            </div>\r\n        </div>\r\n        <div class=\"g-mt-10\">\r\n            <div class=\"counters-wrap\">\r\n                <div class=\"counter-item\">\r\n                    <div class=\"value\">\r\n                        {{cityData?.solutions.length}}\r\n                    </div>\r\n                    <div class=\"name\">\r\n                        Solutions\r\n                    </div>\r\n                </div>\r\n                <div class=\"counter-item\">\r\n                    <div class=\"value\">\r\n                        {{cityData?.challenges.length}}\r\n                    </div>\r\n                    <div class=\"name\">\r\n                        Challenges\r\n                    </div>\r\n                </div>\r\n                <div class=\"counter-item\">\r\n                    <div class=\"value\">\r\n                        {{cityData?.seekers.length}}\r\n                    </div>\r\n                    <div class=\"name\">\r\n                        Seekers\r\n                    </div>\r\n                </div>\r\n                <div class=\"counter-item\">\r\n                    <div class=\"value\">\r\n                        0\r\n                    </div>\r\n                    <div class=\"name\">\r\n                        Pilots\r\n                    </div>\r\n                </div>\r\n                <div class=\"counter-item\">\r\n                    <div class=\"value\">\r\n                        {{cityData?.providers.length}}\r\n                    </div>\r\n                    <div class=\"name\">\r\n                        Innovators\r\n                    </div>\r\n                </div>\r\n                <div class=\"counter-item\">\r\n                    <div class=\"value\">\r\n                        {{cityData?.challenge_sectors.length}}\r\n                    </div>\r\n                    <div class=\"name\">\r\n                        Challenge Sectors\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <div class=\"loader-section\" *ngIf=\"loading\">\r\n        <div class=\"g-mt-20\">\r\n            <ngx-skeleton-loader animation=\"progress\" [theme]=\"{\r\n                'border-radius': '2px',\r\n                height: '28px',\r\n                width: '55%'\r\n              }\">\r\n            </ngx-skeleton-loader>\r\n        </div>\r\n        <div class=\"g-mt-10\">\r\n            <div class=\"counters-wrap\">\r\n                <ng-container *ngFor=\"let item of [].constructor(6)\">\r\n                    <div class=\"counter-item\">\r\n                        <ngx-skeleton-loader animation=\"progress\" appearance=\"circle\" [theme]=\"{\r\n                            height: '60px',\r\n                            width: '50px',\r\n                            'border-radius': '2px',\r\n                            margin: '0px'\r\n                          }\">\r\n                        </ngx-skeleton-loader>\r\n                        <ngx-skeleton-loader animation=\"progress\" [theme]=\"{\r\n                            'border-radius': '2px',\r\n                            height: '14px',\r\n                            width: '70%',\r\n                            display: 'block',\r\n                            margin: '5px 0'\r\n                          }\">\r\n                        </ngx-skeleton-loader>\r\n                    </div>\r\n                </ng-container>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <div *ngIf=\"!loading && !cityData\">\r\n        <div class=\"g-fw-500 g-black7-clr g-mt-26\"> No results found </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/help/help.component.html":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/help/help.component.html ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"container-fluid l-help-sec-1-cont g-white-bg\">\r\n\t<div class=\"row\">\r\n\t\t<div class=\"col-xs-12 text-center g-pt-20\">\r\n\t\t\t<div class=\"g-fw-500 l-hlp-hdr g-mb-30\">Hello, how can we help you?</div>\r\n\t\t</div>\r\n\t\t<!-- <div class=\"col-xs-12 l-help-sec-1-inpt-cont g-mt-15 g-mb-15\">\r\n\t\t\t<div class=\"input-group g-maxw-600px l-help-sec-1-inpt-grp\">\r\n\t\t\t\t<input type=\"text\" class=\"form-control\" placeholder=\"| Search using keyword\" />\r\n\t\t\t\t<span class=\"input-group-btn\">\r\n\t\t\t\t\t<button class=\"btn btn-default\" type=\"button\"><i class=\"glyphicon glyphicon-search\"></i> Search</button>\r\n\t\t\t\t</span>\r\n\t\t\t</div>\r\n\t\t</div> -->\r\n\t\t<div class=\"col-xs-12\">\r\n\t\t\t<div class=\"text-center l-help-sec-1-tabs g-mb-20\">\r\n\t\t\t\t<ul class=\"nav nav-tabs\">\r\n\t\t\t\t\t<li class=\"active\">\r\n\t\t\t\t\t\t<a data-toggle=\"tab\" href=\"#resources\" class=\"l-hlp-tabs-title g-fw-500 g-fs-10\"\r\n\t\t\t\t\t\t\t><img src=\"../../../assets/img/help/getting_started_icon.svg\" alt=\"icon\" /><br />\r\n\t\t\t\t\t\t\tResources</a\r\n\t\t\t\t\t\t>\r\n\t\t\t\t\t</li>\r\n\t\t\t\t\t<li>\r\n\t\t\t\t\t\t<a data-toggle=\"tab\" href=\"#getstarted\" class=\"l-hlp-tabs-title g-fw-500 g-fs-10\"\r\n\t\t\t\t\t\t\t><img src=\"../../../assets/img/help/getting_started_icon.svg\" alt=\"icon\" /><br />\r\n\t\t\t\t\t\t\tGetting started</a\r\n\t\t\t\t\t\t>\r\n\t\t\t\t\t</li>\r\n\t\t\t\t\t<li>\r\n\t\t\t\t\t\t<a data-toggle=\"tab\" href=\"#faq\" class=\"l-hlp-tabs-title g-fw-500 g-fs-10\"\r\n\t\t\t\t\t\t\t><img src=\"../../../assets/img/help/faq_icon.svg\" alt=\"icon\" /><br />\r\n\t\t\t\t\t\t\tFAQs</a\r\n\t\t\t\t\t\t>\r\n\t\t\t\t\t</li>\r\n\t\t\t\t\t<li>\r\n\t\t\t\t\t\t<a data-toggle=\"tab\" href=\"#updates\" class=\"l-hlp-tabs-title g-fw-500 g-fs-10\"\r\n\t\t\t\t\t\t\t><img src=\"../../../assets/img/help/updates_icon.svg\" alt=\"icon\" /><br />\r\n\t\t\t\t\t\t\tProduct Updates</a\r\n\t\t\t\t\t\t>\r\n\t\t\t\t\t</li>\r\n\t\t\t\t\t<li>\r\n\t\t\t\t\t\t<a data-toggle=\"tab\" href=\"#glossary\" class=\"l-hlp-tabs-title g-fw-500 g-fs-10\"\r\n\t\t\t\t\t\t\t><img src=\"../../../assets/img/help/glossary.svg\" alt=\"icon\" /><br />\r\n\t\t\t\t\t\t\tGlossary</a\r\n\t\t\t\t\t\t>\r\n\t\t\t\t\t</li>\r\n\t\t\t\t\t<li>\r\n\t\t\t\t\t\t<a data-toggle=\"tab\" href=\"#query\" class=\"l-hlp-tabs-title g-fw-500 g-fs-10\"><img src=\"../../../assets/img/help/query_icon.svg\" alt=\"icon\" /><br />Query & support</a>\r\n\t\t\t\t\t</li>\r\n\t\t\t\t</ul>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n</div>\r\n<div class=\"tab-content g-mt-20 help-content-area g-pb-20\">\r\n\t<div id=\"resources\" class=\"tab-pane fade in active\">\r\n\t\t<div class=\"container\">\r\n\t\t\t<div class=\"row\">\r\n\t\t\t\t<div class=\"col-xs-3\">\r\n\t\t\t\t\t<div class=\"l-hlp-getting-start-col-1-hdr g-fw-700 g-opacity-06 g-pb-05\">Table of contents</div>\r\n\t\t\t\t\t<ul class=\"l-hlp-getting-start-col-1-ul g-mt-15\">\r\n\t\t\t\t\t\t<li class=\"g-pt-10 g-pb-10 g-cursor-pointer l-hlp-get-strd-li\" *ngFor=\"let item of resources_tb_arr; let i = index\">\r\n\t\t\t\t\t\t\t<a class=\"g-fs-08\" [ngClass]=\"{ active: get_selectedItem == item.id }\" pageScroll [href]=\"item.a_tag\" (click)=\"getstartedActionListner($event, item, i)\">{{ item.name }}</a>\r\n\t\t\t\t\t\t\t<img class=\"l-tble-right-chev-icon g-mt-03\" *ngIf=\"item.active == true\" src=\"assets/img/help/right-chevron.svg\" alt=\"right arrow\" />\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"col-xs-9\">\r\n\t\t\t\t\t<div class=\"g-pt-15 g-pb-15\">\r\n\t\t\t\t\t\t<div class=\"l-hlp-getting-start-col-2-hdr g-fw-500 g-fs-10 g-pl-10\" id=\"policies\">\r\n\t\t\t\t\t\t\t<div class=\"resouces_img_btn_wrapper\">\r\n\t\t\t\t\t\t\t\t<div class=\"resouces_img_btn_cont\">\r\n\t\t\t\t\t\t\t\t\t<a href=\"assets/img/help/challenge_brief_pdf.pdf\" target=\"_blank\">\r\n\t\t\t\t\t\t\t\t\t\t<img src=\"assets/img/help/resources_chall_brief.png\" alt=\"challenge_brief\">\r\n\t\t\t\t\t\t\t\t\t  </a>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"resouces_img_btn_cont\">\r\n\t\t\t\t\t\t\t\t\t<a href=\"assets/img/help/pilot_pdf.pdf\" target=\"_blank\">\r\n\t\t\t\t\t\t\t\t\t\t<img src=\"assets/img/help/resources_pil_req.png\" alt=\"pilot_requirements\">\r\n\t\t\t\t\t\t\t\t\t  </a>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"resouces_img_btn_cont\">\r\n\t\t\t\t\t\t\t\t\t<a href=\"assets/img/help/work_order_pdf.pdf\" target=\"_blank\">\r\n\t\t\t\t\t\t\t\t\t\t<img src=\"assets/img/help/resources_work_order.png\" alt=\"work_order\">\r\n\t\t\t\t\t\t\t\t\t  </a>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\r\n\t\t\t\t\t\t</div>\r\n\r\n\r\n\t\t\t\t\t\t<div class=\"l-hlp-getting-start-col-2-hdr g-fw-500 g-fs-10 g-pl-10 g-mt-25\" id=\"model-documents\"></div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n\t<div id=\"getstarted\" class=\"tab-pane fade\">\r\n\t\t<div class=\"container\">\r\n\t\t\t<div class=\"row\">\r\n\t\t\t\t<div class=\"col-xs-3\">\r\n\t\t\t\t\t<div class=\"l-hlp-getting-start-col-1-hdr g-fw-700 g-opacity-06 g-pb-05\">Table of contents</div>\r\n\t\t\t\t\t<ul class=\"l-hlp-getting-start-col-1-ul g-mt-15\">\r\n\t\t\t\t\t\t<li class=\"g-pt-10 g-pb-10 g-cursor-pointer l-hlp-get-strd-li\" *ngFor=\"let item of getting_started_tb_arr; let i = index\">\r\n\t\t\t\t\t\t\t<a class=\"g-fs-08\" [ngClass]=\"{ active: get_selectedItem == item.id }\" pageScroll [href]=\"item.a_tag\" (click)=\"getstartedActionListner($event, item, i)\">{{ item.name }}</a>\r\n\t\t\t\t\t\t\t<img class=\"l-tble-right-chev-icon g-mt-03\" *ngIf=\"item.active == true\" src=\"assets/img/help/right-chevron.svg\" alt=\"right arrow\" />\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t\t<div class=\"dwnld_smrt_pro\">\r\n\t\t\t\t\t\t<a href=\"assets/img/help/smart_procure_doc.pdf\" download=\"smart_procure_doc\">Download Smartprocure</a>\r\n\t\t\t\t\t\t<div class=\"dwnld_smrt_pro_lbl\">* Download size 2MB</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"col-xs-9\">\r\n\t\t\t\t\t<div class=\"g-white-bg l-hlp-getting-start-col-2-cont g-pt-15 g-pb-15\">\r\n\t\t\t\t\t\t<div class=\"l-hlp-getting-start-col-2-hdr g-fw-500 g-fs-10 g-pl-10\" id=\"gett-started-1\">What is City Innovation eXchange?</div>\r\n\t\t\t\t\t\t<div class=\"g-pl-10 g-pr-10 g-fs-07 l-hlp-getting-start-desc g-mt-08\">\r\n\t\t\t\t\t\t\tCity Innovation eXchange (CiX), is an Open Innovation Platform that enables City Administrators and Innovators & Startups to collaborate and co-create innovative & technologically\r\n\t\t\t\t\t\t\tadvanced solutions to address city challenges. The platform helps users to host challenges, discover solutions, run pilots, and thereby co-create solutions.\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"g-pl-10 g-pr-10 g-pt-10\">\r\n\t\t\t\t\t\t\t<iframe\r\n\t\t\t\t\t\t\t\tclass=\"g-w-100per\"\r\n\t\t\t\t\t\t\t\theight=\"315\"\r\n\t\t\t\t\t\t\t\tsrc=\"https://www.youtube.com/embed/kMnQgqPmo6E\"\r\n\t\t\t\t\t\t\t\tframeborder=\"0\"\r\n\t\t\t\t\t\t\t\tallow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\"\r\n\t\t\t\t\t\t\t\tallowfullscreen\r\n\t\t\t\t\t\t\t></iframe>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"l-hlp-getting-start-col-2-hdr g-fw-500 g-fs-10 g-pl-10 g-mt-25\" id=\"gett-started-2\">How does CiX work?</div>\r\n\t\t\t\t\t\t<div class=\"g-pl-10 g-pr-10 g-fs-07 l-hlp-getting-start-desc g-mt-08\">\r\n\t\t\t\t\t\t\tCities can host challenges on the platform, inviting innovators to apply with their solutions. On identifying relevant solutions, cities can raise an expression of interest requesting\r\n\t\t\t\t\t\t\tthe innovators to share a proposal for pilot implementation. Cities evaluate the proposals and select the solutions for running pilots—to validate the solution. Cities can even choose to\r\n\t\t\t\t\t\t\tprocure the solution, based on the solution’s maturity and how well the solution fits the city’s requirements.\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"g-pl-10 g-pr-10 g-pt-10\">\r\n\t\t\t\t\t\t\t<iframe\r\n\t\t\t\t\t\t\t\tclass=\"g-w-100per\"\r\n\t\t\t\t\t\t\t\theight=\"315\"\r\n\t\t\t\t\t\t\t\tsrc=\"https://www.youtube.com/embed/JmjPDOYw7Ak\"\r\n\t\t\t\t\t\t\t\tframeborder=\"0\"\r\n\t\t\t\t\t\t\t\tallow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\"\r\n\t\t\t\t\t\t\t\tallowfullscreen\r\n\t\t\t\t\t\t\t></iframe>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n\t<div id=\"faq\" class=\"tab-pane fade\">\r\n\t\t<div class=\"container\">\r\n\t\t\t<div class=\"row\">\r\n\t\t\t\t<div class=\"col-xs-3\">\r\n\t\t\t\t\t<div class=\"l-hlp-getting-start-col-1-hdr g-fw-700 g-opacity-06 g-pb-05\">Table of contents</div>\r\n\t\t\t\t\t<ul class=\"l-hlp-getting-start-col-1-ul g-mt-15\">\r\n\t\t\t\t\t\t<li class=\"g-pt-10 g-pb-10 l-hlp-get-strd-li g-cursor-pointer\" *ngFor=\"let item of faq_tb_arr; let i = index\">\r\n\t\t\t\t\t\t\t<a class=\"g-fs-08\" [ngClass]=\"{ active: faq_selectedItem == item.id }\" pageScroll [href]=\"item.a_tag\" (click)=\"faqActionListner($event, item, i)\">{{ item.name }}</a>\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"col-xs-9\">\r\n\t\t\t\t\t<div class=\"g-white-bg l-hlp-getting-start-col-2-cont g-pt-15 g-pb-15 l-hlp-faq-cont\">\r\n\t\t\t\t\t\t<div *ngFor=\"let faq_item of faqs; let i = index\">\r\n\t\t\t\t\t\t\t<div class=\"l-hlp-getting-start-col-2-hdr g-fw-500 g-fs-10 g-pl-10\" [id]=\"faq_item.section_id\">{{ faq_item.section_name }}</div>\r\n\t\t\t\t\t\t\t<div class=\"panel-group g-mt-15\" id=\"accordion\">\r\n\t\t\t\t\t\t\t\t<div class=\"panel panel-default\" *ngFor=\"let item of faq_item.content\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"panel-heading\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"g-fs-09 l-hlp-getting-start-col-2-acc-hdr g-fs-09\" data-toggle=\"collapse\" [attr.href]=\"'#collapse' + item.id\" (click)=\"showIcon(item)\">\r\n\t\t\t\t\t\t\t\t\t\t\t{{ item.title }}\r\n\t\t\t\t\t\t\t\t\t\t\t<i class=\"l-hlp-getting-start-col-2-acc-icon\" *ngIf=\"item.status == false\"><img src=\"../../../assets/img/help/up_chevron.svg\" alt=\"icon\" /></i>\r\n\t\t\t\t\t\t\t\t\t\t\t<i class=\"l-hlp-getting-start-col-2-acc-icon\" *ngIf=\"item.status != false\"><img src=\"../../../assets/img/help/down_chevron.svg\" alt=\"icon\" /></i>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t<div [id]=\"'collapse' + item.id\" class=\"panel-collapse collapse\">\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"panel-body g-fw-400 g-fs-08\">\r\n\t\t\t\t\t\t\t\t\t\t\t<ul *ngIf=\"item.desc_type == 'ul_li'\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t<li *ngFor=\"let list_itm of item.li_arr\">{{ list_itm.name }}</li>\r\n\t\t\t\t\t\t\t\t\t\t\t</ul>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"panel-body g-fw-400 g-fs-08\" *ngIf=\"item.desc_type == 'para'\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t{{ item.desc }}\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<!-- <div class=\"panel panel-default\">\r\n                                    <div class=\"panel-heading\">\r\n                                        <div class=\"g-fs-09 l-hlp-getting-start-col-2-acc-hdr g-fs-09\"\r\n                                            data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapse2\">\r\n                                            What are steps from Challenge to Procurement\r\n                                            <i class=\"l-hlp-getting-start-col-2-acc-icon\"><img\r\n                                                    src=\"../../../assets/img/help/up_chevron.svg\" alt=\"icon\"></i>\r\n                                            <i class=\"l-hlp-getting-start-col-2-acc-icon\"><img\r\n                                                    src=\"../../../assets/img/help/down_chevron.svg\" alt=\"icon\"></i>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id=\"collapse2\" class=\"panel-collapse collapse\">\r\n                                        <div class=\"panel-body g-fw-400 g-fs-08\">\r\n                                            <ul>\r\n                                                <li>Challenge curation</li>\r\n                                                <li>Solution discovery</li>\r\n                                                <li>Innovation co-creation</li>\r\n                                                <li>Solution validation</li>\r\n                                                <li>Solution certification</li>\r\n                                                <li>Commercial procurement</li>\r\n                                            </ul>\r\n                                        </div>\r\n                                    </div>\r\n                                </div> -->\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n\t<div id=\"updates\" class=\"tab-pane fade\">\r\n\t\t<div class=\"container\">\r\n\t\t\t<div class=\"row\">\r\n\t\t\t\t<div class=\"col-xs-3\">\r\n\t\t\t\t\t<div class=\"l-hlp-getting-start-col-1-hdr g-fw-700 g-opacity-06 g-pb-15\">Table of contents</div>\r\n\t\t\t\t\t<ul class=\"l-hlp-getting-start-col-1-ul g-mt-15\">\r\n\t\t\t\t\t\t<li class=\"g-pt-10 g-pb-10\">\r\n\t\t\t\t\t\t\t<a class=\"g-fw-700 g-fs-08\" pageScroll href=\"#v1\">V1.0</a>\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t<li class=\"g-pt-10 g-pb-10\">\r\n\t\t\t\t\t\t\t<a class=\"g-fw-700 g-fs-08\" pageScroll href=\"#v2\">V2.0</a>\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"col-xs-9\">\r\n\t\t\t\t\t<div class=\"g-white-bg l-hlp-getting-start-col-2-cont g-pt-15 g-pb-15\">\r\n\t\t\t\t\t\t<div class=\"g-pl-10 g-pr-10\">\r\n\t\t\t\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t\t\t<div class=\"col-xs-6\" id=\"v1\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"g-fw-500 g-fs-10\">V1.0</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<!-- <div class=\"col-xs-6\">\r\n                                    <div class=\"g-fs-08\"><span\r\n                                            class=\"g-fs-07 l-hlp-getting-start-prod-pub-date g-mr-10\">Realesed\r\n                                            on</span>24 Feb 2021</div>\r\n                                </div> -->\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t<ul class=\"l-hlp-getting-start-prod-ul g-pl-10 g-mt-10\">\r\n\t\t\t\t\t\t\t\t<li class=\"g-fs-07\">A simple and smooth Sign Up/Log In process was established to start the onboarding of stakeholders of two kinds - City Administrators and Innovators.</li>\r\n\t\t\t\t\t\t\t\t<li class=\"g-fs-07\">\r\n\t\t\t\t\t\t\t\t\tAn equally simple and smooth Profile creation process that collects and saves every necessary data from the user was established. It was designed in a way the questions are never\r\n\t\t\t\t\t\t\t\t\tintrusive or demand a lot of thinking from the user.\r\n\t\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t\t\t<li class=\"g-fs-07\">The process to catalogue solutions according to the current maturity, providers’ location and team size were also established in this version.</li>\r\n\t\t\t\t\t\t\t</ul>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"g-pl-10 g-pr-10\">\r\n\t\t\t\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t\t\t<div class=\"col-xs-6\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"g-fw-500 g-fs-10\" id=\"v2\">V2.0</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<!-- <div class=\"col-xs-6\">\r\n                                    <div class=\"g-fs-08\"><span\r\n                                            class=\"g-fs-07 l-hlp-getting-start-prod-pub-date g-mr-10\">Realesed\r\n                                            on</span>24 Feb 2021</div>\r\n                                </div> -->\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t<ul class=\"l-hlp-getting-start-prod-ul g-pl-10 g-mt-10\">\r\n\t\t\t\t\t\t\t\t<li class=\"g-fs-07\">\r\n\t\t\t\t\t\t\t\t\tA process to profile every city with elaborate details was established. The CEO of the city or other administrators could add details ranging from the vision, unique challenges to\r\n\t\t\t\t\t\t\t\t\tbudget at disposal and the area based development.\r\n\t\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t\t\t<li class=\"g-fs-07\">\r\n\t\t\t\t\t\t\t\t\tA straight forward process to create/anchor a challenge was established. The Challengers could create challenges with a filter for sectors and publish them for the producers to see\r\n\t\t\t\t\t\t\t\t\tand pitch a solution.\r\n\t\t\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t\t\t<li class=\"g-fs-07\">City administrators could also create their profile with every necessary information in this version.</li>\r\n\t\t\t\t\t\t\t\t<li class=\"g-fs-07\">A dedicated help section to help users with every potential block in the website was also established.</li>\r\n\t\t\t\t\t\t\t</ul>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n\t<div id=\"glossary\" class=\"tab-pane fade\">\r\n\t\t<div class=\"container\">\r\n\t\t\t<div class=\"row\">\r\n\t\t\t\t<div class=\"col-xs-3\">\r\n\t\t\t\t\t<div class=\"l-hlp-getting-start-col-1-hdr g-fw-700 g-opacity-06 g-pb-05\">Table of contents</div>\r\n\t\t\t\t\t<ul class=\"l-hlp-getting-start-col-1-ul g-mt-15\">\r\n\t\t\t\t\t\t<li class=\"g-pt-10 g-pb-10 l-hlp-get-strd-li g-cursor-pointer\" *ngFor=\"let item of glossary_tb_arr; let i = index\">\r\n\t\t\t\t\t\t\t<a class=\"g-fs-08\" [ngClass]=\"{ active: faq_selectedItem == item.id }\" pageScroll [href]=\"item.a_tag\" (click)=\"glossaryActionListner($event, item, i)\">{{ item.name }}</a>\r\n\t\t\t\t\t\t</li>\r\n\t\t\t\t\t\t<!-- <li class=\"g-pt-10 g-pb-10\">\r\n                            <a class=\"g-fw-700 g-fs-08\" pageScroll href=\"#challenges\">Challenges</a>\r\n                        </li>\r\n                        <li class=\"g-pt-10 g-pb-10\">\r\n                            <a class=\"g-fw-700 g-fs-08\" pageScroll href=\"#cityadmin\">City Administrator\r\n                            </a>\r\n                        </li>\r\n                        <li class=\"g-pt-10 g-pb-10\">\r\n                            <a class=\"g-fw-700 g-fs-08\" pageScroll href=\"#innovator\">Innovator\r\n                            </a>\r\n                        </li>\r\n                        <li class=\"g-pt-10 g-pb-10\">\r\n                            <a class=\"g-fw-700 g-fs-08\" pageScroll href=\"#anchor\">Anchor Process\r\n                            </a>\r\n                        </li> -->\r\n\t\t\t\t\t</ul>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"col-xs-9\">\r\n\t\t\t\t\t<div class=\"g-white-bg l-hlp-getting-start-col-2-cont g-pb-15\">\r\n\t\t\t\t\t\t<div class=\"l-hlp-get-started-glos-cont g-pt-15 g-pb-15\" id=\"solution\">\r\n\t\t\t\t\t\t\t<div class=\"l-hlp-getting-start-col-2-hdr g-fw-500 g-fs-10 g-pl-10\">What is a Solution?</div>\r\n\t\t\t\t\t\t\t<div class=\"g-fs-07 l-hlp-getting-start-desc g-mt-08 g-pl-10 g-pr-10\">\r\n\t\t\t\t\t\t\t\tInnovative or technologically advanced products/services that are built by innovators (startups/MSME/ individuals like professionals, freelancers, academicians or students) can\r\n\t\t\t\t\t\t\t\tpotentially address/solve the challenges faced by the city in an efficient, reliable, and cost effective manner.\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"l-hlp-get-started-glos-cont g-pt-15 g-pb-15\" id=\"challenges\">\r\n\t\t\t\t\t\t\t<div class=\"l-hlp-getting-start-col-2-hdr g-fw-500 g-fs-10 g-pl-10\">What are Challenges?</div>\r\n\t\t\t\t\t\t\t<div class=\"g-fs-07 l-hlp-getting-start-desc g-mt-08 g-pl-10 g-pr-10\">\r\n\t\t\t\t\t\t\t\tPressing problems faced by the end-users viz citizens or city administrators of that city. These are hosted by the cities facing them. Innovators can tag their solutions under these\r\n\t\t\t\t\t\t\t\tchallenges in the platform for quick discoverability.\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"l-hlp-get-started-glos-cont g-pt-15 g-pb-15\" id=\"cityadmin\">\r\n\t\t\t\t\t\t\t<div class=\"l-hlp-getting-start-col-2-hdr g-fw-500 g-fs-10 g-pl-10\">Who is a City Administrator?</div>\r\n\t\t\t\t\t\t\t<div class=\"g-fs-07 l-hlp-getting-start-desc g-mt-08 g-pl-10 g-pr-10\">City Administrator is a representative of a city (viz CEOs, Commissioners, Senior Executives)</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"l-hlp-get-started-glos-cont g-pt-15 g-pb-15\" id=\"innovator_g\">\r\n\t\t\t\t\t\t\t<div class=\"l-hlp-getting-start-col-2-hdr g-fw-500 g-fs-10 g-pl-10\">Who is an Innovator?</div>\r\n\t\t\t\t\t\t\t<div class=\"g-fs-07 l-hlp-getting-start-desc g-mt-08 g-pl-10 g-pr-10\">\r\n\t\t\t\t\t\t\t\tStartups, MSME, Individuals vis professionals, freelancers, academicians, and students who provide solutions to a particular challenge or a variety of challenges.\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"l-hlp-get-started-glos-cont g-pt-15 g-pb-15\" id=\"anchor\">\r\n\t\t\t\t\t\t\t<div class=\"l-hlp-getting-start-col-2-hdr g-fw-500 g-fs-10 g-pl-10\">What is the Anchor process?</div>\r\n\t\t\t\t\t\t\t<div class=\"g-fs-07 l-hlp-getting-start-desc g-mt-08 g-pl-10 g-pr-10\">\r\n\t\t\t\t\t\t\t\tWhen a City Administrator anchors a challenge he/she is indicating that his/her city has that particular challenge and is looking for solutions to address it. While anchoring a\r\n\t\t\t\t\t\t\t\tchallenge, the City Administrator has to provide the details of the challenge in the context of how it is perceived by the respective city. This enables Providers to build/customise\r\n\t\t\t\t\t\t\t\tand furnish information about their solutions\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n\t<div id=\"query\" class=\"tab-pane fade\">\r\n\t\t<div class=\"container\">\r\n\t\t\t<div class=\"row\">\r\n\t\t\t\t<div class=\"col-sm-5\">\r\n\t\t\t\t\t<ng-container *ngIf=\"loggedInUser.isLoggedIn; else notLoggedIn\">\r\n\t\t\t\t\t\t<div class=\"g-white-bg l-hlp-getting-start-col-2-cont g-p-15 g-mb-15\">\r\n\t\t\t\t\t\t\t<div class=\"l-hlp-getting-start-col-2-hdr g-fw-500 g-fs-10\">Get in touch</div>\r\n\t\t\t\t\t\t\t<div class=\"l-hlp-getting-start-cnt-frm-msg-cont g-p-15\" *ngIf=\"show_msg\">\r\n\t\t\t\t\t\t\t\t<div class=\"g-disp-inlblock\">\r\n\t\t\t\t\t\t\t\t\t<img src=\"../../../assets/img/help/success_icon.svg\" alt=\"icon\" />\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"g-disp-inlblock\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"g-fs-09\">Your query is submitted successfully.</div>\r\n\t\t\t\t\t\t\t\t\t<div class=\"g-fs-07\">\r\n\t\t\t\t\t\t\t\t\t\tAs the platform is under development, you’ll not get an acknolwedgement email. Do expect a response to your submission over an email or call by the next working day.\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t<form class=\"g-mt-15 l-get-strd-hlp-cont-frm\" [formGroup]=\"contactForm\" (ngSubmit)=\"onSubmit()\">\r\n\t\t\t\t\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"col-sm-6 form-group\">\r\n\t\t\t\t\t\t\t\t\t\t<label class=\"g-fs-07 g-fw-400 l-hlp-cont-labl g-opacity-06\" for=\"inputError2\">First Name *</label>\r\n\t\t\t\t\t\t\t\t\t\t<input\r\n\t\t\t\t\t\t\t\t\t\t\tclass=\"form-control g-blue8-bg\"\r\n\t\t\t\t\t\t\t\t\t\t\ttype=\"text\"\r\n\t\t\t\t\t\t\t\t\t\t\tplaceholder=\"ex:\"\r\n\t\t\t\t\t\t\t\t\t\t\tformControlName=\"fname\"\r\n\t\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{\r\n\t\t\t\t\t\t\t\t\t\t\t\terror: (contactFormControl.fname.touched || isSubmitted) && contactFormControl.fname?.errors\r\n\t\t\t\t\t\t\t\t\t\t\t}\"\r\n\t\t\t\t\t\t\t\t\t\t/>\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"err-resp\">\r\n\t\t\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(contactFormControl.fname.touched || isSubmitted) && contactFormControl.fname.errors?.required\">\r\n\t\t\t\t\t\t\t\t\t\t\t\tFirst name is required\r\n\t\t\t\t\t\t\t\t\t\t\t</span>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t<div class=\"col-sm-6 form-group\">\r\n\t\t\t\t\t\t\t\t\t\t<label class=\"g-fs-07 g-fw-400 l-hlp-cont-labl g-opacity-06\" for=\"inputError2\">Second Name *</label>\r\n\t\t\t\t\t\t\t\t\t\t<input\r\n\t\t\t\t\t\t\t\t\t\t\tclass=\"form-control g-blue8-bg\"\r\n\t\t\t\t\t\t\t\t\t\t\ttype=\"text\"\r\n\t\t\t\t\t\t\t\t\t\t\tplaceholder=\"ex:\"\r\n\t\t\t\t\t\t\t\t\t\t\tformControlName=\"lname\"\r\n\t\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{\r\n\t\t\t\t\t\t\t\t\t\t\t\terror: (contactFormControl.lname.touched || isSubmitted) && contactFormControl.lname?.errors\r\n\t\t\t\t\t\t\t\t\t\t\t}\"\r\n\t\t\t\t\t\t\t\t\t\t/>\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"err-resp\">\r\n\t\t\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(contactFormControl.lname.touched || isSubmitted) && contactFormControl.lname.errors?.required\">\r\n\t\t\t\t\t\t\t\t\t\t\t\tLast name is required\r\n\t\t\t\t\t\t\t\t\t\t\t</span>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t<label class=\"g-fs-07 g-fw-400 l-hlp-cont-labl g-opacity-06\" for=\"inputError2\">Email *</label>\r\n\t\t\t\t\t\t\t\t\t<input\r\n\t\t\t\t\t\t\t\t\t\tclass=\"form-control g-blue8-bg\"\r\n\t\t\t\t\t\t\t\t\t\ttype=\"text\"\r\n\t\t\t\t\t\t\t\t\t\tplaceholder=\"ex:\"\r\n\t\t\t\t\t\t\t\t\t\tformControlName=\"email\"\r\n\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{\r\n\t\t\t\t\t\t\t\t\t\t\terror: (contactFormControl.email.touched || isSubmitted) && contactFormControl.email?.errors\r\n\t\t\t\t\t\t\t\t\t\t}\"\r\n\t\t\t\t\t\t\t\t\t/>\r\n\t\t\t\t\t\t\t\t\t<div class=\"err-resp\">\r\n\t\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(contactFormControl.email.touched || isSubmitted) && contactFormControl.email.errors?.required\">\r\n\t\t\t\t\t\t\t\t\t\t\tEmail is required\r\n\t\t\t\t\t\t\t\t\t\t</span>\r\n\t\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(contactFormControl.email.touched || isSubmitted) && contactFormControl.email.errors?.email\">\r\n\t\t\t\t\t\t\t\t\t\t\tEnter valid email\r\n\t\t\t\t\t\t\t\t\t\t</span>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t<label class=\"g-fs-07 g-fw-400 l-hlp-cont-labl g-opacity-06\" for=\"inputError2\">Phone *</label>\r\n\t\t\t\t\t\t\t\t\t<input\r\n\t\t\t\t\t\t\t\t\t\tclass=\"form-control g-blue8-bg\"\r\n\t\t\t\t\t\t\t\t\t\ttype=\"number\"\r\n\t\t\t\t\t\t\t\t\t\tplaceholder=\"ex:\"\r\n\t\t\t\t\t\t\t\t\t\tformControlName=\"phone\"\r\n\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{\r\n\t\t\t\t\t\t\t\t\t\t\terror: (contactFormControl.phone.touched || isSubmitted) && contactFormControl.phone?.errors\r\n\t\t\t\t\t\t\t\t\t\t}\"\r\n\t\t\t\t\t\t\t\t\t/>\r\n\t\t\t\t\t\t\t\t\t<div class=\"err-resp\">\r\n\t\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(contactFormControl.phone.touched || isSubmitted) && contactFormControl.phone.errors?.required\">\r\n\t\t\t\t\t\t\t\t\t\t\tPhone is required\r\n\t\t\t\t\t\t\t\t\t\t</span>\r\n\t\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(contactFormControl.phone.touched || isSubmitted) && contactFormControl.phone.errors?.pattern\">\r\n\t\t\t\t\t\t\t\t\t\t\tEnter valid phone\r\n\t\t\t\t\t\t\t\t\t\t</span>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t<label class=\"g-fs-07 g-fw-400 l-hlp-cont-labl g-opacity-06\" for=\"inputError2\">How may we assist you ? *</label>\r\n\t\t\t\t\t\t\t\t\t<input\r\n\t\t\t\t\t\t\t\t\t\tclass=\"form-control g-blue8-bg\"\r\n\t\t\t\t\t\t\t\t\t\ttype=\"text\"\r\n\t\t\t\t\t\t\t\t\t\tplaceholder=\"ex:\"\r\n\t\t\t\t\t\t\t\t\t\tformControlName=\"shortdesc\"\r\n\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{\r\n\t\t\t\t\t\t\t\t\t\t\terror: (contactFormControl.shortdesc.touched || isSubmitted) && contactFormControl.shortdesc?.errors\r\n\t\t\t\t\t\t\t\t\t\t}\"\r\n\t\t\t\t\t\t\t\t\t/>\r\n\t\t\t\t\t\t\t\t\t<div class=\"err-resp\">\r\n\t\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(contactFormControl.shortdesc.touched || isSubmitted) && contactFormControl.shortdesc.errors?.required\">\r\n\t\t\t\t\t\t\t\t\t\t\tShort description is required\r\n\t\t\t\t\t\t\t\t\t\t</span>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"form-group\">\r\n\t\t\t\t\t\t\t\t\t<label class=\"g-fs-07 g-fw-400 l-hlp-cont-labl g-opacity-06\" for=\"inputError2\">Elaborate on details about your question (optional)</label>\r\n\t\t\t\t\t\t\t\t\t<textarea class=\"form-control g-blue8-bg\" rows=\"5\" id=\"comment\" formControlName=\"longdesc\"></textarea>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"g-pb-10 g-mt-10\">\r\n\t\t\t\t\t\t\t\t\t<button class=\"btn g-p-bg g-w-clr g-fs-08 g-pt-04 g-pb-04 g-pl-25 g-pr-25\" type=\"submit\">Submit</button>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</form>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</ng-container>\r\n\t\t\t\t\t<ng-template #notLoggedIn>\r\n\t\t\t\t\t\t<p class=\"g-fs-09\"><span class=\"g-p-clr g-cursor-pointer\" routerLink=\"/login\" [queryParams]=\"{ redirectURL: '/help' }\">Login</span> to submit queries</p>\r\n\t\t\t\t\t</ng-template>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"col-sm-7\">\r\n\t\t\t\t\t<div class=\"g-pl-30\">\r\n\t\t\t\t\t\t<div class=\"l-hlp-getting-start-col-2-hdr g-fw-500 g-fs-10\">Reach Out</div>\r\n\t\t\t\t\t\t<div class=\"g-fs-08 l-get-star-cont-col-2-text g-pt-08 g-pb-08\">Call for support</div>\r\n\t\t\t\t\t\t<div class=\"g-mt-15 g-pb-15 l-get-start-cont-col-2-cont\">\r\n\t\t\t\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t\t\t<div class=\"col-sm-7\">\r\n\t\t\t\t\t\t\t\t\t<div>\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"g-disp-inlblock l-get-start-cont-icn-cont\">\r\n\t\t\t\t\t\t\t\t\t\t\t<img src=\"../../../assets/img/help/cnt_call_icon.svg\" alt=\"icon\" />\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"g-disp-inlblock g-pl-10\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"g-fs-08\">Forge Innovation & Ventures</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div><a class=\"g-fs-07 l-get-start-cont-us-link g-opacity-07\" href=\"tel:+917397798921\">+91-73977 98921</a></div>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"col-sm-5 text-right\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"g-fs-07 l-get-start-cont-col-2-text g-opacity-05\">M T W T F S 10AM - 06PM</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"g-mt-15 g-pb-15 l-get-start-cont-col-2-cont\">\r\n\t\t\t\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t\t\t<div class=\"col-sm-7\">\r\n\t\t\t\t\t\t\t\t\t<div>\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"g-disp-inlblock l-get-start-cont-icn-cont\">\r\n\t\t\t\t\t\t\t\t\t\t\t<img src=\"../../../assets/img/help/cnt_call_icon.svg\" alt=\"icon\" />\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"g-disp-inlblock g-pl-10\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"g-fs-08\">National Institute of Urban Affairs (NIUA)</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div><a class=\"g-fs-07 l-get-start-cont-us-link g-opacity-07\" href=\"tel:+919711669779\">+91-97116 69779</a></div>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"col-sm-5 text-right\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"g-fs-07 l-get-start-cont-col-2-text g-opacity-05\">M T W T F S 10AM - 06PM</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"g-mt-15 g-pb-15 l-get-start-cont-col-2-cont\">\r\n\t\t\t\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t\t\t<div class=\"col-sm-6\">\r\n\t\t\t\t\t\t\t\t\t<div>\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"g-disp-inlblock l-get-start-cont-icn-cont\">\r\n\t\t\t\t\t\t\t\t\t\t\t<img src=\"../../../assets/img/help/cnt_mail_icon.svg\" alt=\"icon\" />\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"g-disp-inlblock g-pl-10\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"g-fs-08\">Email for support</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div><a class=\"g-fs-07 l-get-start-cont-us-link g-opacity-07\" href=\"mailto:cix@forgeforward.in\">cix@forgeforward.in</a></div>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"col-sm-6 text-right\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"g-fs-07 l-get-start-cont-col-2-text g-opacity-05\">Expected response time of 3 hours</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"g-mt-15 g-pb-15 l-get-start-cont-col-2-cont\">\r\n\t\t\t\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t\t\t<div class=\"col-sm-7\">\r\n\t\t\t\t\t\t\t\t\t<div>\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"g-disp-inlblock l-get-start-cont-icn-cont\">\r\n\t\t\t\t\t\t\t\t\t\t\t<img src=\"../../../assets/img/help/cnt_mail_icon.svg\" alt=\"icon\" />\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"g-disp-inlblock g-pl-10\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"g-fs-08\">Tech support & feedback</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div><a class=\"g-fs-07 l-get-start-cont-us-link g-opacity-07\" href=\"mailto:cixtechsupport@forgeforward.in\">cixtechsupport@forgeforward.in</a></div>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"col-sm-5 text-right\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"g-fs-07 l-get-start-cont-col-2-text g-opacity-05\"></div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"g-mt-15 g-pb-15 l-get-start-cont-col-2-cont\">\r\n\t\t\t\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t\t\t<div class=\"col-sm-6\">\r\n\t\t\t\t\t\t\t\t\t<div>\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"g-disp-inlblock l-get-start-cont-icn-cont\">\r\n\t\t\t\t\t\t\t\t\t\t\t<img src=\"../../../assets/img/help/cnt_map_icon.svg\" alt=\"icon\" />\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"g-disp-inlblock g-pl-10\">\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"g-fs-08\">Looking to meet us?</div>\r\n\t\t\t\t\t\t\t\t\t\t\t<div class=\"g-fs-07 l-get-start-cont-us-link g-opacity-07\">\r\n\t\t\t\t\t\t\t\t\t\t\t\tMaulana Azad Road,<br />\r\n\t\t\t\t\t\t\t\t\t\t\t\tNew Delhi 110011\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"col-sm-6 text-right\">\r\n\t\t\t\t\t\t\t\t\t<div class=\"g-fs-07 l-get-start-cont-col-2-text g-opacity-05\">Get Directions</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.component.html":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.component.html ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"a-lp-wrapper g-white-bg\">\r\n  <h1 class=\"g-disp-none\">City Innovation Exchange</h1>\r\n  <h4 class=\"g-disp-none\">Smart Cities Mission</h4>\r\n  <h5 class=\"g-disp-none\">Open Innovation Exchange</h5>\r\n  <!-- Section 1 slider -->\r\n  <div class=\"container-fluid a-lp-s6 g-p-0\">\r\n    <div id=\"myCarousel\" class=\"carousel slide\" data-ride=\"carousel\">\r\n      <!-- Indicators -->\r\n      <ol class=\"carousel-indicators\">\r\n        <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>\r\n        <li data-target=\"#myCarousel\" data-slide-to=\"1\"></li>\r\n        <li data-target=\"#myCarousel\" data-slide-to=\"2\"></li>\r\n      </ol>\r\n\r\n      <!-- Wrapper for slides -->\r\n      <div class=\"carousel-inner\">\r\n        <div\r\n          class=\"item\"\r\n          *ngFor=\"let img of banner_images; let i = index\"\r\n          [ngClass]=\"{ active: i === 0 }\"\r\n        >\r\n          <img [src]=\"img.url\" alt=\"Banner Image\" class=\"g-w-100\" />\r\n        </div>\r\n      </div>\r\n\r\n      <!-- Left and right controls -->\r\n      <a class=\"left carousel-control\" href=\"#myCarousel\" data-slide=\"prev\">\r\n        <!-- <span class=\"glyphicon glyphicon-chevron-left g-green2-clr\"></span> -->\r\n        <i class=\"fas fa-chevron-left g-green2-clr\"></i>\r\n        <span class=\"sr-only\">Previous</span>\r\n      </a>\r\n      <a class=\"right carousel-control\" href=\"#myCarousel\" data-slide=\"next\">\r\n        <!-- <span class=\"glyphicon glyphicon-chevron-right g-green2-clr\"></span> -->\r\n        <i class=\"fas fa-chevron-right g-green2-clr\"></i>\r\n        <span class=\"sr-only\">Next</span>\r\n      </a>\r\n    </div>\r\n  </div>\r\n  <!-- Section-2 -->\r\n  <div class=\"section-2 a-s2 g-blue10-bg\">\r\n    <div class=\"container\">\r\n      <div class=\"row text-center\">\r\n        <!-- <div class=\"col-sm-1\"></div> -->\r\n        <div class=\"col-sm-2\">\r\n          <div class=\"g-pt-17\">\r\n            <div class=\"g-white-clr g-fs-20 g-fw-500\">{{ citiesCount }}</div>\r\n          </div>\r\n          <div class=\"g-pb-14\">\r\n            <div class=\"g-white-clr g-fs-09 g-fw-500 g-opacity-05\">Cities</div>\r\n          </div>\r\n        </div>\r\n        <div class=\"col-sm-2\">\r\n          <div class=\"g-pt-17\">\r\n            <div class=\"g-white-clr g-fs-20 g-fw-500\">{{ seekersCount }}</div>\r\n          </div>\r\n          <div class=\"g-pb-14\">\r\n            <div class=\"g-white-clr g-fs-09 g-fw-500 g-opacity-05\">City Administrators</div>\r\n          </div>\r\n        </div>\r\n        <div class=\"col-sm-2\">\r\n          <div class=\"g-pt-17\">\r\n            <div class=\"g-white-clr g-fs-20 g-fw-500\">\r\n              {{ challengeSectorCount }}\r\n            </div>\r\n          </div>\r\n          <div class=\"g-pb-14\">\r\n            <div class=\"g-white-clr g-fs-09 g-fw-500 g-opacity-05\">\r\n              Challenge Sectors\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"col-sm-2\">\r\n          <div class=\"g-pt-17\">\r\n            <div class=\"g-white-clr g-fs-20 g-fw-500\">\r\n              {{ challengesCount }}\r\n            </div>\r\n          </div>\r\n          <div class=\"g-pb-14\">\r\n            <div class=\"g-white-clr g-fs-09 g-fw-500 g-opacity-05\">\r\n              Challenges\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"col-sm-2\">\r\n          <div class=\"g-pt-17\">\r\n            <div class=\"g-white-clr g-fs-20 g-fw-500\">\r\n              {{ innovatorsCount }}\r\n            </div>\r\n          </div>\r\n          <div class=\"g-pb-14\">\r\n            <div class=\"g-white-clr g-fs-09 g-fw-500 g-opacity-05\">\r\n              Innovators\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"col-sm-2\">\r\n          <div class=\"g-pt-17\">\r\n            <div class=\"g-white-clr g-fs-20 g-fw-500\">\r\n              {{ solutionsCount }}\r\n            </div>\r\n          </div>\r\n          <div class=\"g-pb-14\">\r\n            <div class=\"g-white-clr g-fs-09 g-fw-500 g-opacity-05\">Solutions</div>\r\n          </div>\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n\r\n  <!-- Section-3 -->\r\n  <div class=\"container-fluid\">\r\n    <div class=\"row\">\r\n      <div class=\"col-sm-1\"></div>\r\n      <div class=\"col-sm-5\">\r\n        <div class=\"a-lp-s3-wrapper1 g-pt-50 g-pb-50\">\r\n          <div class=\"g-mt-29\">\r\n            <img src=\"assets/img/landingpage-s3-icon1.png\" alt=\"\" />\r\n          </div>\r\n          <div class=\"g-mt-08\">\r\n            <h2 class=\"g-fs-24 g-fw-700 g-blue10-clr\">\r\n              Urban Development through Open Innovation\r\n            </h2>\r\n          </div>\r\n          <div class=\"text-center g-mt-46 g-pb-30\">\r\n            <img\r\n              src=\"assets/img/landingpage-s3-img1.svg\"\r\n              alt=\"Image\"\r\n              class=\"g-w-100per\"\r\n            />\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"col-sm-5\">\r\n        <div class=\"a-lp-s3-wrapper2\">\r\n          <div class=\"g-pt-50 \">\r\n            <div class=\"g-fs-16 g-fw-700 g-blue10-clr\">About</div>\r\n          </div>\r\n          <div class=\"g-mt-09\">\r\n            <div class=\"g-fs-09 g-lh-14 g-fw-400 g-black-clr\">\r\n              Urban India is in dire need of the capability to discover and scale innovation at speed to keep up\r\n            with the escalating scope and complexities of its challenges. Identifying and removing systemic\r\n            bottlenecks, blind spots and inefficiencies are imperatives that requires urgent attention. The vast\r\n            geography and diversity of our 4000+ cities further complicate the challenge of discovering the\r\n            right solutions for local needs and aspirations.\r\n            </div>\r\n            <div class=\"g-mt-10 g-fs-09 g-lh-14 g-fw-400 g-black-clr\">\r\n              New India is witnessing the rise of a vibrant innovation ecosystem enriched by technology, talent\r\n              and entrepreneurial spirit, offering enormous potential to address the toughest urban challenges\r\n              across the nation.\r\n\r\n            </div>\r\n            <div class=\"g-mt-10 g-fs-09 g-lh-14 g-fw-400 g-black-clr\">\r\n              Smart Cities Mission, Ministry of Housing and Urban Affairs, envisions bringing administrators\r\n              and urban stakeholders in direct connection with India’s innovation ecosystem to significantly\r\n              augment the problem-solving capacity of our cities. In due time, the CiX platform will\r\n              immensely contribute to the Ease of Doing Business and Ease of Living in Cities.\r\n            </div>\r\n          </div>\r\n          <!-- <div class=\"g-mt-12\">\r\n            <a\r\n              href=\"#\"\r\n              class=\"btn g-blue10-bg g-white-clr g-fs-09 g-fw-700\"\r\n              role=\"button\"\r\n              >Learn more</a\r\n            >\r\n          </div> -->\r\n        </div>\r\n      </div>\r\n      <div class=\"col-sm-1\"></div>\r\n    </div>\r\n  </div>\r\n  <!-- Section-4 -->\r\n  <div class=\"container-fluid\">\r\n    <div class=\"row\">\r\n      <div class=\"col-sm-1\"></div>\r\n      <div class=\"col-sm-5\">\r\n        <div class=\"a-lp-s3-wrapper1\">\r\n          <div class=\"g-pt-50\">\r\n            <div class=\"g-fs-16 g-fw-700 g-blue10-clr\">Approach</div>\r\n          </div>\r\n          <div class=\"g-mt-09\">\r\n            <div class=\"g-fs-09 g-lh-14 g-fw-600 g-black-clr\">\r\n              Scaling Open Innovation to Transform 4000+ Cities in India\r\n            </div>\r\n            <div class=\"g-mt-10 g-fs-09 g-lh-14 g-fw-400 g-black-clr\">\r\n              Building on Prime Minister Shri Narendra Modi’s management mantra for AtmaNirbhar Bharat, ‘Innovation, Integrity & Inclusion’, City Innovation Exchange will facilitate innovation procurement in cities through a transparent & collaborative process. CiX marks the first step in the creation of Innovation Zones at the level of Urban Local Bodies, an vision shared by Smart Cities Mission with StartUp India.\r\n            </div>\r\n            <div class=\"g-mt-10 g-fs-09 g-lh-14 g-fw-400 g-black-clr\">\r\n              CiX adopts the Open Innovation Model to build solutions to address cities’ challenges. Open innovation helps in the purposive flows of knowledge and ideas from ‘outside-in and inside-out’ effectively closing the innovation capacity gap in urban local bodies and enriching the design and delivery of products and services. Open Innovation has been an underlying principle in the creation of the some of the most successful and user-friendly inventions in contemporary times.\r\n            </div>\r\n            <div class=\"g-mt-10 g-fs-09 g-lh-14 g-fw-400 g-black-clr\">\r\n              CiX using a federated architecture will enable multiple stakeholders including Administrators (Cities), Citizens, Innovators (researchers, startups, and MSMEs), and Ecosystem Enablers (Startup India, incubators, academia, associations) collectively called the Quadruple Helix—to effectively collaborate and co-create innovative solutions.\r\n\r\n            </div>\r\n          </div>\r\n          <!-- <div class=\"g-mt-12\">\r\n            <a\r\n              href=\"#\"\r\n              class=\"btn g-yellow-bg g-yellow3-clr g-fs-07 g-fw-500\"\r\n              role=\"button\" data-toggle=\"modal\" data-target=\"#approch-modal\"\r\n              >Know More</a\r\n            >\r\n          </div> -->\r\n        </div>\r\n      </div>\r\n      <div class=\"col-sm-5\">\r\n        <div class=\"a-lp-s3-wrapper1 g-pb-50\">\r\n          <div class=\"text-center g-mt-46 g-pb-30\">\r\n            <img\r\n              src=\"assets/img/landingpage-s4-img1.svg\"\r\n              alt=\"Image\"\r\n              class=\"g-w-100per\"\r\n            />\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"col-sm-1\"></div>\r\n    </div>\r\n  </div>\r\n  <!-- Section-5 -->\r\n  <div class=\"container-fluid g-mt-50\">\r\n    <div class=\"row\">\r\n      <div class=\"col-sm-1\"></div>\r\n      <div class=\"col-sm-5\">\r\n        <div class=\"g-pb-50\">\r\n          <div class=\"g-pl-24 g-pr-24\">\r\n            <img src=\"assets/img/Clock.png\" alt=\"Icon\" />\r\n          </div>\r\n          <div class=\"g-mt-08 g-pl-20 g-pr-20 g-mb-24\">\r\n            <div class=\"g-fs-24 g-fw-700 g-blue10-clr\">India in a minute</div>\r\n          </div>\r\n          <!-- <ul class=\"a-lp-s5-list g-mt-24\">\r\n            <li>\r\n              <button\r\n                type=\"button\"\r\n                class=\"btn btn-default g-bdr-0 g-black-clr g-opacity-05 g-fs-10 g-fw-400\"\r\n              >\r\n                National\r\n              </button>\r\n            </li>\r\n            <li>\r\n              <button\r\n                type=\"button\"\r\n                class=\"btn btn-default g-bdr-0 g-black-clr g-opacity-05 g-fs-10 g-fw-400\"\r\n              >\r\n                State\r\n              </button>\r\n            </li>\r\n            <li>\r\n              <button\r\n                type=\"button\"\r\n                class=\"btn btn-default g-bdr-0 g-black-clr g-opacity-05 g-fs-10 g-fw-400\"\r\n              >\r\n                City\r\n              </button>\r\n            </li>\r\n          </ul> -->\r\n          <city-stats></city-stats>\r\n        </div>\r\n      </div>\r\n      <div class=\"col-sm-5\">\r\n        <div class=\"g-pt-50\">\r\n          <img src=\"assets/img/landingpage-s6-img1.png\" alt=\"Image\" />\r\n        </div>\r\n      </div>\r\n      <div class=\"col-sm-1\"></div>\r\n    </div>\r\n  </div>\r\n  <!-- Section-6 -->\r\n  <div class=\"container-fluid a-lp-s6\">\r\n    <div id=\"myCarousel2\" class=\"carousel slide\" data-ride=\"carousel\">\r\n      <!-- Indicators -->\r\n      <ol class=\"carousel-indicators\">\r\n        <li data-target=\"#myCarousel2\" data-slide-to=\"0\" class=\"active\"></li>\r\n        <li data-target=\"#myCarousel2\" data-slide-to=\"1\"></li>\r\n        <li data-target=\"#myCarousel2\" data-slide-to=\"2\"></li>\r\n        <li data-target=\"#myCarousel2\" data-slide-to=\"3\"></li>\r\n        <li data-target=\"#myCarousel2\" data-slide-to=\"4\"></li>\r\n        <li data-target=\"#myCarousel2\" data-slide-to=\"5\"></li>\r\n        <li data-target=\"#myCarousel2\" data-slide-to=\"6\"></li>\r\n        <li data-target=\"#myCarousel2\" data-slide-to=\"7\"></li>\r\n        <li data-target=\"#myCarousel2\" data-slide-to=\"8\"></li>\r\n        <li data-target=\"#myCarousel2\" data-slide-to=\"9\"></li>\r\n      </ol>\r\n\r\n      <!-- Wrapper for slides -->\r\n      <div class=\"carousel-inner\">\r\n        <div\r\n          class=\"item\"\r\n          *ngFor=\"let sectors of challenge_sectors; let i = index\"\r\n          [ngClass]=\"{ active: i === 0 }\"\r\n        >\r\n          <div class=\"row g-pb-50\">\r\n            <div class=\"col-sm-1\"></div>\r\n            <div class=\"col-sm-5\">\r\n              <div class=\"g-pt-34 g-pl-24 g-pr-24\">\r\n                <img src=\"assets/img/lanadingpage-s6-icon1.png\" alt=\"Icon\" />\r\n              </div>\r\n              <div class=\"g-mt-08 g-pl-24 g-pr-24\">\r\n                <h3 class=\"g-fs-24 g-fw-700 g-green2-clr\">\r\n                  Challenge Sectors\r\n                </h3>\r\n              </div>\r\n              <div class=\"g-mt-50\">\r\n                <div class=\"g-pl-24 g-pr-24\">\r\n                  <img [src]=\"sectors.image_url\" alt=\"Icon\" />\r\n                </div>\r\n                <div class=\"g-mt-08 g-pl-24 g-pr-24\">\r\n                  <div class=\"g-fs-16 g-fw-700 g-green2-clr\">\r\n                    {{ sectors.name }}\r\n                  </div>\r\n                </div>\r\n                <div class=\"g-mt-08 g-pl-24 g-pr-24\">\r\n                  <div class=\"g-fs-09 g-fw-400 g-black-clr\">\r\n                    {{ sectors.desc }}\r\n                  </div>\r\n                </div>\r\n                <div class=\"g-mt-12 g-pl-24 g-pr-24 g-mb-50\">\r\n                  <a\r\n                    href=\"#\"\r\n                    class=\"btn g-green2-bg g-white-clr g-fs-07 g-fw-500 g-pl-16 g-pr-16\"\r\n                    role=\"button\"\r\n                    >Explore Platform</a\r\n                  >\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"col-sm-5\">\r\n              <div class=\"g-pt-50\">\r\n                <div class=\"row g-pt-50 g-mt-50\">\r\n                  <div class=\"col-sm-6 g-pt-50 g-mb-50\">\r\n                    <div>\r\n                      <div>\r\n                        <div class=\"g-fs-32 g-fw-500 g-green2-clr\">\r\n                          {{ sectors.solutions }}\r\n                        </div>\r\n                      </div>\r\n                      <div>\r\n                        <div class=\"g-fs-11 g-fw-500 g-green2-clr g-opacity-05\">\r\n                          Solutions\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"g-mt-35\">\r\n                      <div>\r\n                        <div class=\"g-fs-32 g-fw-500 g-green2-clr\">\r\n                          {{ sectors.pilots }}\r\n                        </div>\r\n                      </div>\r\n                      <div>\r\n                        <div class=\"g-fs-11 g-fw-500 g-green2-clr g-opacity-05\">\r\n                          Pilots\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"col-sm-6 g-pt-50 g-mb-50\">\r\n                    <div>\r\n                      <div>\r\n                        <div class=\"g-fs-32 g-fw-500 g-green2-clr\">\r\n                          {{ sectors.challenges }}\r\n                        </div>\r\n                      </div>\r\n                      <div>\r\n                        <div class=\"g-fs-11 g-fw-500 g-green2-clr g-opacity-05\">\r\n                          Challenges\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"g-mt-35\">\r\n                      <div>\r\n                        <div class=\"g-fs-32 g-fw-500 g-green2-clr\">\r\n                          {{ sectors.certified_solutons }}\r\n                        </div>\r\n                      </div>\r\n                      <div>\r\n                        <div class=\"g-fs-11 g-fw-500 g-green2-clr g-opacity-05\">\r\n                          Certified Solutions\r\n                        </div>\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"col-sm-1\"></div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n\r\n      <!-- Left and right controls -->\r\n      <a class=\"left carousel-control\" href=\"#myCarousel2\" data-slide=\"prev\">\r\n        <!-- <span class=\"glyphicon glyphicon-chevron-left g-green2-clr\"></span> -->\r\n        <i class=\"fas fa-chevron-left g-green2-clr\"></i>\r\n        <span class=\"sr-only\">Previous</span>\r\n      </a>\r\n      <a class=\"right carousel-control\" href=\"#myCarousel2\" data-slide=\"next\">\r\n        <!-- <span class=\"glyphicon glyphicon-chevron-right g-green2-clr\"></span> -->\r\n        <i class=\"fas fa-chevron-right g-green2-clr\"></i>\r\n        <span class=\"sr-only\">Next</span>\r\n      </a>\r\n    </div>\r\n  </div>\r\n  <!-- Section-7 -->\r\n  <div class=\"container-fluid g-mt-50 g-pt-39 g-pb-50\">\r\n    <div class=\"row\">\r\n      <div class=\"col-sm-1\"></div>\r\n      <div class=\"col-sm-10\">\r\n        <div class=\"g-pl-24 g-pr-24\">\r\n          <img src=\"assets/img/landingpage-s7-icon1.svg\" alt=\"Icon\" />\r\n        </div>\r\n        <div class=\"g-mt-08 g-pl-24 g-pr-24\">\r\n          <div class=\"g-fs-24 g-fw-700 g-green2-clr\">Benefits</div>\r\n        </div>\r\n        <div class=\"text-center g-mt-26\">\r\n          <img\r\n            src=\"assets/img/benifits.jpg\"\r\n            alt=\"Image\"\r\n            class=\"g-w-100per\"\r\n          />\r\n        </div>\r\n      </div>\r\n      <div class=\"col-sm-1\"></div>\r\n    </div>\r\n  </div>\r\n  <!-- Section-8 News Gallery -->\r\n  <div class=\"container-fluid a-lp-s8 g-mt-23 g-pt-50 g-pb-50 hidden\">\r\n    <div class=\"row\">\r\n      <div class=\"col-sm-1\"></div>\r\n      <div class=\"col-sm-10\">\r\n        <div class=\"g-pl-24 g-pr-24\">\r\n          <img src=\"assets/img/landingpage-s8-icon1.png\" alt=\"Icon\" />\r\n        </div>\r\n        <div class=\"g-mt-08 g-pl-24 g-pr-24\">\r\n          <div class=\"g-fs-24 g-fw-700 g-blue10-clr\">Gallery</div>\r\n        </div>\r\n        <div class=\"g-mt-20 g-mb-15\">\r\n          <div class=\"panel a-lp-panel1 g-bdrrad-0\">\r\n            <div class=\"panel-body g-p-0\">\r\n              <div>\r\n                <img src=\"assets/img/landingpage-s8-img1.jpg\" alt=\"Image\" />\r\n              </div>\r\n              <div class=\"g-pl-12 g-pr-12\">\r\n                <div class=\"g-mt-12\">\r\n                  <div class=\"g-fs-08 g-fw-400 g-black-clr g-opacity-05\">\r\n                    Sep 09, 2020\r\n                  </div>\r\n                </div>\r\n                <div class=\"g-pb-12\">\r\n                  <div class=\"g-fs-10 g-fw-500 g-black-clr\">\r\n                    PM Modi interacts with beneficiaries of PM SVANidhi scheme\r\n                    in MP\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"g-mb-50 g-pb-50\">\r\n          <div class=\"row g-pl-18 g-pr-18\">\r\n            <div class=\"col-sm-4\">\r\n              <div class=\"panel a-lp-panel1 g-bdrrad-0\">\r\n                <div class=\"panel-body g-p-0\">\r\n                  <div>\r\n                    <img src=\"assets/img/landingpage-s8-img2.jpg\" alt=\"Image\" />\r\n                  </div>\r\n                  <div class=\"g-pl-12 g-pr-12\">\r\n                    <div class=\"g-mt-12\">\r\n                      <div class=\"g-fs-08 g-fw-400 g-black-clr g-opacity-05\">\r\n                        Sep 22, 2020\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"g-pb-12\">\r\n                      <div class=\"g-fs-10 g-fw-500 g-black-clr\">\r\n                        Agartala' performance ranked first among smart cities\r\n                        .......\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"col-sm-4\">\r\n              <div class=\"panel a-lp-panel1 g-bdrrad-0\">\r\n                <div class=\"panel-body g-p-0\">\r\n                  <div>\r\n                    <img src=\"assets/img/landingpage-s8-img3.jpg\" alt=\"Image\" />\r\n                  </div>\r\n                  <div class=\"g-pl-12 g-pr-12\">\r\n                    <div class=\"g-mt-12\">\r\n                      <div class=\"g-fs-08 g-fw-400 g-black-clr g-opacity-05\">\r\n                        Sep 29, 2020\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"g-pb-12\">\r\n                      <div class=\"g-fs-10 g-fw-500 g-black-clr\">\r\n                        PM Modi To Inaugurate 6 Mega Projects In Uttarakhand\r\n                        .........\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"col-sm-4\">\r\n              <div class=\"panel a-lp-panel1 g-bdrrad-0\">\r\n                <div class=\"panel-body g-p-0\">\r\n                  <div>\r\n                    <img src=\"assets/img/landingpage-s8-img4.jpg\" alt=\"Image\" />\r\n                  </div>\r\n                  <div class=\"g-pl-12 g-pr-12\">\r\n                    <div class=\"g-mt-12\">\r\n                      <div class=\"g-fs-08 g-fw-400 g-black-clr g-opacity-05\">\r\n                        Sep 29, 2020\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"g-pb-12\">\r\n                      <div class=\"g-fs-10 g-fw-500 g-black-clr\">\r\n                        Smart cities predicted to create growth opportunities\r\n                        worth .......\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <div class=\"col-sm-1\"></div>\r\n    </div>\r\n  </div>\r\n  <!-- Section-9 clients -->\r\n  <div class=\"container-fluid a-lp-s9 g-pb-08 g-pt-08\">\r\n    <carousel\r\n      [margin]=\"50\"\r\n      [height]=\"70\"\r\n      [loop]=\"true\"\r\n      [cellWidth]=\"160\"\r\n      [autoplay]=\"true\"\r\n      [arrows]=\"false\"\r\n      [overflowCellsLimit]=\"0\"\r\n    >\r\n    <div class=\"carousel-cell\">\r\n      <img src=\"assets/img/clients/dppit_logo.png\" />\r\n    </div>\r\n    <div class=\"carousel-cell\">\r\n      <img src=\"assets/img/clients/Logo_NITI.png\" />\r\n    </div>\r\n    <div class=\"carousel-cell\">\r\n      <img src=\"assets/img/clients/aim_logo.png\" />\r\n    </div>\r\n    <div class=\"carousel-cell\">\r\n      <img src=\"assets/img/clients/Logo_StartUpIndia.png\" />\r\n    </div>\r\n    <div class=\"carousel-cell\">\r\n      <img src=\"assets/img/clients/Logo_Agni.png\" />\r\n    </div>\r\n      <div class=\"carousel-cell\">\r\n        <img src=\"assets/img/clients/Logo_Digital India.png\" />\r\n      </div>\r\n      <div class=\"carousel-cell\">\r\n        <img src=\"assets/img/clients/Logo_Atma.png\" />\r\n      </div>\r\n      <div class=\"carousel-cell\">\r\n        <img src=\"assets/img/clients/Logo_Swach.png\" />\r\n      </div>\r\n      <div class=\"carousel-cell\">\r\n        <img src=\"assets/img/clients/Make_In_India_0.png\" />\r\n      </div>\r\n      <div class=\"carousel-cell\">\r\n        <img src=\"assets/img/clients/Logo_FORGE.png\" />\r\n      </div>\r\n      <div class=\"carousel-cell\">\r\n        <img src=\"assets/img/clients/AVEVA_Logo_color_RGB.png\" />\r\n      </div>\r\n      <div class=\"carousel-cell\">\r\n        <img src=\"assets/img/clients/astikos_logo.png\" />\r\n      </div>\r\n    </carousel>\r\n  </div>\r\n  <!-- footer -->\r\n  <!-- <div class=\"a-lp-footer g-pt-50 g-pb-50\">\r\n        <div class=\"container g-pl-07 g-pr-07\">\r\n            <div class=\"row\">\r\n                <div class=\"col-sm-4\">\r\n                    <div>\r\n                        <div>\r\n                            <div class=\"g-white-clr g-fw-700 g-fs-32\">Innovation Exchange</div>\r\n                        </div>\r\n                        <div class=\"g-pt-16\">\r\n                            <div class=\"g-fs-16 g-fw-500 g-opacity-05 g-white-clr\">Commissioned by</div>\r\n                        </div>\r\n                        <div>\r\n                            <span>\r\n                                <img src=\"assets/img/smart-cities-logo 2.png\" alt=\"Image\" class=\"g-w-40per\">\r\n                            </span>&nbsp;\r\n                            <span>\r\n                                <img src=\"assets/img/smart-cities-logo 2.png\" alt=\"Image\">\r\n                            </span>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-sm-4\">\r\n                    <div>\r\n                        <div class=\"g-white-clr g-fw-700 g-fs-20\">Get in touch</div>\r\n                    </div>\r\n                    <div class=\"g-mt-12\">\r\n                        <div class=\"g-white-clr g-fw-500 g-fs-14\">Ashwini Metri</div>\r\n                    </div>\r\n                    <div class=\"g-mt-08\">\r\n                        <span class=\"g-fs-09 g-fw-500 g-opacity-05 g-white-clr\">Phone.</span>&nbsp;\r\n                        <span>\r\n                            <a class=\"g-fs-09 g-fw-500 g-opacity-05 g-white-clr\" href=\"tel:+917397761208\">+91-7397 761\r\n                                208</a>\r\n                        </span>\r\n                    </div>\r\n                    <div class=\"g-mt-04\">\r\n                        <span class=\"g-fs-08 g-fw-500 g-opacity-05 g-white-clr\">Mail.</span>&nbsp;\r\n                        <span>\r\n                            <a class=\"g-fs-08 g-fw-500 g-opacity-05 g-white-clr\"\r\n                                href=\"mailto:ashwini@forgeforward.in\">ashwini@forgeforward.in</a>\r\n                        </span>\r\n                    </div>\r\n\r\n                    <div class=\"g-mt-15\">\r\n                        <div class=\"g-white-clr g-fw-500 g-fs-09\">Ashwini Metri</div>\r\n                    </div>\r\n                    <div class=\"g-mt-08\">\r\n                        <span class=\"g-fs-07 g-fw-500 g-opacity-05 g-white-clr\">Phone.</span>&nbsp;\r\n                        <span>\r\n                            <a class=\"g-fs-07 g-fw-500 g-opacity-05 g-white-clr\" href=\"tel:+917397761208\">+91-7397 761\r\n                                208</a>\r\n                        </span>\r\n                    </div>\r\n                    <div class=\"g-mt-04\">\r\n                        <span class=\"g-fs-08 g-fw-500 g-opacity-05 g-white-clr\">Mail.</span>&nbsp;\r\n                        <span>\r\n                            <a class=\"g-fs-08 g-fw-500 g-opacity-05 g-white-clr\"\r\n                                href=\"mailto:ashwini@forgeforward.in\">ashwini@forgeforward.in</a>\r\n                        </span>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-sm-4\">\r\n                    <div class=\"g-mt-12\">\r\n                        <div class=\"g-white-clr g-fw-500 g-fs-14\">Arun</div>\r\n                    </div>\r\n                    <div class=\"g-mt-08\">\r\n                        <span class=\"g-fs-09 g-fw-500 g-opacity-05 g-white-clr\">Phone.</span>&nbsp;\r\n                        <span>\r\n                            <a class=\"g-fs-09 g-fw-500 g-opacity-05 g-white-clr\" href=\"tel:+91739798921\">+91-7397 798\r\n                                921</a>\r\n                        </span>\r\n                    </div>\r\n                    <div class=\"g-mt-04\">\r\n                        <span class=\"g-fs-08 g-fw-500 g-opacity-05 g-white-clr\">Mail.</span>&nbsp;\r\n                        <span>\r\n                            <a class=\"g-fs-08 g-fw-500 g-opacity-05 g-white-clr\"\r\n                                href=\"mailto:arun.s@forgeforward.in\">arun.s@forgeforward.in</a>\r\n                        </span>\r\n                    </div>\r\n\r\n                    <div class=\"g-mt-15\">\r\n                        <div class=\"g-white-clr g-fw-500 g-fs-09\">Arun</div>\r\n                    </div>\r\n                    <div class=\"g-mt-08\">\r\n                        <span class=\"g-fs-07 g-fw-500 g-opacity-05 g-white-clr\">Phone.</span>&nbsp;\r\n                        <span>\r\n                            <a class=\"g-fs-07 g-fw-500 g-opacity-05 g-white-clr\" href=\"tel:+91739798921\">+91-7397 798\r\n                                921</a>\r\n                        </span>\r\n                    </div>\r\n                    <div class=\"g-mt-04\">\r\n                        <span class=\"g-fs-08 g-fw-500 g-opacity-05 g-white-clr\">Mail.</span>&nbsp;\r\n                        <span>\r\n                            <a class=\"g-fs-08 g-fw-500 g-opacity-05 g-white-clr\"\r\n                                href=\"mailto:arun.s@forgeforward.in\">arun.s@forgeforward.in</a>\r\n                        </span>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <div class=\"a-lp-footer2\">\r\n        <div class=\"container g-pt-10 g-pb-08\">\r\n            <ul class=\"a-lp-ftr-list g-p-0\">\r\n                <li><a class=\"g-fs-08 g-mr-25 g-fw-500 g-white-clr g-opacity-05\" href=\"#\">@All Rights Reserved 2020 |\r\n                        Smart Cities\r\n                        Mission</a></li>\r\n                <li><a class=\"g-fs-08 g-fw-500 g-white-clr g-opacity-05\" href=\"#\">Privacy Policy</a></li>\r\n                <li><a class=\"g-fs-08 g-fw-500 g-white-clr g-opacity-05\" href=\"#\">Copyright Policy</a></li>\r\n                <li><a class=\"g-fs-08 g-fw-500 g-white-clr g-opacity-05\" href=\"#\">Terms & Conditions</a></li>\r\n                <li><a class=\"g-fs-08 g-ml-25 g-fw-500 g-white-clr g-opacity-05\" href=\"#\">Designed by\r\n                        <span class=\"g-white-clr\">Frozen Iris</span>\r\n                    </a></li>\r\n            </ul>\r\n        </div>\r\n    </div> -->\r\n</div>\r\n\r\n\r\n<!-- The Modal -->\r\n\r\n<div id=\"approch-modal\" class=\"modal fade\" role=\"dialog\">\r\n  <div class=\"modal-dialog modal-lg\">\r\n    <!-- Modal content-->\r\n    <div class=\"modal-content\">\r\n      <div class=\"modal-body\">\r\n        <div class=\"text-center\">\r\n          <img class=\"l-approch-modal-img\" src=\"assets/img/landing-approch.svg\" alt=\"Approch\">\r\n        </div>\r\n      </div>\r\n    </div>\r\n\r\n  </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/add-achievement-innovator/achievement-item/achievement-item.component.html":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/add-achievement-innovator/achievement-item/achievement-item.component.html ***!
  \*************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"achievementitem-card\">\r\n\t<div class=\"title\">{{ achievementData.title }}</div>\r\n\t<div class=\"monthyear\">{{ achievementData.month }} {{ achievementData.year }}</div>\r\n\t<div class=\"description\">{{ achievementData.description }}</div>\r\n\t<div class=\"menu\">\r\n\t\t<div class=\"dropdown dropleft\">\r\n\t\t\t<button class=\"btn btn-secondary dropdown-toggle\" type=\"button\" id=\"dropdownMenuButton\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">\r\n\t\t\t\t<i class=\"fas fa-ellipsis-h\"></i>\r\n\t\t\t</button>\r\n\t\t\t<div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuButton\">\r\n\t\t\t\t<span attr.data-target=\"#editachievements{{ id }}\" data-toggle=\"modal\">\r\n\t\t\t\t\t<i class=\"fas fa-pen g-mr-05\"></i>\r\n\t\t\t\t\tEdit Achievement\r\n\t\t\t\t</span>\r\n\t\t\t\t<span (click)=\"emitDeleteIndex()\">\r\n\t\t\t\t\t<i class=\"far fa-trash-alt g-mr-05\"></i>\r\n\t\t\t\t\tDelete Achievement\r\n\t\t\t\t</span>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n</div>\r\n<!-- add solutions popup -->\r\n<div class=\"modal g-mt-30 fade edit-achievements-modal\" attr.id=\"editachievements{{ id }}\" role=\"dialog\">\r\n\t<div class=\"modal-dialog modal-md\">\r\n\t\t<!-- Modal content-->\r\n\t\t<div class=\"modal-content\">\r\n\t\t\t<div class=\"modal-header\">\r\n\t\t\t\t<span class=\"modal-title g-fs-12 title-clr g-fw-400\"> Edit Achivements </span>\r\n\t\t\t\t<button type=\"button\" class=\"close g-fs-12 g-black14-clr g-fw-400\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n\t\t\t\t\t<span aria-hidden=\"true\">&times;</span>\r\n\t\t\t\t</button>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"modal-body\">\r\n\t\t\t\t<form [formGroup]=\"editAchievementsForm\" (ngSubmit)=\"editAchievement()\">\r\n\t\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t<div class=\"col-sm-6\">\r\n\t\t\t\t\t\t\t<div class=\"form-group g-mt-03\">\r\n\t\t\t\t\t\t\t\t<label for=\"year\" class=\"g-fs-07 lable-grey g-fw-400\"> Year* </label>\r\n\t\t\t\t\t\t\t\t<select\r\n\t\t\t\t\t\t\t\t\tclass=\"form-control\"\r\n\t\t\t\t\t\t\t\t\tname=\"challenge\"\r\n\t\t\t\t\t\t\t\t\tformControlName=\"year\"\r\n\t\t\t\t\t\t\t\t\t[ngClass]=\"{\r\n\t\t\t\t\t\t\t\t\t\terror: (editAchievementFormContorl.year.touched || isSubmitted) && editAchievementFormContorl.year?.errors\r\n\t\t\t\t\t\t\t\t\t}\"\r\n\t\t\t\t\t\t\t\t\t(change)=\"handleYearSelect()\"\r\n\t\t\t\t\t\t\t\t>\r\n\t\t\t\t\t\t\t\t\t<option selected=\"selected\" value=\"\">Select Year</option>\r\n\t\t\t\t\t\t\t\t\t<ng-container *ngFor=\"let year of yearArr\">\r\n\t\t\t\t\t\t\t\t\t\t<option [value]=\"year\">\r\n\t\t\t\t\t\t\t\t\t\t\t{{ year }}\r\n\t\t\t\t\t\t\t\t\t\t</option>\r\n\t\t\t\t\t\t\t\t\t</ng-container>\r\n\t\t\t\t\t\t\t\t</select>\r\n\t\t\t\t\t\t\t\t<div class=\"err-resp\">\r\n\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(editAchievementFormContorl.year.touched || isSubmitted) && editAchievementFormContorl.year.errors?.required\"> Year is required. </span>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"col-sm-6\">\r\n\t\t\t\t\t\t\t<div class=\"form-group g-mt-03\">\r\n\t\t\t\t\t\t\t\t<label for=\"month\" class=\"g-fs-07 lable-grey g-fw-400\"> Month* </label>\r\n\t\t\t\t\t\t\t\t<select\r\n\t\t\t\t\t\t\t\t\tclass=\"form-control\"\r\n\t\t\t\t\t\t\t\t\tname=\"challenge_sector\"\r\n\t\t\t\t\t\t\t\t\tformControlName=\"month\"\r\n\t\t\t\t\t\t\t\t\t[ngClass]=\"{\r\n\t\t\t\t\t\t\t\t\t\terror: (editAchievementFormContorl.month.touched || isSubmitted) && editAchievementFormContorl.month?.errors\r\n\t\t\t\t\t\t\t\t\t}\"\r\n\t\t\t\t\t\t\t\t\t[attr.disabled]=\"!yearSelected ? '' : null\"\r\n\t\t\t\t\t\t\t\t>\r\n\t\t\t\t\t\t\t\t\t<option selected=\"selected\" value=\"\">Select Month</option>\r\n\t\t\t\t\t\t\t\t\t<ng-container *ngFor=\"let month of monthDropdown\">\r\n\t\t\t\t\t\t\t\t\t\t<option [value]=\"month\">\r\n\t\t\t\t\t\t\t\t\t\t\t{{ month | titlecase }}\r\n\t\t\t\t\t\t\t\t\t\t</option>\r\n\t\t\t\t\t\t\t\t\t</ng-container>\r\n\t\t\t\t\t\t\t\t</select>\r\n\t\t\t\t\t\t\t\t<div class=\"err-resp\">\r\n\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(editAchievementFormContorl.month.touched || isSubmitted) && editAchievementFormContorl.month.errors?.required\"> Month is required. </span>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"form-group g-mt-03\">\r\n\t\t\t\t\t\t<label for=\"title\" class=\"g-fs-07 lable-grey g-fw-400\"> Title* </label>\r\n\t\t\t\t\t\t<input\r\n\t\t\t\t\t\t\ttype=\"text\"\r\n\t\t\t\t\t\t\tname=\"title\"\r\n\t\t\t\t\t\t\tclass=\"form-control\"\r\n\t\t\t\t\t\t\tplaceholder=\"10-15 words\"\r\n\t\t\t\t\t\t\tformControlName=\"title\"\r\n\t\t\t\t\t\t\t[ngClass]=\"{\r\n\t\t\t\t\t\t\t\terror: (editAchievementFormContorl.title.touched || isSubmitted) && editAchievementFormContorl.title?.errors\r\n\t\t\t\t\t\t\t}\"\r\n\t\t\t\t\t\t/>\r\n\t\t\t\t\t\t<div class=\"err-resp\">\r\n\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(editAchievementFormContorl.title.touched || isSubmitted) && editAchievementFormContorl.title.errors?.required\"> Title is required. </span>\r\n\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(editAchievementFormContorl.title.touched || isSubmitted) && editAchievementFormContorl.title.errors?.maxlength\"> 15 words is the maximum allowed limit. </span>\r\n\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(editAchievementFormContorl.title.touched || isSubmitted) && editAchievementFormContorl.title.errors?.minlength\"> title should have atleast 10 words.</span>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"g-mt-10 text-right\">\r\n\t\t\t\t\t\t<button class=\"btn g-p-bg g-w-clr g-fs-08 g-pt-04 g-pb-04 g-pl-15 g-pr-15\" type=\"submit\">Save</button>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</form>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/add-achievement-innovator/add-achievement-innovator.component.html":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/add-achievement-innovator/add-achievement-innovator.component.html ***!
  \*****************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"add-solution-wrp\">\r\n\t<label class=\"g-fs-07 g-black14-clr g-fw-500\"> Achievements </label>\r\n\t<ng-container *ngIf=\"achievementsArr\">\r\n\t\t<ng-container *ngFor=\"let achievement of achievementsArr; let i = index\">\r\n\t\t\t<app-achievement-item [achievementData]=\"achievement\" [id]=\"i\" (onDelete)=\"handleDeleteAchievement($event)\" (onEdit)=\"handleEditAchievement($event)\"> </app-achievement-item>\r\n\t\t</ng-container>\r\n\t</ng-container>\r\n\t<button type=\"button\" class=\"add-achievements btn\" data-target=\"#addachievements\" data-toggle=\"modal\">\r\n\t\tAdd Achievement &nbsp;\r\n\t\t<i class=\"fas fa-plus\"></i>\r\n\t</button>\r\n</div>\r\n\r\n<!-- add solutions popup -->\r\n<div class=\"modal g-mt-30 fade add-achievements-modal\" id=\"addachievements\" role=\"dialog\">\r\n\t<div class=\"modal-dialog modal-md\">\r\n\t\t<!-- Modal content-->\r\n\t\t<div class=\"modal-content\">\r\n\t\t\t<div class=\"modal-header\">\r\n\t\t\t\t<span class=\"modal-title g-fs-12 title-clr g-fw-400\"> Add Achievement </span>\r\n\t\t\t\t<button type=\"button\" class=\"close g-fs-12 g-black14-clr g-fw-400\" data-dismiss=\"modal\" aria-label=\"Close\">\r\n\t\t\t\t\t<span aria-hidden=\"true\">&times;</span>\r\n\t\t\t\t</button>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"modal-body\">\r\n\t\t\t\t<form [formGroup]=\"addAchievementsForm\" (ngSubmit)=\"createAchievement()\">\r\n\t\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t\t<div class=\"col-sm-6\">\r\n\t\t\t\t\t\t\t<div class=\"form-group g-mt-03\">\r\n\t\t\t\t\t\t\t\t<label for=\"year\" class=\"g-fs-07 lable-grey g-fw-400\"> Year* </label>\r\n\t\t\t\t\t\t\t\t<select\r\n\t\t\t\t\t\t\t\t\tclass=\"form-control\"\r\n\t\t\t\t\t\t\t\t\tname=\"challenge\"\r\n\t\t\t\t\t\t\t\t\tformControlName=\"year\"\r\n\t\t\t\t\t\t\t\t\t[ngClass]=\"{\r\n\t\t\t\t\t\t\t\t\t\terror: (addAchievementFormContorl.year.touched || isSubmitted) && addAchievementFormContorl.year?.errors\r\n\t\t\t\t\t\t\t\t\t}\"\r\n\t\t\t\t\t\t\t\t\t(change)=\"handleYearSelect()\"\r\n\t\t\t\t\t\t\t\t>\r\n\t\t\t\t\t\t\t\t\t<option selected=\"selected\" value=\"\">Select Year</option>\r\n\t\t\t\t\t\t\t\t\t<ng-container *ngFor=\"let year of yearArr\">\r\n\t\t\t\t\t\t\t\t\t\t<option [value]=\"year\">\r\n\t\t\t\t\t\t\t\t\t\t\t{{ year }}\r\n\t\t\t\t\t\t\t\t\t\t</option>\r\n\t\t\t\t\t\t\t\t\t</ng-container>\r\n\t\t\t\t\t\t\t\t</select>\r\n\t\t\t\t\t\t\t\t<div class=\"err-resp\">\r\n\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(addAchievementFormContorl.year.touched || isSubmitted) && addAchievementFormContorl.year.errors?.required\"> Year is required. </span>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<div class=\"col-sm-6\">\r\n\t\t\t\t\t\t\t<div class=\"form-group g-mt-03\">\r\n\t\t\t\t\t\t\t\t<label for=\"month\" class=\"g-fs-07 lable-grey g-fw-400\"> Month* </label>\r\n\t\t\t\t\t\t\t\t<select\r\n\t\t\t\t\t\t\t\t\tclass=\"form-control\"\r\n\t\t\t\t\t\t\t\t\tname=\"challenge_sector\"\r\n\t\t\t\t\t\t\t\t\tformControlName=\"month\"\r\n\t\t\t\t\t\t\t\t\t[ngClass]=\"{\r\n\t\t\t\t\t\t\t\t\t\terror: (addAchievementFormContorl.month.touched || isSubmitted) && addAchievementFormContorl.month?.errors\r\n\t\t\t\t\t\t\t\t\t}\"\r\n\t\t\t\t\t\t\t\t\t[attr.disabled]=\"!yearSelected ? '' : null\"\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t>\r\n\t\t\t\t\t\t\t\t\t<option selected=\"selected\" value=\"\">Select Month</option>\r\n\t\t\t\t\t\t\t\t\t<ng-container *ngFor=\"let month of monthDropdown\">\r\n\t\t\t\t\t\t\t\t\t\t<option [value]=\"month\">\r\n\t\t\t\t\t\t\t\t\t\t\t{{ month | titlecase }}\r\n\t\t\t\t\t\t\t\t\t\t</option>\r\n\t\t\t\t\t\t\t\t\t</ng-container>\r\n\t\t\t\t\t\t\t\t</select>\r\n\t\t\t\t\t\t\t\t<div class=\"err-resp\">\r\n\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(addAchievementFormContorl.month.touched || isSubmitted) && addAchievementFormContorl.month.errors?.required\"> Month is required. </span>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"form-group g-mt-03\">\r\n\t\t\t\t\t\t<label for=\"title\" class=\"g-fs-07 lable-grey g-fw-400\"> Title* </label>\r\n\t\t\t\t\t\t<input\r\n\t\t\t\t\t\t\ttype=\"text\"\r\n\t\t\t\t\t\t\tname=\"title\"\r\n\t\t\t\t\t\t\tclass=\"form-control\"\r\n\t\t\t\t\t\t\tplaceholder=\"10-15 words\"\r\n\t\t\t\t\t\t\tformControlName=\"title\"\r\n\t\t\t\t\t\t\t[ngClass]=\"{\r\n\t\t\t\t\t\t\t\terror: (addAchievementFormContorl.title.touched || isSubmitted) && addAchievementFormContorl.title?.errors\r\n\t\t\t\t\t\t\t}\"\r\n\t\t\t\t\t\t/>\r\n\t\t\t\t\t\t<div class=\"err-resp\">\r\n\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(addAchievementFormContorl.title.touched || isSubmitted) && addAchievementFormContorl.title.errors?.required\"> Title is required. </span>\r\n\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(addAchievementFormContorl.title.touched || isSubmitted) && addAchievementFormContorl.title.errors?.maxlength\"> 15 words is the maximum allowed limit. </span>\r\n\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(addAchievementFormContorl.title.touched || isSubmitted) && addAchievementFormContorl.title.errors?.minlength\"> title should have atleast 10 words.</span>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"g-mt-10 text-right\">\r\n\t\t\t\t\t\t<button class=\"btn g-p-bg g-w-clr g-fs-08 g-pt-04 g-pb-04 g-pl-15 g-pr-15\" type=\"submit\">Save</button>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</form>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/avatar-upload/avatar-upload.component.html":
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/avatar-upload/avatar-upload.component.html ***!
  \*****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"avatar-upload\">\r\n    <img [src]=\"Src\" alt=\"avatar\" class=\"g-w-100per g-bdrrad-50per\" />\r\n  <div class=\"avatar-upload-mdl-tgr\">\r\n    <ng-container *ngIf=\"croppedAvatar\">\r\n      <div class=\"add-avatar\" role=\"button\" (click)=\"removeImage(avatarImage)\">\r\n        <i class=\"fa fa-minus\" aria-hidden=\"true\"></i>\r\n      </div>\r\n    </ng-container>\r\n    <ng-container *ngIf=\"croppedAvatar === ''\">\r\n      <div class=\"add-avatar\" data-toggle=\"modal\" data-target=\"#imageModal\">\r\n        <i class=\"fa fa-plus\" aria-hidden=\"true\"></i>\r\n      </div>\r\n    </ng-container>\r\n  </div>\r\n</div>\r\n\r\n<!-- upload popup -->\r\n<div\r\n  class=\"modal g-mt-30 fade avatar-upload-modal\"\r\n  id=\"imageModal\"\r\n  role=\"dialog\"\r\n>\r\n  <div class=\"modal-dialog modal-md\">\r\n    <!-- Modal content-->\r\n    <div class=\"modal-content\">\r\n      <div class=\"modal-header text-left\">\r\n        <span class=\"modal-title g-fs-12 g-black14-clr g-fw-400\">\r\n          Upload Avatar\r\n        </span>\r\n        <button\r\n          type=\"button\"\r\n          class=\"close g-fs-12 g-black14-clr g-fw-400\"\r\n          data-dismiss=\"modal\"\r\n          aria-label=\"Close\"\r\n        >\r\n          <span aria-hidden=\"true\">&times;</span>\r\n        </button>\r\n      </div>\r\n      <div class=\"modal-body\">\r\n        <!-- cropper widget -->\r\n        <div class=\"cropper-widget\">\r\n          <div class=\"cropper-col-left\">\r\n            <div class=\"cropper-wrp\">\r\n              <image-cropper\r\n                [imageChangedEvent]=\"avatarFileChangedEvent\"\r\n                [maintainAspectRatio]=\"true\"\r\n                [aspectRatio]=\"1 / 1\"\r\n                resizeToWidth=\"512\"\r\n                format=\"png\"\r\n                [roundCropper]=\"true\"\r\n                [containWithinAspectRatio]=\"true\"\r\n                (imageCropped)=\"avatarImageCropped($event)\"\r\n                (imageLoaded)=\"avatarImageLoaded()\"\r\n                [backgroundColor]=\"000000\"\r\n              >\r\n              </image-cropper>\r\n            </div>\r\n          </div>\r\n          <div class=\"cropper-col-right\">\r\n            <div class=\"cropper-preview\">\r\n              <img [src]=\"croppedAvatar\" />\r\n            </div>\r\n            <hr />\r\n            <div class=\"g-pb-06\">\r\n              <label\r\n                (click)=\"avatarImage.click()\"\r\n                class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\"\r\n                role=\"button\"\r\n              >\r\n                <i class=\"fas fa-image\" aria-hidden=\"true\"></i>&nbsp;&nbsp;\r\n                <span\r\n                  *ngIf=\"avatarRawFileLoaded; then changeImage; else addImage\"\r\n                ></span>\r\n                <ng-template #addImage>Add Image</ng-template>\r\n                <ng-template #changeImage>Change Image</ng-template>\r\n              </label>\r\n              <input\r\n                type=\"file\"\r\n                #avatarImage\r\n                name=\"map\"\r\n                accept=\"image/png,image/jpeg\"\r\n                class=\"hidden\"\r\n                (change)=\"avatarChangeEvent($event)\"\r\n              />\r\n            </div>\r\n            <div class=\"g-pb-06\" *ngIf=\"avatarRawFileLoaded\">\r\n              <div class=\"g-fs-12 g-black14-clr g-fw-400\">\r\n                <button\r\n                  type=\"button\"\r\n                  (click)=\"saveEditedImage()\"\r\n                  class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\"\r\n                >\r\n                  <i class=\"far fa-save\" aria-hidden=\"true\"></i>\r\n                  &nbsp;&nbsp;Save Image\r\n                </button>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/collapsable-content/collapsable-content.component.html":
/*!*****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/collapsable-content/collapsable-content.component.html ***!
  \*****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div [innerHTML]=\"text\" class=\"content\" [class.collapsed]=\"isCollapsed\" [style.height]=\"isCollapsed ? maxHeight + 'px' : 'auto'\"></div>\r\n<div class=\"read-btn-wrp text-right\">\r\n\t<a class=\"g-cursor-pointer\" *ngIf=\"isCollapsable\" (click)=\"isCollapsed = !isCollapsed\"> ...read {{ isCollapsed ? \"more\" : \"less\" }} </a>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/companylogo-upload/companylogo-upload.component.html":
/*!***************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/companylogo-upload/companylogo-upload.component.html ***!
  \***************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div>\r\n    <span class=\"g-fs-07 lable-grey g-fw-400\"> Upload Company Logo* </span>\r\n    <div class=\"uploader-wrp\" [ngClass]=\"{\r\n        error:error         \r\n      }\">\r\n        <ng-container *ngIf=\"!Src\">\r\n            <div class=\"add-image\">\r\n                <span>\r\n                    <i class=\"far fa-plus-square\" data-target=\"#logoModal\" data-toggle=\"modal\"></i>\r\n                </span>\r\n            </div>\r\n        </ng-container>\r\n        <ng-container *ngIf=\"Src\">\r\n            <div class=\"preview-image\">\r\n                <img [src]=\"Src\" />\r\n                <span class=\"remove-img\" (click)=\"removeImage()\">\r\n                    <i class=\"far fa-trash-alt\"></i>\r\n                </span>\r\n            </div>\r\n        </ng-container>\r\n    </div>\r\n    <div class=\"err-resp\">\r\n        <span class=\"field-err\" *ngIf=\"error\">\r\n            Company logo is required\r\n        </span>\r\n    </div>\r\n</div>\r\n<!-- logo pop up -->\r\n<div class=\"modal g-mt-30 fade avatar-upload-modal\" id=\"logoModal\" role=\"dialog\">\r\n    <div class=\"modal-dialog modal-md\">\r\n        <!-- Modal content-->\r\n        <div class=\"modal-content\">\r\n            <div class=\"modal-header\">\r\n                <span class=\"modal-title g-fs-12 g-black14-clr g-fw-400\">\r\n                    Upload Logo\r\n                </span>\r\n                <button type=\"button\" class=\"close g-fs-12 g-black14-clr g-fw-400\" data-dismiss=\"modal\"\r\n                    aria-label=\"Close\">\r\n                    <span aria-hidden=\"true\">&times;</span>\r\n                </button>\r\n            </div>\r\n            <div class=\"modal-body\">\r\n                <!-- cropper widget -->\r\n                <div class=\"cropper-widget\">\r\n                    <div class=\"cropper-col-left\">\r\n                        <div class=\"cropper-wrp\">\r\n                            <image-cropper [imageChangedEvent]=\"logoChangedEvent\" [maintainAspectRatio]=\"true\"\r\n                                [aspectRatio]=\"1 / 1\" resizeToWidth=\"256\" format=\"png\" [imageQuality]=\"82\"\r\n                                [containWithinAspectRatio]=\"true\" (imageCropped)=\"logoCropped($event)\"\r\n                                (imageLoaded)=\"logoLoadedEvent()\">\r\n                            </image-cropper>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"cropper-col-right\">\r\n                        <div class=\"cropper-preview\">\r\n                            <img [src]=\"croppedLogo\" />\r\n                        </div>\r\n                        <hr />\r\n                        <div class=\"g-pb-06\">\r\n                            <label for=\"logo\" class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\">\r\n                                <i class=\"fas fa-image\" aria-hidden=\"true\"></i>&nbsp;&nbsp;\r\n                                <span *ngIf=\"logoLoaded; then lchangePicture; else laddPicture\"></span>\r\n                                <ng-template #laddPicture>Add Logo</ng-template>\r\n                                <ng-template #lchangePicture>Change Logo</ng-template>\r\n                            </label>\r\n                            <input type=\"file\" id=\"logo\" name=\"logo\" accept=\"image/png, image/jpeg\" class=\"hidden\"\r\n                                (change)=\"logoChangeEvent($event)\" />\r\n                        </div>\r\n                        <div class=\"g-pb-06\" *ngIf=\"logoLoaded\">\r\n                            <div class=\"g-fs-12 g-black14-clr g-fw-400\">\r\n                                <button type=\"button\" (click)=\"saveCropedLogo()\"\r\n                                    class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\">\r\n                                    <i class=\"far fa-save\" aria-hidden=\"true\"></i>&nbsp;&nbsp;Save\r\n                                    Logo\r\n                                </button>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/doc-upload/doc-upload.component.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/doc-upload/doc-upload.component.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"file-upload-block\">\r\n\t<ng-container *ngFor=\"let file of fileNameArr; let i = index\">\r\n\t\t<div class=\"file-item\">\r\n\t\t\t<div class=\"file-col\">\r\n\t\t\t\t<i class=\"fas fa-file-alt\"></i>\r\n\t\t\t\t{{ file.length > 50 ? (file | slice: 0:50) + \"..\" : file }}\r\n\t\t\t</div>\r\n\t\t\t<div class=\"remove-col text-right\">\r\n\t\t\t\t<span class=\"btn act-span\" (click)=\"removeFile(i)\"><i class=\"act-clr fa fa-minus\"></i></span>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</ng-container>\r\n\t<div class=\"add-doc\">\r\n\t\t<input type=\"file\" attr.id=\"{{ uploadName }}_file\" class=\"inputfile\" (change)=\"fileChangeEvent($event.target.files)\" />\r\n\t\t<label attr.for=\"{{ uploadName }}_file\" class=\"text-center\">\r\n\t\t\t<svg width=\"20\" height=\"20\" viewBox=\"0 0 20 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n\t\t\t\t<path\r\n\t\t\t\t\tfill-rule=\"evenodd\"\r\n\t\t\t\t\tclip-rule=\"evenodd\"\r\n\t\t\t\t\td=\"M5 0.833252C4.33696 0.833252 3.70107 1.09664 3.23223 1.56548C2.76339 2.03433 2.5 2.67021 2.5 3.33325L2.5 16.6666C2.5 17.3296 2.76339 17.9655 3.23223 18.4344C3.70107 18.9032 4.33696 19.1666 5 19.1666H15C15.663 19.1666 16.2989 18.9032 16.7678 18.4344C17.2366 17.9655 17.5 17.3296 17.5 16.6666V6.66658C17.5 6.44557 17.4122 6.23361 17.2559 6.07733L12.2559 1.07733C12.0996 0.921049 11.8877 0.833252 11.6667 0.833252L5 0.833252ZM4.41074 2.744C4.56702 2.58772 4.77899 2.49992 5 2.49992L10.8333 2.49992V6.66658C10.8333 7.12682 11.2064 7.49992 11.6667 7.49992H15.8333V16.6666C15.8333 16.8876 15.7455 17.0996 15.5893 17.2558C15.433 17.4121 15.221 17.4999 15 17.4999H5C4.77899 17.4999 4.56702 17.4121 4.41074 17.2558C4.25446 17.0996 4.16667 16.8876 4.16667 16.6666L4.16667 3.33325C4.16667 3.11224 4.25446 2.90028 4.41074 2.744ZM14.6548 5.83325L12.5 3.67843V5.83325H14.6548ZM10 9.16658C10.4602 9.16658 10.8333 9.53968 10.8333 9.99992V11.6666H12.5C12.9602 11.6666 13.3333 12.0397 13.3333 12.4999C13.3333 12.9602 12.9602 13.3333 12.5 13.3333H10.8333V14.9999C10.8333 15.4602 10.4602 15.8333 10 15.8333C9.53976 15.8333 9.16667 15.4602 9.16667 14.9999V13.3333H7.5C7.03976 13.3333 6.66667 12.9602 6.66667 12.4999C6.66667 12.0397 7.03976 11.6666 7.5 11.6666H9.16667V9.99992C9.16667 9.53968 9.53976 9.16658 10 9.16658Z\"\r\n\t\t\t\t\tfill=\"#4F4F4F\"\r\n\t\t\t\t/>\r\n\t\t\t</svg>\r\n\t\t\t<span class=\"g-ml-06 g-fs-07\">Click here to add a document</span>\r\n\t\t</label>\r\n\t</div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/gallery-upload/gallery-upload.component.html":
/*!*******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/gallery-upload/gallery-upload.component.html ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"gallery-upload-widget\">\r\n    <label class=\"g-fs-07 lable-grey g-fw-400\"> Upload Images </label>\r\n    <div class=\"gallery-upload-wrp\">\r\n      <ng-container *ngFor=\"let item of [].constructor(5); let i = index\">\r\n        <div class=\"gallery-sqaure\">\r\n          <ng-container *ngIf=\"previewArr && previewArr[i]; else elseBlock\">\r\n            <div class=\"preview-img-wrp\">\r\n              <img [src]=\"previewArr[i]\" />\r\n              <span class=\"remove-img\" (click)=\"removeImage(i)\">\r\n                <i class=\"far fa-trash-alt\"></i>\r\n              </span>\r\n            </div>\r\n          </ng-container>\r\n          <ng-template #elseBlock>\r\n            <div class=\"add-img-wrp\">\r\n              <span>\r\n                <i\r\n                  class=\"far fa-plus-square\"\r\n                  data-target=\"#galleryModal\"\r\n                  data-toggle=\"modal\"\r\n                ></i>\r\n              </span>\r\n            </div>\r\n          </ng-template>\r\n        </div>\r\n      </ng-container>\r\n    </div>\r\n  </div>  \r\n  <!-- gallery upload -->  \r\n  <div\r\n    class=\"modal g-mt-30 fade avatar-upload-modal\"\r\n    id=\"galleryModal\"\r\n    role=\"dialog\"\r\n  >\r\n    <div class=\"modal-dialog modal-md\">\r\n      <!-- Modal content-->\r\n      <div class=\"modal-content\">\r\n        <div class=\"modal-header\">\r\n          <span class=\"modal-title g-fs-12 title-clr g-fw-400\">\r\n            Upload Gallery Image\r\n          </span>\r\n          <button\r\n            type=\"button\"\r\n            class=\"close g-fs-12 g-black14-clr g-fw-400\"\r\n            data-dismiss=\"modal\"\r\n            aria-label=\"Close\"\r\n          >\r\n            <span aria-hidden=\"true\">&times;</span>\r\n          </button>\r\n        </div>\r\n        <div class=\"modal-body\" *ngIf=\"!loaded\">\r\n          <div class=\"cropper-widget\">\r\n            <div class=\"cropper-col-left\">\r\n              <div class=\"cropper-wrp\">\r\n                <image-cropper\r\n                  [imageChangedEvent]=\"imageChangedEvent\"\r\n                  [maintainAspectRatio]=\"true\"\r\n                  [aspectRatio]=\"1 / 1\"\r\n                  resizeToWidth=\"1000\"\r\n                  format=\"jpeg\"\r\n                  [imageQuality]=\"82\"\r\n                  [containWithinAspectRatio]=\"true\"\r\n                  [backgroundColor]=\"f3f3f3\"\r\n                  (imageCropped)=\"imageCropped($event)\"\r\n                  (imageLoaded)=\"imageLoaded()\"\r\n                >\r\n                </image-cropper>\r\n              </div>\r\n            </div>\r\n            <div class=\"cropper-col-right\">\r\n              <div class=\"cropper-preview\">\r\n                <img [src]=\"croppedImage\" />\r\n              </div>\r\n              <hr />\r\n              <div class=\"g-pb-06\">\r\n                <label\r\n                  for=\"gallery\"\r\n                  class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\"\r\n                >\r\n                  <i class=\"fas fa-image\" aria-hidden=\"true\"></i>&nbsp;&nbsp;\r\n                  <span\r\n                    *ngIf=\"fileLoaded; then changeImage; else addImage\"\r\n                  ></span>\r\n                  <ng-template #addImage>Add Image</ng-template>\r\n                  <ng-template #changeImage>Change Image</ng-template>\r\n                </label>\r\n                <input\r\n                  type=\"file\"\r\n                  id=\"gallery\"\r\n                  accept=\"image/png,image/jpeg\"\r\n                  class=\"hidden\"\r\n                  (change)=\"fileChangeEvent($event)\"\r\n                />\r\n              </div>\r\n              <div class=\"g-pb-06\" *ngIf=\"fileLoaded\">\r\n                <div class=\"g-fs-12 g-black14-clr g-fw-400\">\r\n                  <button\r\n                    type=\"button\"\r\n                    (click)=\"saveEditedGalleryImage()\"\r\n                    class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\"\r\n                  >\r\n                    <i class=\"far fa-save\" aria-hidden=\"true\"></i>\r\n                    &nbsp;&nbsp;Save Image\r\n                  </button>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/image-cropper/image-cropper.component.html":
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/image-cropper/image-cropper.component.html ***!
  \*****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"cropper-widget\">\r\n  <div class=\"cropper-col-left\">\r\n    <div class=\"cropper-wrp\">\r\n      <image-cropper\r\n        [imageChangedEvent]=\"imageChangedEvent\"\r\n        [maintainAspectRatio]=\"true\"\r\n        [aspectRatio]=\"1 / 1\"\r\n        resizeToWidth=\"512\"\r\n        format=\"png\"\r\n        [roundCropper]=\"\"\r\n        (imageCropped)=\"imageCropped($event)\"\r\n        (imageLoaded)=\"imageLoaded()\"\r\n      >\r\n      </image-cropper>\r\n    </div>\r\n  </div>\r\n  <div class=\"cropper-col-right\">\r\n    <div class=\"cropper-preview\">\r\n      <img [src]=\"croppedImage\" />\r\n    </div>\r\n    <hr />\r\n    <div class=\"g-pb-06\">\r\n      <label\r\n        for=\"map\"\r\n        class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\"\r\n      >\r\n        <i class=\"fas fa-image\" aria-hidden=\"true\"></i>&nbsp;&nbsp;\r\n        <span *ngIf=\"fileLoaded; then changeImage; else addImage\"></span>\r\n        <ng-template #addImage>Add Image</ng-template>\r\n        <ng-template #changeImage>Change Image</ng-template>\r\n      </label>\r\n      <input\r\n        type=\"file\"\r\n        id=\"map\"\r\n        name=\"map\"\r\n        accept=\"image/png,image/jpeg\"\r\n        class=\"hidden\"\r\n        (change)=\"fileChangeEvent($event)\"\r\n      />\r\n    </div>\r\n    <div class=\"g-pb-06\" *ngIf=\"fileLoaded\">\r\n      <div class=\"g-fs-12 g-black14-clr g-fw-400\">\r\n        <button\r\n          type=\"button\"\r\n          (click)=\"saveEditedImage()\"\r\n          class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\"\r\n        >\r\n          <i class=\"far fa-save\" aria-hidden=\"true\"></i>\r\n          &nbsp;&nbsp;Save Image\r\n        </button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/notifier/notifier.component.html":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/notifier/notifier.component.html ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"notification-wrapper\">\r\n\t<span class=\"bell\">\r\n\t\t<i class=\"fas fa-bell\" [attr.data-count]=\"notificationCount\"></i>\r\n\t</span>\r\n\t<div class=\"notification-tray\">\r\n\t\t<div class=\"title header\">\r\n\t\t\t<div>\r\n\t\t\t\tNotifications\r\n\t\t\t\t<span class=\"bell\">\r\n\t\t\t\t\t<i class=\"fas fa-bell\"></i>\r\n\t\t\t\t</span>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"view-link\" (click)=\"viewAll()\">\r\n\t\t\t\t<span>View All</span>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div class=\"notification-content\">\r\n\t\t\t<ng-container *ngFor=\"let item of notifications\">\r\n\t\t\t\t<ng-container *ngIf=\"item.event === 'ON_NEW_CHALLENGE'\">\r\n\t\t\t\t\t<div class=\"notification-item\" (click)=\"handleNotificationRedirect('/challenge/' + item.message_payload.payloads.challenge_id, item.id)\">\r\n\t\t\t\t\t\t<div class=\"message\">\r\n\t\t\t\t\t\t\tA new challenge statement named as <b>{{ item.message_payload.payloads.challenge_name }}</b> under the sector <b>{{ item.message_payload.payloads.challenge_sector | titlecase }}</b>\r\n\t\t\t\t\t\t\thas been added to the platform.\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<span class=\"status\" [ngClass]=\"{ new: item.read === false }\"> </span>\r\n\t\t\t\t\t\t<div class=\"time\">\r\n\t\t\t\t\t\t\t{{ item.timestamp }}\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</ng-container>\r\n\t\t\t\t<ng-container *ngIf=\"item.event === 'ON_SOLUTION_ADDED_UNDER_SECTOR'\">\r\n\t\t\t\t\t<div class=\"notification-item\" (click)=\"handleNotificationRedirect('/solution/' + item.message_payload.payloads.solution_id, item.id)\">\r\n\t\t\t\t\t\t<div class=\"message\">\r\n\t\t\t\t\t\t\tA new Solution named <b>{{ item.message_payload.payloads.solution_name }}</b> has been added under the sector <b>{{ item.message_payload.payloads.challenge_sector | titlecase }}</b> by\r\n\t\t\t\t\t\t\t{{ item.message_payload.payloads.company_name }}\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<span class=\"status\" [ngClass]=\"{ new: item.read === false }\"> </span>\r\n\t\t\t\t\t\t<div class=\"time\">\r\n\t\t\t\t\t\t\t{{ item.timestamp }}\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</ng-container>\r\n\t\t\t\t<ng-container *ngIf=\"item.event === 'ON_SOLUTION_ADDED_UNDER_CHALLENGE'\">\r\n\t\t\t\t\t<div class=\"notification-item\" (click)=\"handleNotificationRedirect('/solution/' + item.message_payload.payloads.solution_id, item.id)\">\r\n\t\t\t\t\t\t<div class=\"message\">\r\n\t\t\t\t\t\t\t<b>{{ item.message_payload.payloads.company_name }}</b> catalogued a new solution for the challenge <b>{{ item.message_payload.payloads.challenge_name | titlecase }}</b>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<span class=\"status\" [ngClass]=\"{ new: item.read === false }\"> </span>\r\n\t\t\t\t\t\t<div class=\"time\">\r\n\t\t\t\t\t\t\t{{ item.timestamp }}\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</ng-container>\r\n\t\t\t\t<ng-container *ngIf=\"item.event === 'ON_NEW_EOI'\">\r\n\t\t\t\t\t<div class=\"notification-item\" (click)=\"handleNotificationRedirect('/provider/user/' + item.message_payload.payloads.user_slug + '/dashboard/eois',item.id )\">\r\n\t\t\t\t\t\t<div class=\"message\">\r\n\t\t\t\t\t\t\tA new EOI has been recieved for <b>{{ item.message_payload.payloads.application_name }}</b> from the <b>{{ item.message_payload.payloads.seeker_name | titlecase }}</b> of\r\n\t\t\t\t\t\t\t{{ item.message_payload.payloads.city_name }}\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<span class=\"status\" [ngClass]=\"{ new: item.read === false }\"> </span>\r\n\t\t\t\t\t\t<div class=\"time\">\r\n\t\t\t\t\t\t\t{{ item.timestamp }}\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</ng-container>\r\n\t\t\t\t<ng-container *ngIf=\"item.event === 'ON_NEW_PROPOSAL'\">\r\n\t\t\t\t\t<div class=\"notification-item\" (click)=\"handleNotificationRedirect('/seeker/user/' + item.message_payload.payloads.user_slug + '/dashboard/challenge/' +  item.message_payload.payloads.anchor_id + '/review-proposals',item.id)\">\r\n\t\t\t\t\t\t<!-- <div>/seeker/user/ {{item.message_payload.payloads.user_slug}} /dashboard/challenge/ {{item.message_payload.payloads.anchor_id}} /review-proposals </div> -->\r\n\t\t\t\t\t\t<div class=\"message\">\r\n\t\t\t\t\t\t\tA new proposal is recieved from <b>{{ item.message_payload.payloads.provider_name | titlecase}},{{item.message_payload.payloads.type | titlecase}}</b> for the challenge <b>{{ item.message_payload.payloads.challenge_name | titlecase }}.</b>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<span class=\"status\" [ngClass]=\"{ new: item.read === false }\"> </span>\r\n\t\t\t\t\t\t<div class=\"time\">\r\n\t\t\t\t\t\t\t{{ item.timestamp }}\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</ng-container>\r\n\t\t\t\t<ng-container *ngIf=\"item.event === 'ON_ANCHOR_CLOSED'\">\r\n\t\t\t\t\t<div class=\"notification-item\" (click)=\"handleNotificationRedirect('/challenge/' + item.message_payload.payloads.challenge_id + '/anchor/' + item.message_payload.payloads.anchor_id,item.id)\">\r\n\t\t\t\t\t\t<div class=\"message\">\r\n\t\t\t\t\t\t\t<b>{{ item.message_payload.payloads.city_name | titlecase}}</b> lead by  <b>{{ item.message_payload.payloads.city_admin | titlecase}}</b> has closed their anchor titled  <b>{{ item.message_payload.payloads.challenge_name | titlecase }}.</b>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<span class=\"status\" [ngClass]=\"{ new: item.read === false }\"> </span>\r\n\t\t\t\t\t\t<div class=\"time\">\r\n\t\t\t\t\t\t\t{{ item.timestamp }}\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</ng-container>\r\n\t\t\t\t<ng-container *ngIf=\"item.event === 'ON_PROPOSAL_REJECTION'\">\r\n\t\t\t\t\t<div class=\"notification-item\" (click)=\"handleNotificationRedirect('/seeker/user/' + item.message_payload.payloads.user_slug + '/dashboard/challenge/' + item.message_payload.payloads.anchor_id +'/review-proposals',item.id)\">\r\n\t\t\t\t\t\t<div class=\"message\">\r\n\t\t\t\t\t\t\tYour Proposal <b>{{ item.message_payload.payloads.proposal_name | titlecase}}</b> was rejected by  <b>{{ item.message_payload.payloads.seeker_name | titlecase}}</b> ,<b>{{ item.message_payload.payloads.city_name | titlecase}}</b> for following reason <b>{{ item.message_payload.payloads.rejection_message | titlecase}}</b>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<span class=\"status\" [ngClass]=\"{ new: item.read === false }\"> </span>\r\n\t\t\t\t\t\t<div class=\"time\">\r\n\t\t\t\t\t\t\t{{ item.timestamp }}\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</ng-container>\r\n\t\t\t\t<ng-container *ngIf=\"item.event === 'ON_APPLICATION_REJECTION'\">\r\n\t\t\t\t\t<div class=\"notification-item\" (click)=\"handleNotificationRedirect('/provider/user/' + item.message_payload.payloads.user_slug + '/dashboard/applications/' ,item.id)\">\r\n\t\t\t\t\t\t<div class=\"message\">\r\n\t\t\t\t\t\t\tYour Proposal <b>{{ item.message_payload.payloads.application_name | titlecase}}</b> was rejected by  <b>{{ item.message_payload.payloads.city_admin | titlecase}}</b> ,<b>{{ item.message_payload.payloads.city_name | titlecase}}</b> for following reason <b>{{ item.message_payload.payloads.rejection_msg | titlecase}}</b>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<span class=\"status\" [ngClass]=\"{ new: item.read === false }\"> </span>\r\n\t\t\t\t\t\t<div class=\"time\">\r\n\t\t\t\t\t\t\t{{ item.timestamp }}\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</ng-container>\r\n\t\t\t\t<ng-container *ngIf=\"item.event === 'ON_ANCHOR_STATUS'\">\r\n\t\t\t\t\t<div class=\"notification-item\">\r\n\t\t\t\t\t\t<div class=\"message g-fs-08\">\r\n\t\t\t\t\t\t\tYour Challenge brief named as <b>{{ item.message_payload.payloads.challenge_name | titlecase}}</b> has been <b>{{ item.message_payload.payloads.status | titlecase}}</b>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<span class=\"status\" [ngClass]=\"{ new: item.read === false }\"> </span>\r\n\t\t\t\t\t\t<div class=\"time g-fs-08 g-black5-clr g-opacity-05 text-end\">\r\n\t\t\t\t\t\t\t{{ item.timestamp }}\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</ng-container>\r\n\t\t\t\t<ng-container *ngIf=\"item.event === 'ON_APP_CREATION'\">\r\n\t\t\t\t\t<div class=\"notification-item\"  (click)=\"handleNotificationRedirect('/provider/user/' + item.message_payload.payloads.user_slug + '/dashboard/proposals/' ,item.id)\">\r\n\t\t\t\t\t\t<div class=\"message g-fs-08\">\r\n\t\t\t\t\t\t\tA proposal for the  Challenge brief <b>{{ item.message_payload.payloads.challenge_name | titlecase}}</b> has been created\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<span class=\"status\" [ngClass]=\"{ new: item.read === false }\"> </span>\r\n\t\t\t\t\t\t<div class=\"time g-fs-08 g-black5-clr g-opacity-05 text-end\">\r\n\t\t\t\t\t\t\t{{ item.timestamp }}\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</ng-container>\r\n\t\t\t\t<ng-container *ngIf=\"item.event ==='ON_UNS_CHALL_CREATION'\">\r\n\t\t\t\t\t<div class=\"notification-item\"  (click)=\"handleNotificationRedirect('/seeker/user/' + item.message_payload.payloads.user_slug + '/unsolicted-proposal' ,item.id)\">\r\n\t\t\t\t\t\t<div class=\"message g-fs-08\">\r\n\t\t\t\t\t\t\tA new challenge statement named as <b>{{ item.message_payload.payloads.challenge_name }}</b> under the sector <b>{{ item.message_payload.payloads.challenge_sector | titlecase }}</b>\r\n\t\t\t\t\t\t\t\thas been added to the platform.\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t<span class=\"status\" [ngClass]=\"{ new: item.read === false }\"> </span>\r\n\t\t\t\t\t\t<div class=\"time g-fs-08 g-black5-clr g-opacity-05 text-end\">\r\n\t\t\t\t\t\t\t{{ item.timestamp }}\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</ng-container>\r\n\r\n\t\t\t</ng-container>\r\n\t\t</div>\r\n\t</div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/pagination/pagination.component.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/pagination/pagination.component.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ng-container *ngIf=\"totalItems != null\">\r\n    <ul class=\"pagination g-mt-10 g-mb-0\" *ngIf=\"totalItems != 0\">\r\n        <ng-container *ngIf=\"pagination.currentPage != 1\">\r\n            <li>\r\n                <a class=\"g-cursor-pointer\" (click)=\"goToPage(pagination.currentPage - 1)\">\r\n                    <i class=\"fas fa-angle-left\"></i>\r\n                </a>\r\n            </li>\r\n        </ng-container>\r\n        <ng-container *ngFor=\"let item of pagination.pages; let i = index\">\r\n            <li [class.active]=\"selectedPage === item\">\r\n                <a class=\"g-cursor-pointer\" (click)=\"goToPage(item)\">\r\n                    {{item}}\r\n                </a>\r\n            </li>\r\n        </ng-container>\r\n        <ng-container *ngIf=\"pagination.currentPage != pagination.totalPages\">\r\n            <li>\r\n                <a class=\"g-cursor-pointer\" (click)=\"goToPage(pagination.currentPage+1)\">\r\n                    <i class=\"fas fa-angle-right\"></i>\r\n                </a>\r\n            </li>\r\n        </ng-container>\r\n    </ul>\r\n</ng-container>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/tooltip/tooltip.component.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/tooltip/tooltip.component.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<span class=\"pull-right tool-tip-icon\" data-html=\"true\" data-placement=\"bottom\" data-toggle=\"tooltip\" [title]=\"title\">\r\n    <i class=\"far fa-question-circle g-p-clr\"></i>\r\n</span>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/users/forgot-password/forgot-password.component.html":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/users/forgot-password/forgot-password.component.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"forgot-password-parent\">\r\n    <div class=\"container\">\r\n        <div class=\"g-pt-50\">\r\n            <ul class=\"a-step-form-active-list text-center g-p-0\">\r\n              <li\r\n                class=\"g-w-24 g-h-05 g-bdrrad-10px g-ml-03 g-mr-03\"\r\n                [ngClass]=\"{\r\n                  'g-p-bg': !forgotPasswordStep1,\r\n                  'g-blue9-bg': forgotPasswordStep1\r\n                }\"                \r\n              ></li>\r\n              <li\r\n                class=\"g-w-24 g-h-05 g-bdrrad-10px g-ml-03 g-mr-03\"\r\n                [ngClass]=\"{\r\n                  'g-p-bg': !forgotPasswordStep2,\r\n                  'g-blue9-bg': forgotPasswordStep2\r\n                }\"               \r\n              ></li>\r\n              <li\r\n                class=\"g-w-24 g-h-05 g-bdrrad-10px g-ml-03 g-mr-03\"\r\n                [ngClass]=\"{\r\n                  'g-p-bg': !forgotPasswordStep3,\r\n                  'g-blue9-bg': forgotPasswordStep3\r\n                }\"                \r\n              ></li>\r\n            </ul>\r\n          </div>\r\n          <!-- step form -->\r\n          <div class=\"forgot-password-step-form-wrp g-pt-50\">\r\n            <!-- step 1 -->\r\n            <div class=\"step-card-wrp\" [hidden]=\"forgotPasswordStep1\">\r\n                <form [formGroup]=\"ForgotPassword.Step1\" #sendCodeForm=\"ngForm\" (ngSubmit)=\"sendCode(sendCodeForm)\">\r\n                    <div class=\"g-fs-14 g-fw-500 g-blue3-clr g-pb-20\">\r\n                        Forgot Password?\r\n                    </div>\r\n                    <div class=\"form-group g-mt-03\">\r\n                        <label for=\"email\" class=\"g-fs-07 g-black14-clr g-fw-500\">\r\n                            Enter your registered email address to reset your password.\r\n                        </label>\r\n                        <input type=\"text\" name=\"email\" class=\"form-control g-blue8-bg\" \r\n                        placeholder=\"ex: johndoe@gmail.com\"\r\n                        formControlName=\"email\"\r\n                        [ngClass]=\"{\r\n                            error:\r\n                              (formControlStep1.email.touched ||\r\n                                isSubmitted.Step1) &&\r\n                              formControlStep1.email?.errors\r\n                            }\">\r\n                        <div class=\"err-resp\">\r\n                            <span class=\"field-err\"\r\n                                *ngIf=\"\r\n                                (formControlStep1.email.touched || isSubmitted.Step1) &&\r\n                                formControlStep1.email.errors?.required\r\n                                \">\r\n                                Email is required\r\n                            </span>\r\n                            <span class=\"field-err\"\r\n                                *ngIf=\"\r\n                                (formControlStep1.email.touched || isSubmitted.Step1) &&\r\n                                formControlStep1.email.errors?.email\r\n                                \">\r\n                                Enter a valid email address\r\n                            </span>\r\n                            <span class=\"field-err\"\r\n                                *ngIf=\"\r\n                                (formControlStep1.email.touched || isSubmitted.Step1) &&\r\n                                formControlStep1.email.errors?.emailNotRegistered\r\n                                \">\r\n                                Email not registered\r\n                            </span>\r\n                        </div>    \r\n                    </div>\r\n                    <div class=\"g-mt-12\">\r\n                        <button type=\"submit\" class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\"\r\n                        >\r\n                            Next&nbsp;\r\n                            <i class=\"fas fa-circle-notch fa-spin\" *ngIf=\"step1Loading\"></i>\r\n                        </button>\r\n                    </div>\r\n                </form> \r\n            </div>\r\n            <!-- step 2 -->\r\n            <div [hidden]=\"forgotPasswordStep2\">\r\n                <div class=\"g-pb-10\">\r\n                    <a class=\"g-fs-10 g-fw-500 g-blue-clr g-cursor-pointer\" (click)=\"goBack('step1')\">\r\n                        &lt; Back\r\n                    </a>\r\n                </div>\r\n                <div class=\"step-card-wrp\" >\r\n                    <form [formGroup]=\"ForgotPassword.Step2\" #verifyCodeForm=\"ngForm\" \r\n                    (ngSubmit)=\"verifyCode(verifyCodeForm)\">                    \r\n                        <div class=\"g-fs-14 g-fw-500 g-blue3-clr g-pb-20\">\r\n                            Get a verification code\r\n                        </div>\r\n                        <div class=\"form-group g-mt-03 g-mb-0\">\r\n                            <label for=\"verification-code\" class=\"g-fs-07 g-black14-clr g-fw-500\">\r\n                                Enter the verification code sent to your email\r\n                            </label>\r\n                            <input type=\"text\" name=\"verification-code\" \r\n                            class=\"form-control g-blue8-bg\"\r\n                            formControlName=\"verificationCode\"\r\n                            [ngClass]=\"{\r\n                                error:\r\n                                  (formControlStep2.verificationCode.touched ||\r\n                                    isSubmitted.Step2) &&\r\n                                    formControlStep2.verificationCode?.errors\r\n                                }\">\r\n                            <div class=\"err-resp\">\r\n                                <span class=\"field-err\"\r\n                                    *ngIf=\"\r\n                                    (formControlStep2.verificationCode.touched || isSubmitted.Step2) &&\r\n                                    formControlStep2.verificationCode.errors?.required\r\n                                    \">\r\n                                    Verification code is required\r\n                                </span>\r\n                            </div>    \r\n                        </div>\r\n                        <div class=\"resend-verification-code text-right\">\r\n                            <span class=\"g-fs-06 g-fw-500 g-blue-clr g-cursor-pointer\" (click)=\"resendCode()\">\r\n                                Resend verification code&nbsp;\r\n                                <i class=\"fas fa-circle-notch fa-spin\" *ngIf=\"resendCodeLoading\"></i>\r\n                            </span>\r\n                        </div>\r\n                        <div class=\"g-mt-12\">\r\n                            <button type=\"submit\" class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\">\r\n                                Next&nbsp;\r\n                                <i class=\"fas fa-circle-notch fa-spin\" *ngIf=\"step2Loading\"></i>\r\n                            </button>\r\n                        </div>\r\n                    </form>\r\n                </div>\r\n            </div>\r\n            <!-- step 3 -->\r\n            <div class=\"step-card-wrp\" [hidden]=\"forgotPasswordStep3\">\r\n                <form [formGroup]=\"ForgotPassword.Step3\" #resetPasswordForm=\"ngForm\" \r\n                    (ngSubmit)=\"resetPassword(resetPasswordForm)\">\r\n                    <div class=\"g-fs-14 g-fw-500 g-blue3-clr g-pb-20\">\r\n                        Reset Password\r\n                    </div>\r\n                    <div class=\"form-group g-mt-03\">\r\n                        <label for=\"new-password\" class=\"g-fs-07 g-black14-clr g-fw-500\">\r\n                            Enter your new password\r\n                        </label>\r\n                        <input type=\"password\" name=\"new-password\" class=\"form-control g-blue8-bg\" formControlName=\"password\"\r\n                        [ngClass]=\"{\r\n                            error:\r\n                              (formControlStep3.password.touched ||\r\n                                isSubmitted.Step3) &&\r\n                                formControlStep3.password?.errors\r\n                            }\">\r\n                        <div class=\"err-resp\">\r\n                            <span class=\"field-err\"\r\n                                *ngIf=\"\r\n                                (formControlStep3.password.touched || isSubmitted.Step3) &&\r\n                                formControlStep3.password.errors?.required\r\n                                \">\r\n                                Password is required\r\n                            </span>\r\n                            <span class=\"field-err\"\r\n                                *ngIf=\"\r\n                                (formControlStep3.password.touched || isSubmitted.Step3) &&\r\n                                formControlStep3.password.errors?.pattern\r\n                                \">\r\n                                Password should have minimum 8 characters, at least one special character and one number\r\n                            </span>\r\n                        </div>    \r\n                    </div>\r\n                    <div class=\"form-group g-mt-03\">\r\n                        <label for=\"confirm-password\" class=\"g-fs-07 g-black14-clr g-fw-500\">\r\n                            *Confirm password\r\n                        </label>\r\n                        <input type=\"password\" name=\"confirm-password\" class=\"form-control g-blue8-bg\" formControlName=\"confirmPassword\"\r\n                        [ngClass]=\"{\r\n                            error:\r\n                              (formControlStep3.confirmPassword.touched ||\r\n                                isSubmitted.Step3) &&\r\n                                formControlStep3.confirmPassword?.errors\r\n                            }\">\r\n                        <div class=\"err-resp\">\r\n                            <span class=\"field-err\"\r\n                                *ngIf=\"\r\n                                (formControlStep3.confirmPassword.touched || isSubmitted.Step3) &&\r\n                                formControlStep3.confirmPassword.errors?.required\r\n                                \">\r\n                                Confirm Password is required\r\n                            </span>\r\n                            <span class=\"field-err\"\r\n                                *ngIf=\"\r\n                                (formControlStep3.confirmPassword.touched || isSubmitted.Step3) &&\r\n                                formControlStep3.confirmPassword.errors?.passwordMismatch\r\n                                \">\r\n                                Passwords doesn't match\r\n                            </span>\r\n                        </div> \r\n                    </div>\r\n                    <div class=\"g-mt-12\">\r\n                        <button type=\"submit\" class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04\">\r\n                            Reset&nbsp;\r\n                            <i class=\"fas fa-circle-notch fa-spin\" *ngIf=\"step3Loading\"></i>\r\n                        </button>\r\n                    </div>\r\n                </form> \r\n            </div>\r\n          </div>\r\n    </div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/users/login/login.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/users/login/login.component.html ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"login-parent-wrp\">\r\n\t<div class=\"left-bg-lyr g-pt-20 g-pb-20\">\r\n\t\t<div class=\"right-bg-lyr\">\r\n\t\t\t<div class=\"container-fluid l-login-container\">\r\n\t\t\t\t<div class=\"row\">\r\n\t\t\t\t\t<div class=\"col-md-5\"></div>\r\n\t\t\t\t\t<div class=\"col-md-1\"></div>\r\n\t\t\t\t\t<div class=\"col-md-6\">\r\n\t\t\t\t\t\t<div class=\"l-login-card g-mt-50 g-mb-50 g-pt-20 g-pb-10\">\r\n\t\t\t\t\t\t\t<div class=\"l-login-hdr g-fs-18 g-fw-500 primary-green-clr text-center g-mb-20\">Welcome to Ci<sup class=\"g-fs-09\">X</sup></div>\r\n\t\t\t\t\t\t\t<form [formGroup]=\"loginForm\" #loginform=\"ngForm\" (ngSubmit)=\"logIn(loginform)\">\r\n\t\t\t\t\t\t\t\t<div class=\"form-group g-mt-03\">\r\n\t\t\t\t\t\t\t\t\t<label for=\"email\" class=\"g-fs-07 g-black14-clr g-fw-500\">Email</label>\r\n\t\t\t\t\t\t\t\t\t<input\r\n\t\t\t\t\t\t\t\t\t\ttype=\"email\"\r\n\t\t\t\t\t\t\t\t\t\tclass=\"form-control g-white-bg\"\r\n\t\t\t\t\t\t\t\t\t\tname=\"email\"\r\n\t\t\t\t\t\t\t\t\t\tplaceholder=\"Email\"\r\n\t\t\t\t\t\t\t\t\t\tformControlName=\"email\"\r\n\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{ error: (loginFormControl.email.touched || isSubmitted) && loginFormControl.email?.errors }\"\r\n\t\t\t\t\t\t\t\t\t/>\r\n\t\t\t\t\t\t\t\t\t<div class=\"err-resp\">\r\n\t\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(loginFormControl.email.touched || isSubmitted) && loginFormControl.email.errors?.required\"> Email is required </span>\r\n\t\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(loginFormControl.email.touched || isSubmitted) && loginFormControl.email.errors?.email\"> The email that you've entered is invalid </span>\r\n\t\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"isSubmitted && loginFormControl.email.errors?.incorrect\"> The email that you've entered is incorrect </span>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"form-group g-mt-03\">\r\n\t\t\t\t\t\t\t\t\t<label for=\"password\" class=\"g-fs-07 g-black14-clr g-fw-500\">Password</label>\r\n\t\t\t\t\t\t\t\t\t<div class=\"pswd-input-wrp\">\r\n\t\t\t\t\t\t\t\t\t\t<input\r\n\t\t\t\t\t\t\t\t\t\t\t[type]=\"passwordField ? 'text' : 'password'\"\r\n\t\t\t\t\t\t\t\t\t\t\tclass=\"form-control g-white-bg\"\r\n\t\t\t\t\t\t\t\t\t\t\tname=\"password\"\r\n\t\t\t\t\t\t\t\t\t\t\tplaceholder=\"Password\"\r\n\t\t\t\t\t\t\t\t\t\t\tformControlName=\"password\"\r\n\t\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{ error: (loginFormControl.password.touched || isSubmitted) && loginFormControl.password?.errors }\"\r\n\t\t\t\t\t\t\t\t\t\t/>\r\n\t\t\t\t\t\t\t\t\t\t<span class=\"pswd-tgl\">\r\n\t\t\t\t\t\t\t\t\t\t\t<i\r\n\t\t\t\t\t\t\t\t\t\t\t\tclass=\"fa\"\r\n\t\t\t\t\t\t\t\t\t\t\t\t[ngClass]=\"{\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t'fa-eye-slash': !passwordField,\r\n\t\t\t\t\t\t\t\t\t\t\t\t\t'fa-eye': passwordField\r\n\t\t\t\t\t\t\t\t\t\t\t\t}\"\r\n\t\t\t\t\t\t\t\t\t\t\t\t(click)=\"togglePassword()\"\r\n\t\t\t\t\t\t\t\t\t\t\t>\r\n\t\t\t\t\t\t\t\t\t\t\t</i>\r\n\t\t\t\t\t\t\t\t\t\t</span>\r\n\t\t\t\t\t\t\t\t\t\t<div class=\"err-resp\">\r\n\t\t\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"(loginFormControl.password.touched || isSubmitted) && loginFormControl.password.errors?.required\"> Password is required </span>\r\n\t\t\t\t\t\t\t\t\t\t\t<span class=\"field-err\" *ngIf=\"isSubmitted && loginFormControl.password.errors?.incorrect\"> The password that you've entered is incorrect </span>\r\n\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"g-fs-07 g-fw-500\">\r\n\t\t\t\t\t\t\t\t\t<a [routerLink]=\"['/login/forgot-password']\" class=\"g-p-clr\">Forgot Password</a>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div class=\"g-pb-10 g-pt-10\">\r\n\t\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04 g-fw-500\">\r\n\t\t\t\t\t\t\t\t\t\tLogin&nbsp;\r\n\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-circle-notch fa-spin\" *ngIf=\"isLoading\"></i>\r\n\t\t\t\t\t\t\t\t\t</button>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t<div>\r\n\t\t\t\t\t\t\t\t\t<div class=\"g-fs-07 text-center g-fw-500\">\r\n\t\t\t\t\t\t\t\t\t\tNew to Ci<sup class=\"g-fs-04\">X</sup>?\r\n\t\t\t\t\t\t\t\t\t\t<a [routerLink]=\"['/register']\">\r\n\t\t\t\t\t\t\t\t\t\t\t<span class=\"g-p-clr\">&nbsp;Sign Up</span>\r\n\t\t\t\t\t\t\t\t\t\t</a>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</form>\r\n\t\t\t\t\t\t\t<div class=\"g-pb-10\">\r\n\t\t\t\t\t\t\t\t<div class=\"g-fs-07 g-fw-500\">Sign Up via</div>\r\n\t\t\t\t\t\t\t\t<button class=\"oauth-login btn g-p-bg g-w-clr g-w-100per g-fs-08 g-pt-04 g-pb-04 g-fw-500\">#startupindia</button>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/users/select-challenge-sector/select-challenge-sector.component.html":
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/users/select-challenge-sector/select-challenge-sector.component.html ***!
  \****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"select-challenge-sector-wrp\">\r\n    <div class=\"container g-pt-40 g-pb-40\">\r\n        <div class=\"text-center g-fs-08 g-black9-clr g-fw-500 g-pb-06\">\r\n            Follow Solution Areas that interest you.\r\n        </div>\r\n        <div class=\"g-pb-20 g-fs-18 g-fw-500 g-blue3-clr text-center\">\r\n            What are you working on?\r\n        </div>\r\n        <div class=\"challenge-sector-row g-pb-30\">\r\n            <div class=\"challenge-sector-card\">\r\n                <label class=\"challenge-sector-checkbox\">\r\n                    <input type=\"checkbox\" name=\"challenge-sector\" class=\"a-checkbox\" value=\"1\">\r\n                    <div class=\"challenge-sector\">\r\n                        <div>\r\n                            <div class=\"g-pb-06\">\r\n                                <svg width=\"50\" height=\"50\" viewBox=\"0 0 50 50\" fill=\"none\"\r\n                                    xmlns=\"http://www.w3.org/2000/svg\">\r\n                                    <path\r\n                                        d=\"M29.9858 26.4092L29.9858 26.4053C30.0035 24.9371 29.5763 23.6388 28.7409 22.3986L28.7409 22.3986L28.7385 22.395C27.5641 20.6352 26.4122 18.8599 25.2675 17.0952C24.6811 17.9991 24.087 18.9047 23.4941 19.8084C22.865 20.7672 22.2373 21.7238 21.6218 22.674C20.1135 25.0081 20.1938 27.9858 21.664 29.8834C22.5547 31.029 23.6901 31.6837 25.0919 31.8488C25.7973 31.9282 26.5197 31.6962 27.2772 31.2458L27.2772 31.2458L27.2836 31.242C29.1038 30.1781 29.968 28.5871 29.9858 26.4092Z\"\r\n                                        stroke=\"#3B6FD4\" stroke-width=\"2\" />\r\n                                    <path\r\n                                        d=\"M44.4436 22.6031C44.0037 19.0012 42.5739 15.7291 40.4567 13.007L43.6737 9.76252L40.2368 6.32552L37.0197 9.54255C34.3251 7.45286 31.0256 6.02307 27.4236 5.58313V1.0188H22.5843V5.55563C18.9824 5.99557 15.7103 7.42536 12.9882 9.54255L9.74372 6.35302L6.33422 9.76252L9.55125 12.9795C7.43406 15.7016 6.00427 19.0012 5.56433 22.6031H1V27.4699H5.53684C5.97677 31.0719 7.40656 34.3439 9.52375 37.066L6.30672 40.283L9.74372 43.6925L12.9607 40.4755C15.6828 42.5927 18.9549 44.0225 22.5568 44.4624V48.9993H27.4236V44.4624C31.0256 44.0225 34.2976 42.5927 37.0197 40.4755L40.2368 43.6925L43.6737 40.2555L40.4567 37.0385C42.5739 34.3164 44.0037 31.0444 44.4436 27.4424H48.9805V22.6031H44.4436ZM25.7189 38.8808C17.4976 39.2932 10.7336 32.5292 11.146 24.3079C11.5035 17.2689 17.2501 11.5223 24.2891 11.1648C32.5104 10.7524 39.2744 17.5164 38.862 25.7377C38.5045 32.7766 32.7578 38.5233 25.7189 38.8808Z\"\r\n                                        stroke=\"#3B6FD4\" stroke-width=\"1.6983\" stroke-miterlimit=\"10\" />\r\n                                </svg>\r\n                            </div>\r\n                            <div>\r\n                                <div class=\"g-fs-08 g-lh-09 g-black9-clr g-fw-500 a-cnt\">\r\n                                    WATER<br> MANAGEMENT\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </label>\r\n            </div>\r\n            <div class=\"challenge-sector-card\">\r\n                <label class=\"challenge-sector-checkbox\">\r\n                    <input type=\"checkbox\" name=\"challenge-sector\" class=\"a-checkbox\" value=\"1\">\r\n                    <div class=\"challenge-sector\">\r\n                        <div>\r\n                            <div class=\"g-pb-06\">\r\n                                <svg width=\"46\" height=\"47\" viewBox=\"0 0 46 47\" fill=\"none\"\r\n                                xmlns=\"http://www.w3.org/2000/svg\">\r\n                                <path d=\"M31.5312 0.751221H33.0428V2.26801H31.5312V0.751221Z\" fill=\"white\" />\r\n                                <path\r\n                                    d=\"M36.0664 15.9191H12.6057L23.7526 4.73352C23.8947 4.59094 23.974 4.39831 23.974 4.19734C23.974 3.99636 23.8947 3.80297 23.7526 3.66115L21.6153 1.51641C20.7582 0.656394 19.2648 0.656394 18.4085 1.51641L16.6823 3.24859L17.751 4.32095L19.4779 2.58878C19.7629 2.30211 20.2609 2.30211 20.5466 2.58878L22.1503 4.19734L3.97931 22.4306L2.37632 20.8213C2.23348 20.6788 2.15488 20.4884 2.15488 20.2852C2.15488 20.0819 2.23348 19.8923 2.37632 19.749L16.2395 5.83774L15.1708 4.76537L14.1331 5.80665L13.0645 4.73428C12.1794 3.8462 10.7412 3.84696 9.85771 4.73428L4.51364 10.0969C3.62939 10.9842 3.62939 12.4274 4.51364 13.3147L5.58231 14.3871L1.3069 18.6774C0.878379 19.1074 0.642578 19.6784 0.642578 20.2867C0.642578 20.8949 0.878379 21.466 1.3069 21.8952L3.44423 24.0407C3.58631 24.1818 3.77903 24.2614 3.97931 24.2614C4.17959 24.2614 4.37231 24.1818 4.51364 24.0392L8.53284 20.0061L11.7154 44.2769C11.8635 45.4039 12.8294 46.2548 13.9631 46.2548H30.9619C32.0955 46.2548 33.0614 45.4039 33.2103 44.2762L35.8215 24.36L34.3228 24.1621L31.7116 44.0775C31.6617 44.4544 31.3398 44.7381 30.9619 44.7381H13.9631C13.5852 44.7381 13.2632 44.4544 13.2141 44.0783L9.88038 18.6538L11.0942 17.4359H35.2048L34.7203 21.1292L36.219 21.3272L36.8161 16.7768C36.8448 16.5599 36.7791 16.3423 36.6355 16.1777C36.4911 16.0131 36.284 15.9191 36.0664 15.9191ZM5.58306 12.2416C5.28831 11.9458 5.28831 11.465 5.58306 11.1685L10.9271 5.80589C11.2211 5.51087 11.701 5.51012 11.9965 5.80589L13.0652 6.87826L6.65248 13.3132L5.58306 12.2416Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M20.1953 22.7447V39.4293C20.1953 40.6837 21.2126 41.7045 22.4626 41.7045C23.7127 41.7045 24.7299 40.6837 24.7299 39.4293V22.7447C24.7299 21.4903 23.7127 20.4695 22.4626 20.4695C21.2126 20.4695 20.1953 21.4903 20.1953 22.7447ZM23.2184 22.7447V39.4293C23.2184 39.8472 22.8791 40.1877 22.4626 40.1877C22.0462 40.1877 21.7069 39.8472 21.7069 39.4293V22.7447C21.7069 22.3268 22.0462 21.9863 22.4626 21.9863C22.8791 21.9863 23.2184 22.3268 23.2184 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M14.1484 22.7447V39.4293C14.1484 40.6837 15.1657 41.7045 16.4158 41.7045C17.6658 41.7045 18.6831 40.6837 18.6831 39.4293V22.7447C18.6831 21.4903 17.6658 20.4695 16.4158 20.4695C15.1657 20.4695 14.1484 21.4903 14.1484 22.7447ZM17.1715 22.7447V39.4293C17.1715 39.8472 16.8322 40.1877 16.4158 40.1877C15.9993 40.1877 15.66 39.8472 15.66 39.4293V22.7447C15.66 22.3268 15.9993 21.9863 16.4158 21.9863C16.8322 21.9863 17.1715 22.3268 17.1715 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M26.2402 22.7447V39.4293C26.2402 40.6837 27.2575 41.7045 28.5076 41.7045C29.7576 41.7045 30.7749 40.6837 30.7749 39.4293V22.7447C30.7749 21.4903 29.7576 20.4695 28.5076 20.4695C27.2575 20.4695 26.2402 21.4903 26.2402 22.7447ZM29.2633 22.7447V39.4293C29.2633 39.8472 28.924 40.1877 28.5076 40.1877C28.0911 40.1877 27.7518 39.8472 27.7518 39.4293V22.7447C27.7518 22.3268 28.0911 21.9863 28.5076 21.9863C28.924 21.9863 29.2633 22.3268 29.2633 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M26.4245 9.1163L23.4014 8.3579C23.1059 8.28434 22.7953 8.39506 22.6139 8.63851L20.3466 11.6721C20.2121 11.8518 20.1637 12.0824 20.2159 12.3016C20.2673 12.5207 20.4131 12.705 20.6134 12.8059L23.6365 14.3227C23.74 14.375 23.8564 14.4023 23.9736 14.4023H27.7524C28.0033 14.4023 28.2376 14.2772 28.3782 14.0694C28.5188 13.8616 28.5475 13.5961 28.4545 13.3625L26.943 9.57057C26.8523 9.34457 26.6596 9.17545 26.4245 9.1163ZM24.1519 12.8855L22.0985 11.8556L23.5216 9.95205L25.6824 10.4943L26.6361 12.8855H24.1519Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M35.9554 7.93473L35.2306 6.47937C35.0779 6.17298 34.7386 6.00765 34.406 6.07515L30.6272 6.83354C30.2735 6.90407 30.0195 7.21501 30.0195 7.57677V9.09356C30.0195 9.15575 30.0271 9.21718 30.0422 9.27785L30.798 12.3114C30.8826 12.6519 31.188 12.8855 31.5303 12.8855C31.5621 12.8855 31.593 12.884 31.6248 12.8795L37.671 12.1211C37.9385 12.0877 38.1675 11.914 38.2726 11.6645C38.3776 11.415 38.3428 11.1291 38.1811 10.9129L35.9554 7.93473ZM32.1017 11.2914L31.5311 9.00027V8.19865L34.1362 7.67612L34.6335 8.67492C34.6539 8.71588 34.6781 8.75456 34.7053 8.79096L36.1912 10.7795L32.1017 11.2914Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M38.1855 5.4586L39.1068 6.66141C40.7778 5.37366 42.922 4.87312 44.9875 5.28645L45.2845 3.79923C42.7874 3.29869 40.2012 3.90389 38.1855 5.4586Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path d=\"M41.3555 8.33514H42.867V9.85193H41.3555V8.33514Z\" fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M34.5527 4.54319H36.0643C36.0643 3.28881 37.0815 2.26801 38.3316 2.26801V0.751221C36.2479 0.751221 34.5527 2.4523 34.5527 4.54319Z\"\r\n                                    fill=\"white\" />\r\n                            </svg>\r\n                            </div>\r\n                            <div>\r\n                                <div class=\"g-fs-08 g-lh-09 g-black9-clr g-fw-500 a-cnt\">\r\n                                    WASTE<br> MANAGEMENT\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </label>\r\n            </div>\r\n            <div class=\"challenge-sector-card\">\r\n                <label class=\"challenge-sector-checkbox\">\r\n                    <input type=\"checkbox\" name=\"challenge-sector\" class=\"a-checkbox\" value=\"1\">\r\n                    <div class=\"challenge-sector\">\r\n                        <div>\r\n                            <div class=\"g-pb-06\">\r\n                                <svg width=\"38\" height=\"43\" viewBox=\"0 0 38 43\" fill=\"none\"\r\n                                xmlns=\"http://www.w3.org/2000/svg\">\r\n                                <path\r\n                                    d=\"M25.7184 28.9839H23.5901C22.694 28.9839 21.9648 29.816 21.9648 30.8394V33.2694C21.9648 34.2924 22.694 35.1249 23.5901 35.1249H25.7184C26.6145 35.1249 27.3437 34.2924 27.3437 33.2694V30.8394C27.3437 29.8164 26.6145 28.9839 25.7184 28.9839ZM26.2534 33.2694C26.2534 33.6062 26.0135 33.8801 25.7184 33.8801H23.5901C23.2951 33.8801 23.0551 33.6062 23.0551 33.2694V30.8394C23.0551 30.5026 23.2951 30.2287 23.5901 30.2287H25.7184C26.0135 30.2287 26.2534 30.5026 26.2534 30.8394V33.2694Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M32.8415 28.9839H30.7131C29.817 28.9839 29.0879 29.816 29.0879 30.8394V33.2694C29.0879 34.2924 29.817 35.1249 30.7131 35.1249H32.8415C33.7376 35.1249 34.4667 34.2924 34.4667 33.2694V30.8394C34.4667 29.8164 33.7376 28.9839 32.8415 28.9839ZM33.3764 33.2694C33.3764 33.6062 33.1365 33.8801 32.8415 33.8801H30.7131C30.4181 33.8801 30.1782 33.6062 30.1782 33.2694V30.8394C30.1782 30.5026 30.4181 30.2287 30.7131 30.2287H32.8415C33.1365 30.2287 33.3764 30.5026 33.3764 30.8394V33.2694Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M4.19177 17.9186H6.5311C7.19153 17.9186 7.72873 17.3053 7.72873 16.5509V12.4778C7.72873 11.7238 7.19153 11.1105 6.5311 11.1105H4.19177C3.53134 11.1105 2.99414 11.7238 2.99414 12.4778V16.5509C2.99414 17.3049 3.53134 17.9186 4.19177 17.9186ZM4.08445 12.4778C4.08445 12.4104 4.13271 12.3553 4.19177 12.3553H6.5311C6.59016 12.3553 6.63843 12.4104 6.63843 12.4778V16.5509C6.63843 16.6187 6.59044 16.6738 6.5311 16.6738H4.19177C4.13271 16.6738 4.08445 16.6187 4.08445 16.5509V12.4778Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M13.5456 13.8853H15.8846C16.545 13.8853 17.0825 13.2717 17.0825 12.5177V8.44455C17.0825 7.69055 16.5453 7.0769 15.8846 7.0769H13.5456C12.8851 7.0769 12.3477 7.69055 12.3477 8.44455V12.5177C12.3477 13.2717 12.8851 13.8853 13.5456 13.8853ZM13.438 8.44455C13.438 8.3768 13.4862 8.32169 13.5456 8.32169H15.8846C15.944 8.32169 15.9922 8.3768 15.9922 8.44455V12.5177C15.9922 12.5854 15.944 12.6405 15.8846 12.6405H13.5456C13.4862 12.6405 13.438 12.5854 13.438 12.5177V8.44455Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M13.5456 22.6818H15.8846C16.545 22.6818 17.0825 22.0682 17.0825 21.3142V17.2411C17.0825 16.4871 16.5453 15.8734 15.8846 15.8734H13.5456C12.8851 15.8734 12.3477 16.4871 12.3477 17.2411V21.3142C12.3477 22.0682 12.8851 22.6818 13.5456 22.6818ZM13.438 17.2411C13.438 17.1733 13.4862 17.1182 13.5456 17.1182H15.8846C15.944 17.1182 15.9922 17.1733 15.9922 17.2411V21.3142C15.9922 21.3819 15.944 21.437 15.8846 21.437H13.5456C13.4862 21.437 13.438 21.3819 13.438 21.3142V17.2411Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M21.651 13.8853H23.9901C24.6505 13.8853 25.188 13.2717 25.188 12.5177V8.44455C25.188 7.69055 24.6508 7.0769 23.9901 7.0769H21.651C20.9906 7.0769 20.4531 7.69055 20.4531 8.44455V12.5177C20.4531 13.2717 20.9906 13.8853 21.651 13.8853ZM21.5434 8.44455C21.5434 8.3768 21.5917 8.32169 21.651 8.32169H23.9901C24.0494 8.32169 24.0977 8.3768 24.0977 8.44455V12.5177C24.0977 12.5854 24.0494 12.6405 23.9901 12.6405H21.651C21.5917 12.6405 21.5434 12.5854 21.5434 12.5177V8.44455Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M21.651 22.6818H23.9901C24.6505 22.6818 25.188 22.0682 25.188 21.3142V17.2411C25.188 16.4871 24.6508 15.8734 23.9901 15.8734H21.651C20.9906 15.8734 20.4531 16.4871 20.4531 17.2411V21.3142C20.4531 22.0682 20.9906 22.6818 21.651 22.6818ZM21.5434 17.2411C21.5434 17.1733 21.5917 17.1182 21.651 17.1182H23.9901C24.0494 17.1182 24.0977 17.1733 24.0977 17.2411V21.3142C24.0977 21.3819 24.0494 21.437 23.9901 21.437H21.651C21.5917 21.437 21.5434 21.3819 21.5434 21.3142V17.2411Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M6.5311 27.0279C7.19153 27.0279 7.72873 26.4146 7.72873 25.6603V21.5872C7.72873 20.8332 7.19153 20.2198 6.5311 20.2198H4.19177C3.53134 20.2198 2.99414 20.8332 2.99414 21.5872V25.6603C2.99414 26.4143 3.53134 27.0279 4.19177 27.0279H6.5311ZM4.08445 25.6606V21.5875C4.08445 21.5197 4.13271 21.4646 4.19177 21.4646H6.5311C6.59016 21.4646 6.63843 21.5197 6.63843 21.5875V25.6606C6.63843 25.728 6.59044 25.7832 6.5311 25.7832H4.19177C4.13271 25.7832 4.08445 25.728 4.08445 25.6606Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M33.3377 11.1105H30.9984C30.338 11.1105 29.8008 11.7238 29.8008 12.4781V16.5512C29.8008 17.3053 30.338 17.9186 30.9984 17.9186H33.3377C33.9982 17.9186 34.5354 17.3053 34.5354 16.5512V12.4781C34.5354 11.7238 33.9982 11.1105 33.3377 11.1105ZM33.4451 16.5509C33.4451 16.6187 33.3971 16.6738 33.3377 16.6738H30.9984C30.9394 16.6738 30.8911 16.6187 30.8911 16.5509V12.4778C30.8911 12.4104 30.9394 12.3553 30.9984 12.3553H33.3377C33.3968 12.3553 33.4451 12.4104 33.4451 12.4778V16.5509Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M35.1249 7.73853H28.0581V4.96206C28.5987 4.71408 28.9823 4.11048 28.9823 3.40543V1.87732C28.9823 0.952477 28.323 0.199768 27.5129 0.199768H14.9932C14.6919 0.199768 14.448 0.478549 14.448 0.822163C14.448 1.16578 14.6919 1.44456 14.9932 1.44456H27.5129C27.7219 1.44456 27.892 1.63873 27.892 1.87732V3.40575C27.892 3.64434 27.7219 3.83851 27.5129 3.83851H10.0195C9.81052 3.83851 9.64045 3.64434 9.64045 3.40575V1.87732C9.64045 1.63873 9.81024 1.44456 10.0195 1.44456H12.8126C13.1135 1.44456 13.3577 1.16578 13.3577 0.822163C13.3577 0.478549 13.1135 0.199768 12.8126 0.199768H10.0195C9.20915 0.199768 8.55014 0.952153 8.55014 1.87732V3.40575C8.55014 4.11048 8.93345 4.7144 9.47435 4.96206V7.73885H2.40724C1.1673 7.73853 0.158203 8.89061 0.158203 10.3066V42.0037C0.158203 42.3473 0.402386 42.626 0.703355 42.626H36.8288C37.1298 42.626 37.3739 42.3473 37.3739 42.0037V10.3066C37.3739 8.89061 36.3648 7.73853 35.1249 7.73853ZM10.5647 5.08298H26.9678V24.8113H16.1349C14.8529 24.8113 13.5954 25.0706 12.3969 25.5818C11.7603 25.8535 11.1447 26.1942 10.5647 26.5981V5.08298ZM9.61489 28.9729C10.3338 28.2144 11.1584 27.5803 12.0425 27.1041V29.9616C12.0425 32.0486 10.5553 33.7465 8.72732 33.7465H5.62733C5.85959 33.3287 6.13273 32.9381 6.4391 32.588C6.44052 32.5864 6.44165 32.5847 6.44307 32.5834C6.44307 32.5834 9.52432 29.0685 9.61489 28.9729ZM1.24851 10.3066C1.24851 9.57686 1.76839 8.98332 2.40724 8.98332H9.47435V27.4701C9.1623 27.7544 8.86304 28.0594 8.5774 28.3855C8.5774 28.3855 5.67248 31.7027 5.67219 31.7027C4.39449 33.1621 3.64519 35.1709 3.61197 37.2339H1.24851V10.3066ZM36.2836 37.2342H29.8213C29.5201 37.2342 29.2762 37.5127 29.2762 37.8569C29.2762 38.2006 29.5201 38.4793 29.8213 38.4793H36.2836V41.3813H1.24851V38.479L27.6407 38.4793C27.9417 38.4793 28.1858 38.2006 28.1858 37.8566C28.1858 37.5127 27.9417 37.2342 27.6407 37.2342H20.5106V31.2907C20.5106 30.0187 19.6042 28.9839 18.4901 28.9839H16.5707C15.4565 28.9839 14.5502 30.0187 14.5502 31.2907V37.2342H4.70455C4.7054 37.1895 4.70597 37.1448 4.70767 37.1C4.73351 36.3797 4.86014 35.6656 5.0836 34.9913H8.72732C11.1564 34.9913 13.1328 32.7351 13.1328 29.9616V26.6062C13.1385 26.6042 13.1445 26.6016 13.1501 26.5997C14.0744 26.2538 15.0446 26.0707 16.017 26.057C16.0562 26.0564 36.2836 26.0561 36.2836 26.0561V37.2342ZM15.6405 37.2342V31.2907C15.6405 30.7049 16.0579 30.2287 16.5707 30.2287H18.4901C19.0032 30.2287 19.4203 30.7049 19.4203 31.2907V37.2342H15.6405ZM30.8937 24.8113V21.5871C30.8937 21.5197 30.942 21.4646 31.0013 21.4646H33.3404C33.3997 21.4646 33.448 21.5194 33.448 21.5871V24.8113H30.8937ZM36.2836 24.8113H34.538V21.5871C34.538 20.8331 34.0008 20.2198 33.3404 20.2198H31.001C30.3406 20.2198 29.8034 20.8331 29.8034 21.5871V24.8113H28.0578V8.98332H35.1249C35.7637 8.98332 36.2836 9.57686 36.2836 10.3066V24.8113Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                            </svg>\r\n                            </div>\r\n                            <div>\r\n                                <div class=\"g-fs-08 g-lh-09 g-black9-clr g-fw-500 a-cnt\">\r\n                                    URBAN INFRA AND BUILDINGS\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </label>\r\n            </div>\r\n            <div class=\"challenge-sector-card\">\r\n                <label class=\"challenge-sector-checkbox\">\r\n                    <input type=\"checkbox\" name=\"challenge-sector\" class=\"a-checkbox\" value=\"1\">\r\n                    <div class=\"challenge-sector\">\r\n                        <div>\r\n                            <div class=\"g-pb-06\">\r\n                                <svg width=\"35\" height=\"46\" viewBox=\"0 0 35 46\" fill=\"none\"\r\n                                xmlns=\"http://www.w3.org/2000/svg\">\r\n                                <path\r\n                                    d=\"M34.1455 25.8916H29.4043V22.7411C29.4043 22.3368 29.1899 21.985 28.8857 21.8903L26.1914 21.0515C25.591 15.8457 22.2719 11.8049 18.161 11.3984V9.08899H25.6114C25.8853 9.08899 26.1323 8.87572 26.2372 8.54877C26.342 8.22174 26.284 7.84534 26.0904 7.59505L23.86 4.71332L26.0903 1.83159C26.284 1.5813 26.342 1.20491 26.2371 0.877867C26.1323 0.550917 25.8853 0.337646 25.6114 0.337646H17.4837C17.1096 0.337646 16.8064 0.729532 16.8064 1.21278V11.3984C12.6958 11.8049 9.37641 15.8453 8.77597 21.0515L6.08163 21.8903C5.77745 21.985 5.56302 22.3368 5.56302 22.7411V25.8916H0.821842C0.447763 25.8916 0.144531 26.2835 0.144531 26.7667V44.2694C0.144531 44.7527 0.447763 45.1445 0.821842 45.1445H14.4358C14.8099 45.1445 15.1131 44.7527 15.1131 44.2694C15.1131 43.7862 14.8099 43.3943 14.4358 43.3943C13.111 43.3943 7.78161 43.3943 6.91764 43.3943V41.644H28.0497V43.3943H20.5316C20.1575 43.3943 19.8543 43.7862 19.8543 44.2694C19.8543 44.7527 20.1575 45.1445 20.5316 45.1445H34.1455C34.5196 45.1445 34.8228 44.7527 34.8228 44.2694V26.7667C34.8228 26.2835 34.5196 25.8916 34.1455 25.8916ZM18.161 2.08792H23.9762L22.4232 4.09451C22.1587 4.43625 22.1587 4.99039 22.4232 5.33222L23.9762 7.33872H18.161V2.08792ZM17.4837 13.1146C21.0277 13.1146 23.9988 16.2569 24.7507 20.6029L17.6423 18.3898C17.538 18.3573 17.4292 18.3573 17.3249 18.3898L10.2165 20.6029C10.9686 16.2569 13.9397 13.1146 17.4837 13.1146ZM6.91764 23.4304C8.3238 22.9926 16.5606 20.4281 17.4837 20.1407L28.0497 23.4304V25.8916H6.91764V23.4304ZM10.9815 27.6419V39.8937H9.62688V27.6419H10.9815ZM12.3361 27.6419H15.4517V39.8937H12.3361V27.6419ZM16.8064 27.6419H18.161V39.8937H16.8064V27.6419ZM19.5156 27.6419H22.6312V39.8937H19.5156V27.6419ZM23.9859 27.6419H25.3405V39.8937H23.9859V27.6419ZM1.49915 43.3943V27.6419H8.27226V39.8937H6.91764V37.2683C6.91764 36.7851 6.6144 36.3932 6.24033 36.3932H3.53108C3.15701 36.3932 2.85377 36.7851 2.85377 37.2683V40.7689C2.85377 41.2521 3.15701 41.644 3.53108 41.644H5.56302V43.3943H1.49915ZM5.56302 39.8937H4.20839V38.1435H5.56302V39.8937ZM33.4682 43.3943H29.4043V41.644H31.4363C31.8104 41.644 32.1136 41.2521 32.1136 40.7689V37.2683C32.1136 36.7851 31.8104 36.3932 31.4363 36.3932H28.727C28.353 36.3932 28.0497 36.7851 28.0497 37.2683V39.8937H26.6951V27.6419H33.4682V43.3943ZM29.4043 39.8937V38.1435H30.759V39.8937H29.4043Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M28.0508 30.2673V33.7678C28.0508 34.251 28.354 34.6429 28.7281 34.6429H31.4373C31.8114 34.6429 32.1146 34.251 32.1146 33.7678V30.2673C32.1146 29.784 31.8114 29.3921 31.4373 29.3921H28.7281C28.354 29.3921 28.0508 29.784 28.0508 30.2673ZM29.4054 31.1424H30.76V32.8927H29.4054V31.1424Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M3.52887 34.6429H6.23811C6.61219 34.6429 6.91542 34.251 6.91542 33.7678V30.2673C6.91542 29.784 6.61219 29.3921 6.23811 29.3921H3.52887C3.15479 29.3921 2.85156 29.784 2.85156 30.2673V33.7678C2.85156 34.251 3.15479 34.6429 3.52887 34.6429ZM4.20618 31.1424H5.5608V32.8927H4.20618V31.1424Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M17.482 45.1445C17.8561 45.1445 18.1593 44.7527 18.1593 44.2694C18.1593 43.7861 17.8561 43.3943 17.482 43.3943C17.1079 43.3943 16.8047 43.7861 16.8047 44.2694C16.8047 44.7527 17.1079 45.1445 17.482 45.1445Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                            </svg>\r\n                            </div>\r\n                            <div>\r\n                                <div class=\"g-fs-08 g-lh-09 g-black9-clr g-fw-500 a-cnt\">\r\n                                    <br>\r\n                                    GOVERNANCE\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </label>\r\n            </div>\r\n            <div class=\"challenge-sector-card\">\r\n                <label class=\"challenge-sector-checkbox\">\r\n                    <input type=\"checkbox\" name=\"challenge-sector\" class=\"a-checkbox\" value=\"1\">\r\n                    <div class=\"challenge-sector\">\r\n                        <div>\r\n                            <div class=\"g-pb-06\">\r\n                                <svg width=\"44\" height=\"46\" viewBox=\"0 0 44 46\" fill=\"none\"\r\n                                xmlns=\"http://www.w3.org/2000/svg\">\r\n                                <path\r\n                                    d=\"M22.7308 17.1541C22.3228 16.9382 21.827 17.1148 21.6239 17.5484L19.3895 22.3174C19.1862 22.7511 19.3524 23.2778 19.7605 23.4937C19.8579 23.5452 19.9601 23.5732 20.0621 23.5819C20.0796 23.5841 20.0993 23.5853 20.1218 23.5855C20.1238 23.5855 20.1258 23.5859 20.1278 23.5859C20.1286 23.5859 20.1294 23.5857 20.1301 23.5857H22.3893L20.7507 27.0867C20.5477 27.5205 20.714 28.0471 21.1222 28.2629C21.2402 28.3253 21.3656 28.3548 21.4891 28.3548C21.7926 28.3548 22.0846 28.1764 22.2289 27.868L24.461 23.0991C24.664 22.6653 24.4977 22.1387 24.0895 21.9229C23.9751 21.8624 23.854 21.8338 23.7342 21.8321C23.7298 21.832 23.7264 21.8311 23.7219 21.8311H21.4616L23.1017 18.3304C23.3051 17.8966 23.1389 17.37 22.7308 17.1541V17.1541Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M40.6327 17.7465H39.6058C39.1875 16.0559 38.5586 14.442 37.7298 12.9323L38.4558 12.1608C38.913 11.6749 39.1647 11.0272 39.1647 10.3369C39.1647 9.64657 38.913 8.99887 38.4558 8.51303L35.2846 5.14304C34.3383 4.13741 32.7984 4.13741 31.8519 5.14304L31.1259 5.91461C29.703 5.03206 28.1842 4.36279 26.5958 3.91853V2.82982C26.5958 1.40731 25.5068 0.25 24.1682 0.25H19.6828C18.3455 0.25 17.2575 1.40731 17.2575 2.82982V3.91853C15.6691 4.36279 14.1503 5.03206 12.7272 5.91461L12.0013 5.14304C11.0549 4.13732 9.51499 4.1375 8.5686 5.14304L5.39747 8.51303C4.94021 8.99887 4.68842 9.64657 4.68842 10.3369C4.68842 11.0272 4.94021 11.6749 5.39739 12.1608L6.12337 12.9323C5.29296 14.4444 4.66324 16.0584 4.24519 17.7465H3.22062C1.88201 17.7465 0.792969 18.9028 0.792969 20.3239V25.0904C0.792969 26.5129 1.88201 27.6702 3.22062 27.6702H4.24519C4.66341 29.3592 5.29321 30.9728 6.12361 32.4828L5.39756 33.2559C4.94029 33.7417 4.6885 34.3894 4.6885 35.0798C4.6885 35.7701 4.94029 36.4178 5.39747 36.9036L8.56868 40.2736C9.51499 41.2793 11.0549 41.2793 12.0013 40.2736L12.7273 39.5021C14.1504 40.3847 15.6692 41.0539 17.2576 41.4981V42.5868C17.2576 44.0094 18.3456 45.1667 19.6829 45.1667H24.1682C25.5068 45.1667 26.5959 44.0094 26.5959 42.5868V41.4981C28.1843 41.054 29.7031 40.3847 31.1262 39.5021L31.8522 40.2736C32.7985 41.2793 34.3384 41.2793 35.2848 40.2736L38.4559 36.9036C38.9131 36.4178 39.1649 35.7701 39.1649 35.0798C39.1649 34.3894 38.9131 33.7417 38.4565 33.2566L37.7298 32.4827C38.5584 30.9751 39.1874 29.3616 39.606 27.6702H40.6328C41.9714 27.6702 43.0604 26.5129 43.0604 25.0904V20.3239C43.0604 18.9028 41.9713 17.7465 40.6327 17.7465V17.7465ZM41.4093 25.0904C41.4093 25.5455 41.0609 25.9156 40.6327 25.9156H38.9575C38.5712 25.9156 38.2367 26.2002 38.152 26.6007C37.7347 28.5749 37.0075 30.4404 35.9904 32.1453C35.7837 32.4919 35.8306 32.9444 36.1033 33.2348L37.2884 34.4967C37.4337 34.6512 37.5138 34.8583 37.5138 35.0799C37.5138 35.3015 37.4337 35.5086 37.2884 35.663L34.1173 39.033C33.8146 39.3545 33.3222 39.3546 33.0196 39.033L31.8351 37.7742C31.5621 37.484 31.1361 37.4338 30.8098 37.6533C29.1985 38.7372 27.4421 39.511 25.5894 39.9532C25.2125 40.0432 24.9447 40.3987 24.9447 40.8092V42.5869C24.9447 43.0421 24.5964 43.4122 24.1682 43.4122H19.6828C19.2559 43.4122 18.9086 43.042 18.9086 42.5869V40.8092C18.9086 40.3987 18.6408 40.0433 18.2639 39.9532C16.4113 39.5111 14.6549 38.7372 13.0435 37.6533C12.9076 37.5619 12.7545 37.5172 12.6022 37.5172C12.389 37.5172 12.1775 37.6048 12.0182 37.7742L10.8338 39.033C10.5312 39.3546 10.0388 39.3546 9.73615 39.033L6.56494 35.663C6.41957 35.5085 6.33957 35.3015 6.33957 35.0799C6.33957 34.8583 6.41965 34.6511 6.5656 34.496L7.75008 33.2348C8.02284 32.9444 8.06973 32.4919 7.86302 32.1453C6.84356 30.4365 6.11552 28.5709 5.69904 26.6007C5.61442 26.2003 5.27975 25.9156 4.89357 25.9156H3.22062C2.79241 25.9156 2.44404 25.5454 2.44404 25.0904V20.3239C2.44404 19.8702 2.79241 19.5011 3.22062 19.5011H4.89348C5.27967 19.5011 5.61426 19.2165 5.69896 18.816C6.11519 16.847 6.84331 14.9804 7.86318 13.2683C8.06973 12.9216 8.02251 12.469 7.74942 12.1788L6.56494 10.92C6.41957 10.7655 6.33957 10.5585 6.33957 10.3369C6.33957 10.1153 6.41965 9.90817 6.56503 9.75377L9.73615 6.38378C10.0387 6.06217 10.5311 6.06208 10.8338 6.38378L12.0183 7.64259C12.2914 7.93271 12.7173 7.98298 13.0436 7.76348C14.655 6.6796 16.4113 5.90566 18.264 5.46351C18.6409 5.37359 18.9087 5.01803 18.9087 4.60755V2.82982C18.9087 2.37469 19.256 2.00456 19.6829 2.00456H24.1682C24.5964 2.00456 24.9448 2.37478 24.9448 2.82982V4.60755C24.9448 5.01803 25.2126 5.3735 25.5895 5.46351C27.4421 5.90575 29.1986 6.67951 30.8099 7.76348C31.1362 7.98289 31.5621 7.93262 31.8352 7.64259L33.0196 6.38378C33.3223 6.06226 33.8147 6.06208 34.1173 6.38378L37.2885 9.75377C37.4338 9.90826 37.5138 10.1153 37.5138 10.3369C37.5138 10.5585 37.4338 10.7656 37.2885 10.92L36.104 12.1788C35.8309 12.469 35.7837 12.9216 35.9902 13.2683C37.0077 14.9766 37.7351 16.843 38.1521 18.816C38.2368 19.2164 38.5713 19.5011 38.9576 19.5011H40.6329C41.0611 19.5011 41.4095 19.8702 41.4095 20.3239V25.0904H41.4093Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M15.699 28.0855C15.3765 28.428 15.3763 28.9834 15.6986 29.3262C17.362 31.0952 19.5738 32.0696 21.9265 32.0696C24.2792 32.0696 26.4909 31.0953 28.1536 29.3269C29.611 27.7807 30.4949 25.7858 30.692 23.6333L31.5664 24.5625C31.7276 24.7337 31.9389 24.8194 32.1501 24.8194C32.3614 24.8194 32.5727 24.7337 32.7339 24.5625C33.0563 24.2199 33.0563 23.6644 32.7339 23.3217L30.4098 20.8519C30.255 20.6874 30.045 20.595 29.826 20.595C29.6071 20.595 29.3971 20.6874 29.2423 20.8519L26.9182 23.3217C26.5958 23.6643 26.5958 24.2198 26.9182 24.5625C27.2405 24.905 27.7633 24.905 28.0856 24.5625L29.0385 23.5498C28.8623 25.2642 28.1502 26.851 26.9863 28.0861C25.6348 29.5234 23.8378 30.315 21.9264 30.315C20.0149 30.315 18.218 29.5234 16.8664 28.0861C16.5442 27.7433 16.0215 27.7431 15.699 28.0855V28.0855Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M13.1608 21.7814L12.2862 20.8519C11.9639 20.5095 11.4411 20.5094 11.1188 20.8519C10.7964 21.1945 10.7963 21.75 11.1188 22.0926L13.4429 24.5624C13.761 24.8998 14.2923 24.9001 14.6104 24.5624L16.9346 22.0926C17.2569 21.7501 17.2569 21.1946 16.9346 20.8519C16.6122 20.5094 16.0895 20.5094 15.7671 20.8519L14.8145 21.8642C14.9913 20.1511 15.7033 18.5644 16.8661 17.3285C19.6563 14.3634 24.1963 14.3634 26.9865 17.3285C27.3088 17.671 27.8316 17.671 28.154 17.3285C28.4764 16.986 28.4764 16.4305 28.154 16.0878C24.72 12.4387 19.1326 12.4387 15.6987 16.0878C14.242 17.6356 13.3584 19.6304 13.1608 21.7814V21.7814Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M25.9897 7.7714C25.5519 7.63744 25.0941 7.9058 24.9678 8.37129C24.8414 8.83686 25.0941 9.32305 25.5322 9.45728C27.6269 10.0992 29.5527 11.3096 31.1018 12.9582C33.5523 15.5623 34.9019 19.0249 34.9019 22.7084C34.9019 26.392 33.5523 29.8546 31.1018 32.4587C26.0427 37.835 17.8108 37.8349 12.7515 32.4586C10.3001 29.8545 8.9499 26.3918 8.9499 22.7084C8.9499 19.0251 10.3 15.5624 12.7521 12.9578C14.3431 11.2647 16.3256 10.0381 18.485 9.41043C18.9248 9.28261 19.1838 8.80019 19.0635 8.33286C18.9432 7.86553 18.489 7.59007 18.0494 7.71806C15.6133 8.42603 13.3775 9.80915 11.5843 11.7174C8.82078 14.6529 7.29883 18.5563 7.29883 22.7084C7.29883 26.8606 8.82078 30.764 11.5843 33.6994C14.4357 36.7295 18.1813 38.2447 21.9268 38.2447C25.6723 38.2447 29.418 36.7295 32.2694 33.6994C35.0318 30.7638 36.5531 26.8605 36.5531 22.7084C36.5531 18.5564 35.0318 14.653 32.2699 11.7179C30.524 9.86012 28.3524 8.49542 25.9897 7.7714V7.7714Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M21.9212 8.91747H21.9259C22.3819 8.91747 22.7491 8.52462 22.7491 8.04019C22.7491 7.55575 22.3772 7.1629 21.9212 7.1629C21.4653 7.1629 21.0957 7.55575 21.0957 8.04019C21.0957 8.52462 21.4653 8.91747 21.9212 8.91747Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                            </svg>\r\n                            </div>\r\n                            <div>\r\n                                <div class=\"g-fs-08 g-lh-09 g-black9-clr g-fw-500 a-cnt\">\r\n                                    ENERGY <br> MANAGEMENT\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </label>\r\n            </div>\r\n            <div class=\"challenge-sector-card\">\r\n                <label class=\"challenge-sector-checkbox\">\r\n                    <input type=\"checkbox\" name=\"challenge-sector\" class=\"a-checkbox\" value=\"1\">\r\n                    <div class=\"challenge-sector\">\r\n                        <div>\r\n                            <div class=\"g-pb-06\">\r\n                                <svg width=\"46\" height=\"47\" viewBox=\"0 0 46 47\" fill=\"none\"\r\n                                xmlns=\"http://www.w3.org/2000/svg\">\r\n                                <path d=\"M31.5312 0.751221H33.0428V2.26801H31.5312V0.751221Z\" fill=\"white\" />\r\n                                <path\r\n                                    d=\"M36.0664 15.9191H12.6057L23.7526 4.73352C23.8947 4.59094 23.974 4.39831 23.974 4.19734C23.974 3.99636 23.8947 3.80297 23.7526 3.66115L21.6153 1.51641C20.7582 0.656394 19.2648 0.656394 18.4085 1.51641L16.6823 3.24859L17.751 4.32095L19.4779 2.58878C19.7629 2.30211 20.2609 2.30211 20.5466 2.58878L22.1503 4.19734L3.97931 22.4306L2.37632 20.8213C2.23348 20.6788 2.15488 20.4884 2.15488 20.2852C2.15488 20.0819 2.23348 19.8923 2.37632 19.749L16.2395 5.83774L15.1708 4.76537L14.1331 5.80665L13.0645 4.73428C12.1794 3.8462 10.7412 3.84696 9.85771 4.73428L4.51364 10.0969C3.62939 10.9842 3.62939 12.4274 4.51364 13.3147L5.58231 14.3871L1.3069 18.6774C0.878379 19.1074 0.642578 19.6784 0.642578 20.2867C0.642578 20.8949 0.878379 21.466 1.3069 21.8952L3.44423 24.0407C3.58631 24.1818 3.77903 24.2614 3.97931 24.2614C4.17959 24.2614 4.37231 24.1818 4.51364 24.0392L8.53284 20.0061L11.7154 44.2769C11.8635 45.4039 12.8294 46.2548 13.9631 46.2548H30.9619C32.0955 46.2548 33.0614 45.4039 33.2103 44.2762L35.8215 24.36L34.3228 24.1621L31.7116 44.0775C31.6617 44.4544 31.3398 44.7381 30.9619 44.7381H13.9631C13.5852 44.7381 13.2632 44.4544 13.2141 44.0783L9.88038 18.6538L11.0942 17.4359H35.2048L34.7203 21.1292L36.219 21.3272L36.8161 16.7768C36.8448 16.5599 36.7791 16.3423 36.6355 16.1777C36.4911 16.0131 36.284 15.9191 36.0664 15.9191ZM5.58306 12.2416C5.28831 11.9458 5.28831 11.465 5.58306 11.1685L10.9271 5.80589C11.2211 5.51087 11.701 5.51012 11.9965 5.80589L13.0652 6.87826L6.65248 13.3132L5.58306 12.2416Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M20.1953 22.7447V39.4293C20.1953 40.6837 21.2126 41.7045 22.4626 41.7045C23.7127 41.7045 24.7299 40.6837 24.7299 39.4293V22.7447C24.7299 21.4903 23.7127 20.4695 22.4626 20.4695C21.2126 20.4695 20.1953 21.4903 20.1953 22.7447ZM23.2184 22.7447V39.4293C23.2184 39.8472 22.8791 40.1877 22.4626 40.1877C22.0462 40.1877 21.7069 39.8472 21.7069 39.4293V22.7447C21.7069 22.3268 22.0462 21.9863 22.4626 21.9863C22.8791 21.9863 23.2184 22.3268 23.2184 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M14.1484 22.7447V39.4293C14.1484 40.6837 15.1657 41.7045 16.4158 41.7045C17.6658 41.7045 18.6831 40.6837 18.6831 39.4293V22.7447C18.6831 21.4903 17.6658 20.4695 16.4158 20.4695C15.1657 20.4695 14.1484 21.4903 14.1484 22.7447ZM17.1715 22.7447V39.4293C17.1715 39.8472 16.8322 40.1877 16.4158 40.1877C15.9993 40.1877 15.66 39.8472 15.66 39.4293V22.7447C15.66 22.3268 15.9993 21.9863 16.4158 21.9863C16.8322 21.9863 17.1715 22.3268 17.1715 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M26.2402 22.7447V39.4293C26.2402 40.6837 27.2575 41.7045 28.5076 41.7045C29.7576 41.7045 30.7749 40.6837 30.7749 39.4293V22.7447C30.7749 21.4903 29.7576 20.4695 28.5076 20.4695C27.2575 20.4695 26.2402 21.4903 26.2402 22.7447ZM29.2633 22.7447V39.4293C29.2633 39.8472 28.924 40.1877 28.5076 40.1877C28.0911 40.1877 27.7518 39.8472 27.7518 39.4293V22.7447C27.7518 22.3268 28.0911 21.9863 28.5076 21.9863C28.924 21.9863 29.2633 22.3268 29.2633 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M26.4245 9.1163L23.4014 8.3579C23.1059 8.28434 22.7953 8.39506 22.6139 8.63851L20.3466 11.6721C20.2121 11.8518 20.1637 12.0824 20.2159 12.3016C20.2673 12.5207 20.4131 12.705 20.6134 12.8059L23.6365 14.3227C23.74 14.375 23.8564 14.4023 23.9736 14.4023H27.7524C28.0033 14.4023 28.2376 14.2772 28.3782 14.0694C28.5188 13.8616 28.5475 13.5961 28.4545 13.3625L26.943 9.57057C26.8523 9.34457 26.6596 9.17545 26.4245 9.1163ZM24.1519 12.8855L22.0985 11.8556L23.5216 9.95205L25.6824 10.4943L26.6361 12.8855H24.1519Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M35.9554 7.93473L35.2306 6.47937C35.0779 6.17298 34.7386 6.00765 34.406 6.07515L30.6272 6.83354C30.2735 6.90407 30.0195 7.21501 30.0195 7.57677V9.09356C30.0195 9.15575 30.0271 9.21718 30.0422 9.27785L30.798 12.3114C30.8826 12.6519 31.188 12.8855 31.5303 12.8855C31.5621 12.8855 31.593 12.884 31.6248 12.8795L37.671 12.1211C37.9385 12.0877 38.1675 11.914 38.2726 11.6645C38.3776 11.415 38.3428 11.1291 38.1811 10.9129L35.9554 7.93473ZM32.1017 11.2914L31.5311 9.00027V8.19865L34.1362 7.67612L34.6335 8.67492C34.6539 8.71588 34.6781 8.75456 34.7053 8.79096L36.1912 10.7795L32.1017 11.2914Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M38.1855 5.4586L39.1068 6.66141C40.7778 5.37366 42.922 4.87312 44.9875 5.28645L45.2845 3.79923C42.7874 3.29869 40.2012 3.90389 38.1855 5.4586Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path d=\"M41.3555 8.33514H42.867V9.85193H41.3555V8.33514Z\" fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M34.5527 4.54319H36.0643C36.0643 3.28881 37.0815 2.26801 38.3316 2.26801V0.751221C36.2479 0.751221 34.5527 2.4523 34.5527 4.54319Z\"\r\n                                    fill=\"white\" />\r\n                            </svg>\r\n                            </div>\r\n                            <div>\r\n                                <div class=\"g-fs-08 g-lh-09 g-black9-clr g-fw-500 a-cnt\">\r\n                                    WASTE<br> MANAGEMENT\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </label>\r\n            </div>\r\n            <div class=\"challenge-sector-card\">\r\n                <label class=\"challenge-sector-checkbox\">\r\n                    <input type=\"checkbox\" name=\"challenge-sector\" class=\"a-checkbox\" value=\"1\">\r\n                    <div class=\"challenge-sector\">\r\n                        <div>\r\n                            <div class=\"g-pb-06\">\r\n                                <svg width=\"46\" height=\"47\" viewBox=\"0 0 46 47\" fill=\"none\"\r\n                                xmlns=\"http://www.w3.org/2000/svg\">\r\n                                <path d=\"M31.5312 0.751221H33.0428V2.26801H31.5312V0.751221Z\" fill=\"white\" />\r\n                                <path\r\n                                    d=\"M36.0664 15.9191H12.6057L23.7526 4.73352C23.8947 4.59094 23.974 4.39831 23.974 4.19734C23.974 3.99636 23.8947 3.80297 23.7526 3.66115L21.6153 1.51641C20.7582 0.656394 19.2648 0.656394 18.4085 1.51641L16.6823 3.24859L17.751 4.32095L19.4779 2.58878C19.7629 2.30211 20.2609 2.30211 20.5466 2.58878L22.1503 4.19734L3.97931 22.4306L2.37632 20.8213C2.23348 20.6788 2.15488 20.4884 2.15488 20.2852C2.15488 20.0819 2.23348 19.8923 2.37632 19.749L16.2395 5.83774L15.1708 4.76537L14.1331 5.80665L13.0645 4.73428C12.1794 3.8462 10.7412 3.84696 9.85771 4.73428L4.51364 10.0969C3.62939 10.9842 3.62939 12.4274 4.51364 13.3147L5.58231 14.3871L1.3069 18.6774C0.878379 19.1074 0.642578 19.6784 0.642578 20.2867C0.642578 20.8949 0.878379 21.466 1.3069 21.8952L3.44423 24.0407C3.58631 24.1818 3.77903 24.2614 3.97931 24.2614C4.17959 24.2614 4.37231 24.1818 4.51364 24.0392L8.53284 20.0061L11.7154 44.2769C11.8635 45.4039 12.8294 46.2548 13.9631 46.2548H30.9619C32.0955 46.2548 33.0614 45.4039 33.2103 44.2762L35.8215 24.36L34.3228 24.1621L31.7116 44.0775C31.6617 44.4544 31.3398 44.7381 30.9619 44.7381H13.9631C13.5852 44.7381 13.2632 44.4544 13.2141 44.0783L9.88038 18.6538L11.0942 17.4359H35.2048L34.7203 21.1292L36.219 21.3272L36.8161 16.7768C36.8448 16.5599 36.7791 16.3423 36.6355 16.1777C36.4911 16.0131 36.284 15.9191 36.0664 15.9191ZM5.58306 12.2416C5.28831 11.9458 5.28831 11.465 5.58306 11.1685L10.9271 5.80589C11.2211 5.51087 11.701 5.51012 11.9965 5.80589L13.0652 6.87826L6.65248 13.3132L5.58306 12.2416Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M20.1953 22.7447V39.4293C20.1953 40.6837 21.2126 41.7045 22.4626 41.7045C23.7127 41.7045 24.7299 40.6837 24.7299 39.4293V22.7447C24.7299 21.4903 23.7127 20.4695 22.4626 20.4695C21.2126 20.4695 20.1953 21.4903 20.1953 22.7447ZM23.2184 22.7447V39.4293C23.2184 39.8472 22.8791 40.1877 22.4626 40.1877C22.0462 40.1877 21.7069 39.8472 21.7069 39.4293V22.7447C21.7069 22.3268 22.0462 21.9863 22.4626 21.9863C22.8791 21.9863 23.2184 22.3268 23.2184 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M14.1484 22.7447V39.4293C14.1484 40.6837 15.1657 41.7045 16.4158 41.7045C17.6658 41.7045 18.6831 40.6837 18.6831 39.4293V22.7447C18.6831 21.4903 17.6658 20.4695 16.4158 20.4695C15.1657 20.4695 14.1484 21.4903 14.1484 22.7447ZM17.1715 22.7447V39.4293C17.1715 39.8472 16.8322 40.1877 16.4158 40.1877C15.9993 40.1877 15.66 39.8472 15.66 39.4293V22.7447C15.66 22.3268 15.9993 21.9863 16.4158 21.9863C16.8322 21.9863 17.1715 22.3268 17.1715 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M26.2402 22.7447V39.4293C26.2402 40.6837 27.2575 41.7045 28.5076 41.7045C29.7576 41.7045 30.7749 40.6837 30.7749 39.4293V22.7447C30.7749 21.4903 29.7576 20.4695 28.5076 20.4695C27.2575 20.4695 26.2402 21.4903 26.2402 22.7447ZM29.2633 22.7447V39.4293C29.2633 39.8472 28.924 40.1877 28.5076 40.1877C28.0911 40.1877 27.7518 39.8472 27.7518 39.4293V22.7447C27.7518 22.3268 28.0911 21.9863 28.5076 21.9863C28.924 21.9863 29.2633 22.3268 29.2633 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M26.4245 9.1163L23.4014 8.3579C23.1059 8.28434 22.7953 8.39506 22.6139 8.63851L20.3466 11.6721C20.2121 11.8518 20.1637 12.0824 20.2159 12.3016C20.2673 12.5207 20.4131 12.705 20.6134 12.8059L23.6365 14.3227C23.74 14.375 23.8564 14.4023 23.9736 14.4023H27.7524C28.0033 14.4023 28.2376 14.2772 28.3782 14.0694C28.5188 13.8616 28.5475 13.5961 28.4545 13.3625L26.943 9.57057C26.8523 9.34457 26.6596 9.17545 26.4245 9.1163ZM24.1519 12.8855L22.0985 11.8556L23.5216 9.95205L25.6824 10.4943L26.6361 12.8855H24.1519Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M35.9554 7.93473L35.2306 6.47937C35.0779 6.17298 34.7386 6.00765 34.406 6.07515L30.6272 6.83354C30.2735 6.90407 30.0195 7.21501 30.0195 7.57677V9.09356C30.0195 9.15575 30.0271 9.21718 30.0422 9.27785L30.798 12.3114C30.8826 12.6519 31.188 12.8855 31.5303 12.8855C31.5621 12.8855 31.593 12.884 31.6248 12.8795L37.671 12.1211C37.9385 12.0877 38.1675 11.914 38.2726 11.6645C38.3776 11.415 38.3428 11.1291 38.1811 10.9129L35.9554 7.93473ZM32.1017 11.2914L31.5311 9.00027V8.19865L34.1362 7.67612L34.6335 8.67492C34.6539 8.71588 34.6781 8.75456 34.7053 8.79096L36.1912 10.7795L32.1017 11.2914Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M38.1855 5.4586L39.1068 6.66141C40.7778 5.37366 42.922 4.87312 44.9875 5.28645L45.2845 3.79923C42.7874 3.29869 40.2012 3.90389 38.1855 5.4586Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path d=\"M41.3555 8.33514H42.867V9.85193H41.3555V8.33514Z\" fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M34.5527 4.54319H36.0643C36.0643 3.28881 37.0815 2.26801 38.3316 2.26801V0.751221C36.2479 0.751221 34.5527 2.4523 34.5527 4.54319Z\"\r\n                                    fill=\"white\" />\r\n                            </svg>\r\n                            </div>\r\n                            <div>\r\n                                <div class=\"g-fs-08 g-lh-09 g-black9-clr g-fw-500 a-cnt\">\r\n                                    WASTE<br> MANAGEMENT\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </label>\r\n            </div>\r\n            <div class=\"challenge-sector-card\">\r\n                <label class=\"challenge-sector-checkbox\">\r\n                    <input type=\"checkbox\" name=\"challenge-sector\" class=\"a-checkbox\" value=\"1\">\r\n                    <div class=\"challenge-sector\">\r\n                        <div>\r\n                            <div class=\"g-pb-06\">\r\n                                <svg width=\"46\" height=\"47\" viewBox=\"0 0 46 47\" fill=\"none\"\r\n                                xmlns=\"http://www.w3.org/2000/svg\">\r\n                                <path d=\"M31.5312 0.751221H33.0428V2.26801H31.5312V0.751221Z\" fill=\"white\" />\r\n                                <path\r\n                                    d=\"M36.0664 15.9191H12.6057L23.7526 4.73352C23.8947 4.59094 23.974 4.39831 23.974 4.19734C23.974 3.99636 23.8947 3.80297 23.7526 3.66115L21.6153 1.51641C20.7582 0.656394 19.2648 0.656394 18.4085 1.51641L16.6823 3.24859L17.751 4.32095L19.4779 2.58878C19.7629 2.30211 20.2609 2.30211 20.5466 2.58878L22.1503 4.19734L3.97931 22.4306L2.37632 20.8213C2.23348 20.6788 2.15488 20.4884 2.15488 20.2852C2.15488 20.0819 2.23348 19.8923 2.37632 19.749L16.2395 5.83774L15.1708 4.76537L14.1331 5.80665L13.0645 4.73428C12.1794 3.8462 10.7412 3.84696 9.85771 4.73428L4.51364 10.0969C3.62939 10.9842 3.62939 12.4274 4.51364 13.3147L5.58231 14.3871L1.3069 18.6774C0.878379 19.1074 0.642578 19.6784 0.642578 20.2867C0.642578 20.8949 0.878379 21.466 1.3069 21.8952L3.44423 24.0407C3.58631 24.1818 3.77903 24.2614 3.97931 24.2614C4.17959 24.2614 4.37231 24.1818 4.51364 24.0392L8.53284 20.0061L11.7154 44.2769C11.8635 45.4039 12.8294 46.2548 13.9631 46.2548H30.9619C32.0955 46.2548 33.0614 45.4039 33.2103 44.2762L35.8215 24.36L34.3228 24.1621L31.7116 44.0775C31.6617 44.4544 31.3398 44.7381 30.9619 44.7381H13.9631C13.5852 44.7381 13.2632 44.4544 13.2141 44.0783L9.88038 18.6538L11.0942 17.4359H35.2048L34.7203 21.1292L36.219 21.3272L36.8161 16.7768C36.8448 16.5599 36.7791 16.3423 36.6355 16.1777C36.4911 16.0131 36.284 15.9191 36.0664 15.9191ZM5.58306 12.2416C5.28831 11.9458 5.28831 11.465 5.58306 11.1685L10.9271 5.80589C11.2211 5.51087 11.701 5.51012 11.9965 5.80589L13.0652 6.87826L6.65248 13.3132L5.58306 12.2416Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M20.1953 22.7447V39.4293C20.1953 40.6837 21.2126 41.7045 22.4626 41.7045C23.7127 41.7045 24.7299 40.6837 24.7299 39.4293V22.7447C24.7299 21.4903 23.7127 20.4695 22.4626 20.4695C21.2126 20.4695 20.1953 21.4903 20.1953 22.7447ZM23.2184 22.7447V39.4293C23.2184 39.8472 22.8791 40.1877 22.4626 40.1877C22.0462 40.1877 21.7069 39.8472 21.7069 39.4293V22.7447C21.7069 22.3268 22.0462 21.9863 22.4626 21.9863C22.8791 21.9863 23.2184 22.3268 23.2184 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M14.1484 22.7447V39.4293C14.1484 40.6837 15.1657 41.7045 16.4158 41.7045C17.6658 41.7045 18.6831 40.6837 18.6831 39.4293V22.7447C18.6831 21.4903 17.6658 20.4695 16.4158 20.4695C15.1657 20.4695 14.1484 21.4903 14.1484 22.7447ZM17.1715 22.7447V39.4293C17.1715 39.8472 16.8322 40.1877 16.4158 40.1877C15.9993 40.1877 15.66 39.8472 15.66 39.4293V22.7447C15.66 22.3268 15.9993 21.9863 16.4158 21.9863C16.8322 21.9863 17.1715 22.3268 17.1715 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M26.2402 22.7447V39.4293C26.2402 40.6837 27.2575 41.7045 28.5076 41.7045C29.7576 41.7045 30.7749 40.6837 30.7749 39.4293V22.7447C30.7749 21.4903 29.7576 20.4695 28.5076 20.4695C27.2575 20.4695 26.2402 21.4903 26.2402 22.7447ZM29.2633 22.7447V39.4293C29.2633 39.8472 28.924 40.1877 28.5076 40.1877C28.0911 40.1877 27.7518 39.8472 27.7518 39.4293V22.7447C27.7518 22.3268 28.0911 21.9863 28.5076 21.9863C28.924 21.9863 29.2633 22.3268 29.2633 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M26.4245 9.1163L23.4014 8.3579C23.1059 8.28434 22.7953 8.39506 22.6139 8.63851L20.3466 11.6721C20.2121 11.8518 20.1637 12.0824 20.2159 12.3016C20.2673 12.5207 20.4131 12.705 20.6134 12.8059L23.6365 14.3227C23.74 14.375 23.8564 14.4023 23.9736 14.4023H27.7524C28.0033 14.4023 28.2376 14.2772 28.3782 14.0694C28.5188 13.8616 28.5475 13.5961 28.4545 13.3625L26.943 9.57057C26.8523 9.34457 26.6596 9.17545 26.4245 9.1163ZM24.1519 12.8855L22.0985 11.8556L23.5216 9.95205L25.6824 10.4943L26.6361 12.8855H24.1519Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M35.9554 7.93473L35.2306 6.47937C35.0779 6.17298 34.7386 6.00765 34.406 6.07515L30.6272 6.83354C30.2735 6.90407 30.0195 7.21501 30.0195 7.57677V9.09356C30.0195 9.15575 30.0271 9.21718 30.0422 9.27785L30.798 12.3114C30.8826 12.6519 31.188 12.8855 31.5303 12.8855C31.5621 12.8855 31.593 12.884 31.6248 12.8795L37.671 12.1211C37.9385 12.0877 38.1675 11.914 38.2726 11.6645C38.3776 11.415 38.3428 11.1291 38.1811 10.9129L35.9554 7.93473ZM32.1017 11.2914L31.5311 9.00027V8.19865L34.1362 7.67612L34.6335 8.67492C34.6539 8.71588 34.6781 8.75456 34.7053 8.79096L36.1912 10.7795L32.1017 11.2914Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M38.1855 5.4586L39.1068 6.66141C40.7778 5.37366 42.922 4.87312 44.9875 5.28645L45.2845 3.79923C42.7874 3.29869 40.2012 3.90389 38.1855 5.4586Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path d=\"M41.3555 8.33514H42.867V9.85193H41.3555V8.33514Z\" fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M34.5527 4.54319H36.0643C36.0643 3.28881 37.0815 2.26801 38.3316 2.26801V0.751221C36.2479 0.751221 34.5527 2.4523 34.5527 4.54319Z\"\r\n                                    fill=\"white\" />\r\n                            </svg>\r\n                            </div>\r\n                            <div>\r\n                                <div class=\"g-fs-08 g-lh-09 g-black9-clr g-fw-500 a-cnt\">\r\n                                    WASTE<br> MANAGEMENT\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </label>\r\n            </div>\r\n            <div class=\"challenge-sector-card\">\r\n                <label class=\"challenge-sector-checkbox\">\r\n                    <input type=\"checkbox\" name=\"challenge-sector\" class=\"a-checkbox\" value=\"1\">\r\n                    <div class=\"challenge-sector\">\r\n                        <div>\r\n                            <div class=\"g-pb-06\">\r\n                                <svg width=\"46\" height=\"47\" viewBox=\"0 0 46 47\" fill=\"none\"\r\n                                xmlns=\"http://www.w3.org/2000/svg\">\r\n                                <path d=\"M31.5312 0.751221H33.0428V2.26801H31.5312V0.751221Z\" fill=\"white\" />\r\n                                <path\r\n                                    d=\"M36.0664 15.9191H12.6057L23.7526 4.73352C23.8947 4.59094 23.974 4.39831 23.974 4.19734C23.974 3.99636 23.8947 3.80297 23.7526 3.66115L21.6153 1.51641C20.7582 0.656394 19.2648 0.656394 18.4085 1.51641L16.6823 3.24859L17.751 4.32095L19.4779 2.58878C19.7629 2.30211 20.2609 2.30211 20.5466 2.58878L22.1503 4.19734L3.97931 22.4306L2.37632 20.8213C2.23348 20.6788 2.15488 20.4884 2.15488 20.2852C2.15488 20.0819 2.23348 19.8923 2.37632 19.749L16.2395 5.83774L15.1708 4.76537L14.1331 5.80665L13.0645 4.73428C12.1794 3.8462 10.7412 3.84696 9.85771 4.73428L4.51364 10.0969C3.62939 10.9842 3.62939 12.4274 4.51364 13.3147L5.58231 14.3871L1.3069 18.6774C0.878379 19.1074 0.642578 19.6784 0.642578 20.2867C0.642578 20.8949 0.878379 21.466 1.3069 21.8952L3.44423 24.0407C3.58631 24.1818 3.77903 24.2614 3.97931 24.2614C4.17959 24.2614 4.37231 24.1818 4.51364 24.0392L8.53284 20.0061L11.7154 44.2769C11.8635 45.4039 12.8294 46.2548 13.9631 46.2548H30.9619C32.0955 46.2548 33.0614 45.4039 33.2103 44.2762L35.8215 24.36L34.3228 24.1621L31.7116 44.0775C31.6617 44.4544 31.3398 44.7381 30.9619 44.7381H13.9631C13.5852 44.7381 13.2632 44.4544 13.2141 44.0783L9.88038 18.6538L11.0942 17.4359H35.2048L34.7203 21.1292L36.219 21.3272L36.8161 16.7768C36.8448 16.5599 36.7791 16.3423 36.6355 16.1777C36.4911 16.0131 36.284 15.9191 36.0664 15.9191ZM5.58306 12.2416C5.28831 11.9458 5.28831 11.465 5.58306 11.1685L10.9271 5.80589C11.2211 5.51087 11.701 5.51012 11.9965 5.80589L13.0652 6.87826L6.65248 13.3132L5.58306 12.2416Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M20.1953 22.7447V39.4293C20.1953 40.6837 21.2126 41.7045 22.4626 41.7045C23.7127 41.7045 24.7299 40.6837 24.7299 39.4293V22.7447C24.7299 21.4903 23.7127 20.4695 22.4626 20.4695C21.2126 20.4695 20.1953 21.4903 20.1953 22.7447ZM23.2184 22.7447V39.4293C23.2184 39.8472 22.8791 40.1877 22.4626 40.1877C22.0462 40.1877 21.7069 39.8472 21.7069 39.4293V22.7447C21.7069 22.3268 22.0462 21.9863 22.4626 21.9863C22.8791 21.9863 23.2184 22.3268 23.2184 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M14.1484 22.7447V39.4293C14.1484 40.6837 15.1657 41.7045 16.4158 41.7045C17.6658 41.7045 18.6831 40.6837 18.6831 39.4293V22.7447C18.6831 21.4903 17.6658 20.4695 16.4158 20.4695C15.1657 20.4695 14.1484 21.4903 14.1484 22.7447ZM17.1715 22.7447V39.4293C17.1715 39.8472 16.8322 40.1877 16.4158 40.1877C15.9993 40.1877 15.66 39.8472 15.66 39.4293V22.7447C15.66 22.3268 15.9993 21.9863 16.4158 21.9863C16.8322 21.9863 17.1715 22.3268 17.1715 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M26.2402 22.7447V39.4293C26.2402 40.6837 27.2575 41.7045 28.5076 41.7045C29.7576 41.7045 30.7749 40.6837 30.7749 39.4293V22.7447C30.7749 21.4903 29.7576 20.4695 28.5076 20.4695C27.2575 20.4695 26.2402 21.4903 26.2402 22.7447ZM29.2633 22.7447V39.4293C29.2633 39.8472 28.924 40.1877 28.5076 40.1877C28.0911 40.1877 27.7518 39.8472 27.7518 39.4293V22.7447C27.7518 22.3268 28.0911 21.9863 28.5076 21.9863C28.924 21.9863 29.2633 22.3268 29.2633 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M26.4245 9.1163L23.4014 8.3579C23.1059 8.28434 22.7953 8.39506 22.6139 8.63851L20.3466 11.6721C20.2121 11.8518 20.1637 12.0824 20.2159 12.3016C20.2673 12.5207 20.4131 12.705 20.6134 12.8059L23.6365 14.3227C23.74 14.375 23.8564 14.4023 23.9736 14.4023H27.7524C28.0033 14.4023 28.2376 14.2772 28.3782 14.0694C28.5188 13.8616 28.5475 13.5961 28.4545 13.3625L26.943 9.57057C26.8523 9.34457 26.6596 9.17545 26.4245 9.1163ZM24.1519 12.8855L22.0985 11.8556L23.5216 9.95205L25.6824 10.4943L26.6361 12.8855H24.1519Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M35.9554 7.93473L35.2306 6.47937C35.0779 6.17298 34.7386 6.00765 34.406 6.07515L30.6272 6.83354C30.2735 6.90407 30.0195 7.21501 30.0195 7.57677V9.09356C30.0195 9.15575 30.0271 9.21718 30.0422 9.27785L30.798 12.3114C30.8826 12.6519 31.188 12.8855 31.5303 12.8855C31.5621 12.8855 31.593 12.884 31.6248 12.8795L37.671 12.1211C37.9385 12.0877 38.1675 11.914 38.2726 11.6645C38.3776 11.415 38.3428 11.1291 38.1811 10.9129L35.9554 7.93473ZM32.1017 11.2914L31.5311 9.00027V8.19865L34.1362 7.67612L34.6335 8.67492C34.6539 8.71588 34.6781 8.75456 34.7053 8.79096L36.1912 10.7795L32.1017 11.2914Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M38.1855 5.4586L39.1068 6.66141C40.7778 5.37366 42.922 4.87312 44.9875 5.28645L45.2845 3.79923C42.7874 3.29869 40.2012 3.90389 38.1855 5.4586Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path d=\"M41.3555 8.33514H42.867V9.85193H41.3555V8.33514Z\" fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M34.5527 4.54319H36.0643C36.0643 3.28881 37.0815 2.26801 38.3316 2.26801V0.751221C36.2479 0.751221 34.5527 2.4523 34.5527 4.54319Z\"\r\n                                    fill=\"white\" />\r\n                            </svg>\r\n                            </div>\r\n                            <div>\r\n                                <div class=\"g-fs-08 g-lh-09 g-black9-clr g-fw-500 a-cnt\">\r\n                                    WASTE<br> MANAGEMENT\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </label>\r\n            </div>\r\n                        <div class=\"challenge-sector-card\">\r\n                <label class=\"challenge-sector-checkbox\">\r\n                    <input type=\"checkbox\" name=\"challenge-sector\" class=\"a-checkbox\" value=\"1\">\r\n                    <div class=\"challenge-sector\">\r\n                        <div>\r\n                            <div class=\"g-pb-06\">\r\n                                <svg width=\"46\" height=\"47\" viewBox=\"0 0 46 47\" fill=\"none\"\r\n                                xmlns=\"http://www.w3.org/2000/svg\">\r\n                                <path d=\"M31.5312 0.751221H33.0428V2.26801H31.5312V0.751221Z\" fill=\"white\" />\r\n                                <path\r\n                                    d=\"M36.0664 15.9191H12.6057L23.7526 4.73352C23.8947 4.59094 23.974 4.39831 23.974 4.19734C23.974 3.99636 23.8947 3.80297 23.7526 3.66115L21.6153 1.51641C20.7582 0.656394 19.2648 0.656394 18.4085 1.51641L16.6823 3.24859L17.751 4.32095L19.4779 2.58878C19.7629 2.30211 20.2609 2.30211 20.5466 2.58878L22.1503 4.19734L3.97931 22.4306L2.37632 20.8213C2.23348 20.6788 2.15488 20.4884 2.15488 20.2852C2.15488 20.0819 2.23348 19.8923 2.37632 19.749L16.2395 5.83774L15.1708 4.76537L14.1331 5.80665L13.0645 4.73428C12.1794 3.8462 10.7412 3.84696 9.85771 4.73428L4.51364 10.0969C3.62939 10.9842 3.62939 12.4274 4.51364 13.3147L5.58231 14.3871L1.3069 18.6774C0.878379 19.1074 0.642578 19.6784 0.642578 20.2867C0.642578 20.8949 0.878379 21.466 1.3069 21.8952L3.44423 24.0407C3.58631 24.1818 3.77903 24.2614 3.97931 24.2614C4.17959 24.2614 4.37231 24.1818 4.51364 24.0392L8.53284 20.0061L11.7154 44.2769C11.8635 45.4039 12.8294 46.2548 13.9631 46.2548H30.9619C32.0955 46.2548 33.0614 45.4039 33.2103 44.2762L35.8215 24.36L34.3228 24.1621L31.7116 44.0775C31.6617 44.4544 31.3398 44.7381 30.9619 44.7381H13.9631C13.5852 44.7381 13.2632 44.4544 13.2141 44.0783L9.88038 18.6538L11.0942 17.4359H35.2048L34.7203 21.1292L36.219 21.3272L36.8161 16.7768C36.8448 16.5599 36.7791 16.3423 36.6355 16.1777C36.4911 16.0131 36.284 15.9191 36.0664 15.9191ZM5.58306 12.2416C5.28831 11.9458 5.28831 11.465 5.58306 11.1685L10.9271 5.80589C11.2211 5.51087 11.701 5.51012 11.9965 5.80589L13.0652 6.87826L6.65248 13.3132L5.58306 12.2416Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M20.1953 22.7447V39.4293C20.1953 40.6837 21.2126 41.7045 22.4626 41.7045C23.7127 41.7045 24.7299 40.6837 24.7299 39.4293V22.7447C24.7299 21.4903 23.7127 20.4695 22.4626 20.4695C21.2126 20.4695 20.1953 21.4903 20.1953 22.7447ZM23.2184 22.7447V39.4293C23.2184 39.8472 22.8791 40.1877 22.4626 40.1877C22.0462 40.1877 21.7069 39.8472 21.7069 39.4293V22.7447C21.7069 22.3268 22.0462 21.9863 22.4626 21.9863C22.8791 21.9863 23.2184 22.3268 23.2184 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M14.1484 22.7447V39.4293C14.1484 40.6837 15.1657 41.7045 16.4158 41.7045C17.6658 41.7045 18.6831 40.6837 18.6831 39.4293V22.7447C18.6831 21.4903 17.6658 20.4695 16.4158 20.4695C15.1657 20.4695 14.1484 21.4903 14.1484 22.7447ZM17.1715 22.7447V39.4293C17.1715 39.8472 16.8322 40.1877 16.4158 40.1877C15.9993 40.1877 15.66 39.8472 15.66 39.4293V22.7447C15.66 22.3268 15.9993 21.9863 16.4158 21.9863C16.8322 21.9863 17.1715 22.3268 17.1715 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M26.2402 22.7447V39.4293C26.2402 40.6837 27.2575 41.7045 28.5076 41.7045C29.7576 41.7045 30.7749 40.6837 30.7749 39.4293V22.7447C30.7749 21.4903 29.7576 20.4695 28.5076 20.4695C27.2575 20.4695 26.2402 21.4903 26.2402 22.7447ZM29.2633 22.7447V39.4293C29.2633 39.8472 28.924 40.1877 28.5076 40.1877C28.0911 40.1877 27.7518 39.8472 27.7518 39.4293V22.7447C27.7518 22.3268 28.0911 21.9863 28.5076 21.9863C28.924 21.9863 29.2633 22.3268 29.2633 22.7447Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M26.4245 9.1163L23.4014 8.3579C23.1059 8.28434 22.7953 8.39506 22.6139 8.63851L20.3466 11.6721C20.2121 11.8518 20.1637 12.0824 20.2159 12.3016C20.2673 12.5207 20.4131 12.705 20.6134 12.8059L23.6365 14.3227C23.74 14.375 23.8564 14.4023 23.9736 14.4023H27.7524C28.0033 14.4023 28.2376 14.2772 28.3782 14.0694C28.5188 13.8616 28.5475 13.5961 28.4545 13.3625L26.943 9.57057C26.8523 9.34457 26.6596 9.17545 26.4245 9.1163ZM24.1519 12.8855L22.0985 11.8556L23.5216 9.95205L25.6824 10.4943L26.6361 12.8855H24.1519Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M35.9554 7.93473L35.2306 6.47937C35.0779 6.17298 34.7386 6.00765 34.406 6.07515L30.6272 6.83354C30.2735 6.90407 30.0195 7.21501 30.0195 7.57677V9.09356C30.0195 9.15575 30.0271 9.21718 30.0422 9.27785L30.798 12.3114C30.8826 12.6519 31.188 12.8855 31.5303 12.8855C31.5621 12.8855 31.593 12.884 31.6248 12.8795L37.671 12.1211C37.9385 12.0877 38.1675 11.914 38.2726 11.6645C38.3776 11.415 38.3428 11.1291 38.1811 10.9129L35.9554 7.93473ZM32.1017 11.2914L31.5311 9.00027V8.19865L34.1362 7.67612L34.6335 8.67492C34.6539 8.71588 34.6781 8.75456 34.7053 8.79096L36.1912 10.7795L32.1017 11.2914Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M38.1855 5.4586L39.1068 6.66141C40.7778 5.37366 42.922 4.87312 44.9875 5.28645L45.2845 3.79923C42.7874 3.29869 40.2012 3.90389 38.1855 5.4586Z\"\r\n                                    fill=\"#3B6FD4\" />\r\n                                <path d=\"M41.3555 8.33514H42.867V9.85193H41.3555V8.33514Z\" fill=\"#3B6FD4\" />\r\n                                <path\r\n                                    d=\"M34.5527 4.54319H36.0643C36.0643 3.28881 37.0815 2.26801 38.3316 2.26801V0.751221C36.2479 0.751221 34.5527 2.4523 34.5527 4.54319Z\"\r\n                                    fill=\"white\" />\r\n                            </svg>\r\n                            </div>\r\n                            <div>\r\n                                <div class=\"g-fs-08 g-lh-09 g-black9-clr g-fw-500 a-cnt\">\r\n                                    WASTE<br> MANAGEMENT\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </label>\r\n            </div>\r\n        </div>\r\n        <div class=\"text-center \">\r\n            <button class=\"btn g-p-bg g-w-clr g-w-30per g-fs-08 g-pt-04 g-pb-04 g-fw-500\">\r\n                Go to My News Feed\r\n            </button>\r\n        </div>\r\n    </div>\r\n</div>");

/***/ }),

/***/ "./node_modules/tslib/tslib.es6.js":
/*!*****************************************!*\
  !*** ./node_modules/tslib/tslib.es6.js ***!
  \*****************************************/
/*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __createBinding, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault, __classPrivateFieldGet, __classPrivateFieldSet */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__extends", function() { return __extends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__rest", function() { return __rest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__decorate", function() { return __decorate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__param", function() { return __param; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__metadata", function() { return __metadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__awaiter", function() { return __awaiter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__generator", function() { return __generator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__createBinding", function() { return __createBinding; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__exportStar", function() { return __exportStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__values", function() { return __values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__read", function() { return __read; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spread", function() { return __spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArrays", function() { return __spreadArrays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__await", function() { return __await; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function() { return __asyncGenerator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function() { return __asyncDelegator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncValues", function() { return __asyncValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function() { return __makeTemplateObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importStar", function() { return __importStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importDefault", function() { return __importDefault; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldGet", function() { return __classPrivateFieldGet; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldSet", function() { return __classPrivateFieldSet; });
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

function __createBinding(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}

function __exportStar(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) exports[p] = m[p];
}

function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result.default = mod;
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}

function __classPrivateFieldGet(receiver, privateMap) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return privateMap.get(receiver);
}

function __classPrivateFieldSet(receiver, privateMap, value) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to set private field on non-instance");
    }
    privateMap.set(receiver, value);
    return value;
}


/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _auth_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth.guard */ "./src/app/auth.guard.ts");
/* harmony import */ var _challenge_challenges_multi_select_challenges_multi_select_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./challenge/challenges-multi-select/challenges-multi-select.component */ "./src/app/challenge/challenges-multi-select/challenges-multi-select.component.ts");
/* harmony import */ var _pages_home_home_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/home/home.component */ "./src/app/pages/home/home.component.ts");
/* harmony import */ var _pages_help_help_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/help/help.component */ "./src/app/pages/help/help.component.ts");
/* harmony import */ var _users_login_login_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./users/login/login.component */ "./src/app/users/login/login.component.ts");
/* harmony import */ var _users_forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./users/forgot-password/forgot-password.component */ "./src/app/users/forgot-password/forgot-password.component.ts");
/* harmony import */ var _users_select_challenge_sector_select_challenge_sector_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./users/select-challenge-sector/select-challenge-sector.component */ "./src/app/users/select-challenge-sector/select-challenge-sector.component.ts");










const routes = [
    {
        path: "",
        component: _pages_home_home_component__WEBPACK_IMPORTED_MODULE_5__["HomeComponent"],
    },
    {
        path: "home",
        component: _pages_home_home_component__WEBPACK_IMPORTED_MODULE_5__["HomeComponent"],
    },
    {
        path: "help",
        component: _pages_help_help_component__WEBPACK_IMPORTED_MODULE_6__["HelpComponent"],
    },
    {
        path: "login",
        component: _users_login_login_component__WEBPACK_IMPORTED_MODULE_7__["LoginComponent"],
    },
    {
        path: "register",
        loadChildren: "./register/register.module#RegisterModule",
    },
    {
        path: "challenges-multiselect",
        component: _challenge_challenges_multi_select_challenges_multi_select_component__WEBPACK_IMPORTED_MODULE_4__["ChallengesMultiSelectComponent"],
        canActivate: [_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
    },
    {
        path: "login/forgot-password",
        component: _users_forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_8__["ForgotPasswordComponent"],
    },
    {
        path: "select-challenge-sector",
        component: _users_select_challenge_sector_select_challenge_sector_component__WEBPACK_IMPORTED_MODULE_9__["SelectChallengeSectorComponent"],
    },
    {
        path: "discover",
        loadChildren: () => __webpack_require__.e(/*! import() | discover-discover-module */ "default~challenge-challenge-module~cities-cities-module~discover-discover-module").then(__webpack_require__.bind(null, /*! ./discover/discover.module */ "./src/app/discover/discover.module.ts")).then((m) => m.DiscoverModule),
        canActivate: [_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
    },
    {
        path: "challenge",
        loadChildren: () => Promise.all(/*! import() | challenge-challenge-module */[__webpack_require__.e("default~challenge-challenge-module~provider-provider-module~seeker-seeker-module~startup-india-start~e8be73ad"), __webpack_require__.e("default~challenge-challenge-module~cities-cities-module~discover-discover-module"), __webpack_require__.e("common"), __webpack_require__.e("challenge-challenge-module")]).then(__webpack_require__.bind(null, /*! ./challenge/challenge.module */ "./src/app/challenge/challenge.module.ts")).then((m) => m.ChallengeModule),
        canActivate: [_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
    },
    {
        path: "solution",
        loadChildren: () => __webpack_require__.e(/*! import() | solution-solution-module */ "default~provider-provider-module~solution-solution-module").then(__webpack_require__.bind(null, /*! ./solution/solution.module */ "./src/app/solution/solution.module.ts")).then((m) => m.SolutionModule),
        canActivate: [_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
    },
    {
        path: "provider",
        loadChildren: () => Promise.all(/*! import() | provider-provider-module */[__webpack_require__.e("default~challenge-challenge-module~provider-provider-module~seeker-seeker-module~startup-india-start~e8be73ad"), __webpack_require__.e("default~provider-provider-module~solution-solution-module"), __webpack_require__.e("common"), __webpack_require__.e("provider-provider-module")]).then(__webpack_require__.bind(null, /*! ./provider/provider.module */ "./src/app/provider/provider.module.ts")).then((m) => m.ProviderModule),
        canActivate: [_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
    },
    {
        path: "cities",
        loadChildren: () => Promise.all(/*! import() | cities-cities-module */[__webpack_require__.e("default~challenge-challenge-module~cities-cities-module~discover-discover-module"), __webpack_require__.e("cities-cities-module")]).then(__webpack_require__.bind(null, /*! ./cities/cities.module */ "./src/app/cities/cities.module.ts")).then((m) => m.CitiesModule),
        canActivate: [_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
    },
    {
        path: "seeker",
        loadChildren: () => Promise.all(/*! import() | seeker-seeker-module */[__webpack_require__.e("default~challenge-challenge-module~provider-provider-module~seeker-seeker-module~startup-india-start~e8be73ad"), __webpack_require__.e("common"), __webpack_require__.e("seeker-seeker-module")]).then(__webpack_require__.bind(null, /*! ./seeker/seeker.module */ "./src/app/seeker/seeker.module.ts")).then((m) => m.SeekerModule),
        canActivate: [_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
    },
    {
        path: "notifications",
        loadChildren: () => __webpack_require__.e(/*! import() | notifications-notifications-module */ "notifications-notifications-module").then(__webpack_require__.bind(null, /*! ./notifications/notifications.module */ "./src/app/notifications/notifications.module.ts")).then((m) => m.NotificationsModule),
        canActivate: [_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
    }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, {
                scrollPositionRestoration: "enabled",
            }),
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".is-active{\r\n    color: #3B6FD4 !important;\r\n    border-color: var(--primary-clr) !important;\r\n\r\n}\r\n@media only screen and (max-width: 991px){\r\n    .a-ftr-sct-3 .footer-links{\r\n        text-align: center !important;\r\n        padding-top:10px !important;\r\n    }\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSx5QkFBeUI7SUFDekIsMkNBQTJDOztBQUUvQztBQUNBO0lBQ0k7UUFDSSw2QkFBNkI7UUFDN0IsMkJBQTJCO0lBQy9CO0FBQ0oiLCJmaWxlIjoic3JjL2FwcC9hcHAuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5pcy1hY3RpdmV7XHJcbiAgICBjb2xvcjogIzNCNkZENCAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1wcmltYXJ5LWNscikgIWltcG9ydGFudDtcclxuXHJcbn1cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA5OTFweCl7XHJcbiAgICAuYS1mdHItc2N0LTMgLmZvb3Rlci1saW5rc3tcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXIgIWltcG9ydGFudDtcclxuICAgICAgICBwYWRkaW5nLXRvcDoxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn0iXX0= */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let AppComponent = class AppComponent {
    constructor() {
        this.title = "forge";
    }
    ngOnInit() { }
    navigate() {
        window.location.href = "http://ie.forgeforward.in";
    }
};
AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-root",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")).default]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: runAtAppInit1, AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "runAtAppInit1", function() { return runAtAppInit1; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_fire__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire */ "./node_modules/@angular/fire/es2015/index.js");
/* harmony import */ var _angular_fire_database__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/fire/database */ "./node_modules/@angular/fire/database/es2015/index.js");
/* harmony import */ var _route_cache__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./route-cache */ "./src/app/route-cache.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _users_login_login_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./users/login/login.component */ "./src/app/users/login/login.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm2015/animations.js");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm2015/ngx-toastr.js");
/* harmony import */ var _challenge_challenges_multi_select_challenges_multi_select_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./challenge/challenges-multi-select/challenges-multi-select.component */ "./src/app/challenge/challenges-multi-select/challenges-multi-select.component.ts");
/* harmony import */ var ngx_image_cropper__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ngx-image-cropper */ "./node_modules/ngx-image-cropper/fesm2015/ngx-image-cropper.js");
/* harmony import */ var ngx_skeleton_loader__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ngx-skeleton-loader */ "./node_modules/ngx-skeleton-loader/fesm2015/ngx-skeleton-loader.js");
/* harmony import */ var _pages_home_home_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./pages/home/home.component */ "./src/app/pages/home/home.component.ts");
/* harmony import */ var _pages_help_help_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./pages/help/help.component */ "./src/app/pages/help/help.component.ts");
/* harmony import */ var _pages_city_stats_city_stats_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./pages/city-stats/city-stats.component */ "./src/app/pages/city-stats/city-stats.component.ts");
/* harmony import */ var angular_responsive_carousel__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! angular-responsive-carousel */ "./node_modules/angular-responsive-carousel/fesm2015/angular-responsive-carousel.js");
/* harmony import */ var _users_forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./users/forgot-password/forgot-password.component */ "./src/app/users/forgot-password/forgot-password.component.ts");
/* harmony import */ var _users_select_challenge_sector_select_challenge_sector_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./users/select-challenge-sector/select-challenge-sector.component */ "./src/app/users/select-challenge-sector/select-challenge-sector.component.ts");
/* harmony import */ var ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ng-multiselect-dropdown */ "./node_modules/ng-multiselect-dropdown/fesm2015/ng-multiselect-dropdown.js");
/* harmony import */ var _ckeditor_ckeditor5_angular__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ckeditor/ckeditor5-angular */ "./node_modules/@ckeditor/ckeditor5-angular/fesm2015/ckeditor-ckeditor5-angular.js");
/* harmony import */ var ngx_page_scroll__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ngx-page-scroll */ "./node_modules/ngx-page-scroll/fesm2015/ngx-page-scroll.js");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @ngxs/store */ "./node_modules/@ngxs/store/fesm2015/ngxs-store.js");
/* harmony import */ var _state_loggedinuser_state__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./state/loggedinuser.state */ "./src/app/state/loggedinuser.state.ts");
/* harmony import */ var _services_appinit_service__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./services/appinit.service */ "./src/app/services/appinit.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _pages_partial_pages_partial_module__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./pages-partial/pages-partial.module */ "./src/app/pages-partial/pages-partial.module.ts");
/* harmony import */ var _token_interceptor__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./token.interceptor */ "./src/app/token.interceptor.ts");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @angular/fire/firestore */ "./node_modules/@angular/fire/firestore/es2015/index.js");
/* harmony import */ var ngx_moment__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ngx-moment */ "./node_modules/ngx-moment/fesm2015/ngx-moment.js");































// Interceptors



//app startup functions
function runAtAppInit1(initService) {
    return () => initService.runAtAppStartUp();
}
let AppModule = class AppModule {
};
AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"], _users_login_login_component__WEBPACK_IMPORTED_MODULE_9__["LoginComponent"], _challenge_challenges_multi_select_challenges_multi_select_component__WEBPACK_IMPORTED_MODULE_14__["ChallengesMultiSelectComponent"], _pages_home_home_component__WEBPACK_IMPORTED_MODULE_17__["HomeComponent"], _pages_help_help_component__WEBPACK_IMPORTED_MODULE_18__["HelpComponent"], _users_forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_21__["ForgotPasswordComponent"], _users_select_challenge_sector_select_challenge_sector_component__WEBPACK_IMPORTED_MODULE_22__["SelectChallengeSectorComponent"], _pages_city_stats_city_stats_component__WEBPACK_IMPORTED_MODULE_19__["CityStatsComponent"]],
        imports: [
            _ngxs_store__WEBPACK_IMPORTED_MODULE_26__["NgxsModule"].forRoot([_state_loggedinuser_state__WEBPACK_IMPORTED_MODULE_27__["LoggedInUserState"]]),
            ngx_moment__WEBPACK_IMPORTED_MODULE_33__["MomentModule"].forRoot(),
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_12__["BrowserAnimationsModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ReactiveFormsModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_11__["HttpClientModule"],
            ngx_toastr__WEBPACK_IMPORTED_MODULE_13__["ToastrModule"].forRoot({
                timeOut: 3000,
                preventDuplicates: true,
            }),
            _pages_partial_pages_partial_module__WEBPACK_IMPORTED_MODULE_30__["PagesPartialModule"],
            ngx_image_cropper__WEBPACK_IMPORTED_MODULE_15__["ImageCropperModule"],
            ngx_skeleton_loader__WEBPACK_IMPORTED_MODULE_16__["NgxSkeletonLoaderModule"].forRoot(),
            angular_responsive_carousel__WEBPACK_IMPORTED_MODULE_20__["IvyCarouselModule"],
            ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_23__["NgMultiSelectDropDownModule"].forRoot(),
            _ckeditor_ckeditor5_angular__WEBPACK_IMPORTED_MODULE_24__["CKEditorModule"],
            ngx_page_scroll__WEBPACK_IMPORTED_MODULE_25__["NgxPageScrollModule"],
            _angular_fire__WEBPACK_IMPORTED_MODULE_4__["AngularFireModule"].initializeApp(_environments_environment__WEBPACK_IMPORTED_MODULE_29__["environment"].firebase),
            _angular_fire_database__WEBPACK_IMPORTED_MODULE_5__["AngularFireDatabaseModule"],
        ],
        providers: [
            _services_appinit_service__WEBPACK_IMPORTED_MODULE_28__["AppinitService"],
            { provide: _angular_core__WEBPACK_IMPORTED_MODULE_2__["APP_INITIALIZER"], useFactory: runAtAppInit1, deps: [_services_appinit_service__WEBPACK_IMPORTED_MODULE_28__["AppinitService"]], multi: true },
            { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_11__["HTTP_INTERCEPTORS"], useClass: _token_interceptor__WEBPACK_IMPORTED_MODULE_31__["JwtInterceptor"], multi: true },
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _route_cache__WEBPACK_IMPORTED_MODULE_6__["RouteCache"] },
            _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_32__["AngularFirestore"],
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]],
    })
], AppModule);



/***/ }),

/***/ "./src/app/auth.guard.ts":
/*!*******************************!*\
  !*** ./src/app/auth.guard.ts ***!
  \*******************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngxs/store */ "./node_modules/@ngxs/store/fesm2015/ngxs-store.js");
/* harmony import */ var _state_loggedinuser_state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./state/loggedinuser.state */ "./src/app/state/loggedinuser.state.ts");





let AuthGuard = class AuthGuard {
    constructor(_router) {
        this._router = _router;
        this.loggedInUser$.subscribe((resp) => {
            this.isLoggedIn = resp.LoggedInUser.isLoggedIn;
        });
    }
    canActivate(next, state) {
        let url = state.url;
        return this.checkLogin(url);
    }
    checkLogin(url) {
        if (this.isLoggedIn) {
            return true;
        }
        // Store the attempted URL for redirecting
        this.redirectUrl = url;
        // Navigate to the login page
        this._router.navigate(["/login"]);
        return false;
    }
};
AuthGuard.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngxs_store__WEBPACK_IMPORTED_MODULE_3__["Select"])(_state_loggedinuser_state__WEBPACK_IMPORTED_MODULE_4__["LoggedInUserState"])
], AuthGuard.prototype, "loggedInUser$", void 0);
AuthGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: "root",
    })
], AuthGuard);



/***/ }),

/***/ "./src/app/challenge/challenges-multi-select/challenges-multi-select.component.css":
/*!*****************************************************************************************!*\
  !*** ./src/app/challenge/challenges-multi-select/challenges-multi-select.component.css ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NoYWxsZW5nZS9jaGFsbGVuZ2VzLW11bHRpLXNlbGVjdC9jaGFsbGVuZ2VzLW11bHRpLXNlbGVjdC5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/challenge/challenges-multi-select/challenges-multi-select.component.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/challenge/challenges-multi-select/challenges-multi-select.component.ts ***!
  \****************************************************************************************/
/*! exports provided: ChallengesMultiSelectComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChallengesMultiSelectComponent", function() { return ChallengesMultiSelectComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let ChallengesMultiSelectComponent = class ChallengesMultiSelectComponent {
    constructor() { }
    ngOnInit() {
    }
};
ChallengesMultiSelectComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-challenges-multi-select',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./challenges-multi-select.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/challenge/challenges-multi-select/challenges-multi-select.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./challenges-multi-select.component.css */ "./src/app/challenge/challenges-multi-select/challenges-multi-select.component.css")).default]
    })
], ChallengesMultiSelectComponent);



/***/ }),

/***/ "./src/app/pages-partial/footer/footer.component.css":
/*!***********************************************************!*\
  !*** ./src/app/pages-partial/footer/footer.component.css ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ftr_social_icons i{\r\n    font-family: \"Font Awesome 5 Brands\";\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMtcGFydGlhbC9mb290ZXIvZm9vdGVyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxvQ0FBb0M7QUFDeEMiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy1wYXJ0aWFsL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5mdHJfc29jaWFsX2ljb25zIGl7XHJcbiAgICBmb250LWZhbWlseTogXCJGb250IEF3ZXNvbWUgNSBCcmFuZHNcIjtcclxufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages-partial/footer/footer.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/pages-partial/footer/footer.component.ts ***!
  \**********************************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let FooterComponent = class FooterComponent {
    constructor() { }
    ngOnInit() {
    }
};
FooterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-footer',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./footer.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages-partial/footer/footer.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./footer.component.css */ "./src/app/pages-partial/footer/footer.component.css")).default]
    })
], FooterComponent);



/***/ }),

/***/ "./src/app/pages-partial/header/header.component.css":
/*!***********************************************************!*\
  !*** ./src/app/pages-partial/header/header.component.css ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".current-user .dropdown-menu {\r\n\tleft: unset;\r\n\tright: 0;\r\n\tbox-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);\r\n\tborder-radius: 4px;\r\n\twidth: 120px;\r\n\t-webkit-transition: all 0.2s ease;\r\n\ttransition: all 0.2s ease;\r\n}\r\n\r\n.current-user {\r\n\t-webkit-user-select: none;\r\n\t   -moz-user-select: none;\r\n\t    -ms-user-select: none;\r\n\t        user-select: none;\r\n}\r\n\r\n.current-user .dropdown-menu a {\r\n\tcolor: var(--black18);\r\n\tfont-size: 12px;\r\n\tline-height: 1rem !important;\r\n}\r\n\r\n.current-user .dropdown-menu a:hover,\r\n.current-user .dropdown-menu a.is-active {\r\n\tbackground-color: #f5f5f5 !important;\r\n\tcolor: var(--primary-clr) !important;\r\n}\r\n\r\n.user-meta-avatar {\r\n\tdisplay: inline-block;\r\n\twidth: 45px;\r\n\theight: 45px;\r\n\tborder-radius: 50%;\r\n\tbackground-color: #b7b7b7;\r\n\tvertical-align: middle;\r\n}\r\n\r\n.current-user .name {\r\n\tvertical-align: middle;\r\n}\r\n\r\n.nav li a {\r\n\tposition: relative;\r\n\tborder: none !important;\r\n\ttext-decoration: none;\r\n\tbackground-color: transparent !important;\r\n\t-webkit-transition: all 0.3s ease;\r\n\ttransition: all 0.3s ease;\r\n\tline-height: 2rem !important;\r\n}\r\n\r\n.nav > li > a:hover,\r\n.nav > li > a.is-active {\r\n\tcolor: var(--primary-clr) !important;\r\n}\r\n\r\n.nav li a:after {\r\n\tcontent: \"\";\r\n\tposition: absolute;\r\n\twidth: 100%;\r\n\theight: 4px;\r\n\tleft: 0;\r\n\tbottom: -4px;\r\n\tbackground-color: var(--primary-clr);\r\n\tvisibility: hidden;\r\n\topacity: 0;\r\n\t-webkit-transition: opacity 0.3s ease;\r\n\ttransition: opacity 0.3s ease;\r\n}\r\n\r\n.nav li a:hover::after,\r\n.nav li a.is-active::after {\r\n\tvisibility: visible;\r\n\topacity: 1;\r\n}\r\n\r\n.current-user a::after {\r\n\tdisplay: none !important;\r\n}\r\n\r\n.sign-inout-menu {\r\n\tdisplay: -webkit-box;\r\n\tdisplay: flex;\r\n\t-webkit-box-align: center;\r\n\t        align-items: center;\r\n}\r\n\r\n.login_cta_btn {\r\n\tcolor: #fff;\r\n\tbackground: #2d9851;\r\n\tborder-radius: 4px;\r\n\tpadding: 14px 16px;\r\n\tfont-size: 12px;\r\n\tfont-weight: 400;\r\n}\r\n\r\n/* Header 1 new */\r\n\r\n.cix-logo{\r\n\tmax-width:311px;\r\n}\r\n\r\n.mohua-logo {\r\n\tmax-width:270px;\r\n}\r\n\r\n.scm-logo {\r\n\tmax-width:64.48px\r\n}\r\n\r\n.forge-logo {\r\n\tmax-width: 118.9px;\r\n}\r\n\r\n.badge.notification-badge{\r\n\ttop: -10px !important;\r\n    right: 7px !important;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMtcGFydGlhbC9oZWFkZXIvaGVhZGVyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Q0FDQyxXQUFXO0NBQ1gsUUFBUTtDQUNSLDJDQUEyQztDQUMzQyxrQkFBa0I7Q0FDbEIsWUFBWTtDQUNaLGlDQUF5QjtDQUF6Qix5QkFBeUI7QUFDMUI7O0FBRUE7Q0FDQyx5QkFBaUI7SUFBakIsc0JBQWlCO0tBQWpCLHFCQUFpQjtTQUFqQixpQkFBaUI7QUFDbEI7O0FBRUE7Q0FDQyxxQkFBcUI7Q0FDckIsZUFBZTtDQUNmLDRCQUE0QjtBQUM3Qjs7QUFFQTs7Q0FFQyxvQ0FBb0M7Q0FDcEMsb0NBQW9DO0FBQ3JDOztBQUVBO0NBQ0MscUJBQXFCO0NBQ3JCLFdBQVc7Q0FDWCxZQUFZO0NBQ1osa0JBQWtCO0NBQ2xCLHlCQUF5QjtDQUN6QixzQkFBc0I7QUFDdkI7O0FBRUE7Q0FDQyxzQkFBc0I7QUFDdkI7O0FBRUE7Q0FDQyxrQkFBa0I7Q0FDbEIsdUJBQXVCO0NBQ3ZCLHFCQUFxQjtDQUNyQix3Q0FBd0M7Q0FDeEMsaUNBQXlCO0NBQXpCLHlCQUF5QjtDQUN6Qiw0QkFBNEI7QUFDN0I7O0FBRUE7O0NBRUMsb0NBQW9DO0FBQ3JDOztBQUVBO0NBQ0MsV0FBVztDQUNYLGtCQUFrQjtDQUNsQixXQUFXO0NBQ1gsV0FBVztDQUNYLE9BQU87Q0FDUCxZQUFZO0NBQ1osb0NBQW9DO0NBQ3BDLGtCQUFrQjtDQUNsQixVQUFVO0NBQ1YscUNBQTZCO0NBQTdCLDZCQUE2QjtBQUM5Qjs7QUFFQTs7Q0FFQyxtQkFBbUI7Q0FDbkIsVUFBVTtBQUNYOztBQUVBO0NBQ0Msd0JBQXdCO0FBQ3pCOztBQUVBO0NBQ0Msb0JBQWE7Q0FBYixhQUFhO0NBQ2IseUJBQW1CO1NBQW5CLG1CQUFtQjtBQUNwQjs7QUFFQTtDQUNDLFdBQVc7Q0FDWCxtQkFBbUI7Q0FDbkIsa0JBQWtCO0NBQ2xCLGtCQUFrQjtDQUNsQixlQUFlO0NBQ2YsZ0JBQWdCO0FBQ2pCOztBQUVBLGlCQUFpQjs7QUFDakI7Q0FDQyxlQUFlO0FBQ2hCOztBQUNBO0NBQ0MsZUFBZTtBQUNoQjs7QUFDQTtDQUNDO0FBQ0Q7O0FBQ0E7Q0FDQyxrQkFBa0I7QUFDbkI7O0FBQ0E7Q0FDQyxxQkFBcUI7SUFDbEIscUJBQXFCO0FBQ3pCIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMtcGFydGlhbC9oZWFkZXIvaGVhZGVyLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY3VycmVudC11c2VyIC5kcm9wZG93bi1tZW51IHtcclxuXHRsZWZ0OiB1bnNldDtcclxuXHRyaWdodDogMDtcclxuXHRib3gtc2hhZG93OiAwcHggNHB4IDEwcHggcmdiYSgwLCAwLCAwLCAwLjIpO1xyXG5cdGJvcmRlci1yYWRpdXM6IDRweDtcclxuXHR3aWR0aDogMTIwcHg7XHJcblx0dHJhbnNpdGlvbjogYWxsIDAuMnMgZWFzZTtcclxufVxyXG5cclxuLmN1cnJlbnQtdXNlciB7XHJcblx0dXNlci1zZWxlY3Q6IG5vbmU7XHJcbn1cclxuXHJcbi5jdXJyZW50LXVzZXIgLmRyb3Bkb3duLW1lbnUgYSB7XHJcblx0Y29sb3I6IHZhcigtLWJsYWNrMTgpO1xyXG5cdGZvbnQtc2l6ZTogMTJweDtcclxuXHRsaW5lLWhlaWdodDogMXJlbSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uY3VycmVudC11c2VyIC5kcm9wZG93bi1tZW51IGE6aG92ZXIsXHJcbi5jdXJyZW50LXVzZXIgLmRyb3Bkb3duLW1lbnUgYS5pcy1hY3RpdmUge1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICNmNWY1ZjUgIWltcG9ydGFudDtcclxuXHRjb2xvcjogdmFyKC0tcHJpbWFyeS1jbHIpICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi51c2VyLW1ldGEtYXZhdGFyIHtcclxuXHRkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcblx0d2lkdGg6IDQ1cHg7XHJcblx0aGVpZ2h0OiA0NXB4O1xyXG5cdGJvcmRlci1yYWRpdXM6IDUwJTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAjYjdiN2I3O1xyXG5cdHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbn1cclxuXHJcbi5jdXJyZW50LXVzZXIgLm5hbWUge1xyXG5cdHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbn1cclxuXHJcbi5uYXYgbGkgYSB7XHJcblx0cG9zaXRpb246IHJlbGF0aXZlO1xyXG5cdGJvcmRlcjogbm9uZSAhaW1wb3J0YW50O1xyXG5cdHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG5cdHRyYW5zaXRpb246IGFsbCAwLjNzIGVhc2U7XHJcblx0bGluZS1oZWlnaHQ6IDJyZW0gIWltcG9ydGFudDtcclxufVxyXG5cclxuLm5hdiA+IGxpID4gYTpob3ZlcixcclxuLm5hdiA+IGxpID4gYS5pcy1hY3RpdmUge1xyXG5cdGNvbG9yOiB2YXIoLS1wcmltYXJ5LWNscikgIWltcG9ydGFudDtcclxufVxyXG5cclxuLm5hdiBsaSBhOmFmdGVyIHtcclxuXHRjb250ZW50OiBcIlwiO1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRoZWlnaHQ6IDRweDtcclxuXHRsZWZ0OiAwO1xyXG5cdGJvdHRvbTogLTRweDtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1wcmltYXJ5LWNscik7XHJcblx0dmlzaWJpbGl0eTogaGlkZGVuO1xyXG5cdG9wYWNpdHk6IDA7XHJcblx0dHJhbnNpdGlvbjogb3BhY2l0eSAwLjNzIGVhc2U7XHJcbn1cclxuXHJcbi5uYXYgbGkgYTpob3Zlcjo6YWZ0ZXIsXHJcbi5uYXYgbGkgYS5pcy1hY3RpdmU6OmFmdGVyIHtcclxuXHR2aXNpYmlsaXR5OiB2aXNpYmxlO1xyXG5cdG9wYWNpdHk6IDE7XHJcbn1cclxuXHJcbi5jdXJyZW50LXVzZXIgYTo6YWZ0ZXIge1xyXG5cdGRpc3BsYXk6IG5vbmUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnNpZ24taW5vdXQtbWVudSB7XHJcblx0ZGlzcGxheTogZmxleDtcclxuXHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4ubG9naW5fY3RhX2J0biB7XHJcblx0Y29sb3I6ICNmZmY7XHJcblx0YmFja2dyb3VuZDogIzJkOTg1MTtcclxuXHRib3JkZXItcmFkaXVzOiA0cHg7XHJcblx0cGFkZGluZzogMTRweCAxNnB4O1xyXG5cdGZvbnQtc2l6ZTogMTJweDtcclxuXHRmb250LXdlaWdodDogNDAwO1xyXG59XHJcblxyXG4vKiBIZWFkZXIgMSBuZXcgKi9cclxuLmNpeC1sb2dve1xyXG5cdG1heC13aWR0aDozMTFweDtcclxufVxyXG4ubW9odWEtbG9nbyB7XHJcblx0bWF4LXdpZHRoOjI3MHB4O1xyXG59XHJcbi5zY20tbG9nbyB7XHJcblx0bWF4LXdpZHRoOjY0LjQ4cHhcclxufVxyXG4uZm9yZ2UtbG9nbyB7XHJcblx0bWF4LXdpZHRoOiAxMTguOXB4O1xyXG59XHJcbi5iYWRnZS5ub3RpZmljYXRpb24tYmFkZ2V7XHJcblx0dG9wOiAtMTBweCAhaW1wb3J0YW50O1xyXG4gICAgcmlnaHQ6IDdweCAhaW1wb3J0YW50O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "./src/app/pages-partial/header/header.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/pages-partial/header/header.component.ts ***!
  \**********************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _services_helpers_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/helpers.service */ "./src/app/services/helpers.service.ts");
/* harmony import */ var _route_cache__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../route-cache */ "./src/app/route-cache.ts");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngxs/store */ "./node_modules/@ngxs/store/fesm2015/ngxs-store.js");
/* harmony import */ var _state_loggedinuser_state__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../state/loggedinuser.state */ "./src/app/state/loggedinuser.state.ts");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/auth.service */ "./src/app/services/auth.service.ts");








let HeaderComponent = class HeaderComponent {
    constructor(router, _hs, _rcache, _store, auth) {
        this.router = router;
        this._hs = _hs;
        this._rcache = _rcache;
        this._store = _store;
        this.auth = auth;
        this.hideLogin = false;
        this._hs.getAppLogo().subscribe((resp) => {
            this.logo$ = resp;
        });
        this.router.events.subscribe((url) => {
            if (this.router.url === "/login") {
                this.hideLogin = true;
            }
            else {
                this.hideLogin = false;
            }
        });
        this.loggedInUser$.subscribe((resp) => {
            this.currentUserData = resp.LoggedInUser;
        });
    }
    ngOnInit() { }
    logout() {
        this.auth.logout();
    }
};
HeaderComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _services_helpers_service__WEBPACK_IMPORTED_MODULE_3__["HelpersService"] },
    { type: _route_cache__WEBPACK_IMPORTED_MODULE_4__["RouteCache"] },
    { type: _ngxs_store__WEBPACK_IMPORTED_MODULE_5__["Store"] },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngxs_store__WEBPACK_IMPORTED_MODULE_5__["Select"])(_state_loggedinuser_state__WEBPACK_IMPORTED_MODULE_6__["LoggedInUserState"])
], HeaderComponent.prototype, "loggedInUser$", void 0);
HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-header",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./header.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages-partial/header/header.component.html")).default,
        providers: [_route_cache__WEBPACK_IMPORTED_MODULE_4__["RouteCache"]],
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./header.component.css */ "./src/app/pages-partial/header/header.component.css")).default]
    })
], HeaderComponent);



/***/ }),

/***/ "./src/app/pages-partial/pages-partial.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages-partial/pages-partial.module.ts ***!
  \*******************************************************/
/*! exports provided: PagesPartialModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PagesPartialModule", function() { return PagesPartialModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _shared_widgets_widgets_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/widgets/widgets.module */ "./src/app/shared/widgets/widgets.module.ts");
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./footer/footer.component */ "./src/app/pages-partial/footer/footer.component.ts");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./header/header.component */ "./src/app/pages-partial/header/header.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");







let PagesPartialModule = class PagesPartialModule {
};
PagesPartialModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__["FooterComponent"], _header_header_component__WEBPACK_IMPORTED_MODULE_5__["HeaderComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _shared_widgets_widgets_module__WEBPACK_IMPORTED_MODULE_3__["WidgetsModule"], _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"]],
        exports: [_footer_footer_component__WEBPACK_IMPORTED_MODULE_4__["FooterComponent"], _header_header_component__WEBPACK_IMPORTED_MODULE_5__["HeaderComponent"]],
    })
], PagesPartialModule);



/***/ }),

/***/ "./src/app/pages/city-stats/city-stats.component.css":
/*!***********************************************************!*\
  !*** ./src/app/pages/city-stats/city-stats.component.css ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".stat-search-box form{\r\n    display: -webkit-box;\r\n    display: flex;  \r\n    border: 1px solid #2641ad;  \r\n    border-radius: 4px;\r\n}\r\n\r\n.stat-search-box form .search-input-wrp{\r\n    flex-basis: 90%;\r\n}\r\n\r\n.stat-search-box form button{\r\n    flex-basis: 10%;\r\n    background-color:#2641ad;\r\n    color: var(--white);\r\n    border: none !important;\r\n}\r\n\r\n.search-input-wrp input{\r\n    width:100%;\r\n    outline: none !important;\r\n    border: none !important;\r\n    border-radius: 4px;\r\n}\r\n\r\n.counters-wrap{\r\n    display: -webkit-box;\r\n    display: flex;\r\n    -webkit-box-pack: justify;\r\n            justify-content: space-between;\r\n    flex-wrap: wrap;\r\n}\r\n\r\n.counter-item{\r\n    flex-basis: 30%;\r\n    margin-bottom: 36px;\r\n}\r\n\r\n.counter-item .value{\r\n    font-size: 2.8rem !important;\r\n    line-height: 3.2rem !important;\r\n    color: #000;\r\n    font-weight: 300;\r\n}\r\n\r\n.counter-item .name{\r\n    opacity: 0.5;\r\n    font-size: 0.7rem;\r\n    line-height: 1.4rem;\r\n    font-weight: 500;\r\n}\r\n\r\n.search-input-wrp .search-box{\r\n    position: relative;\r\n}\r\n\r\n.search-auto-complete-wrp{\r\n    position: absolute;\r\n    top:50px;\r\n    width:100%;\r\n    overflow-y: auto;\r\n    background-color:var(--white);\r\n    border-top:1px solid #c3c7ce76 !important;\r\n    z-index:10;\r\n    border-radius:6px;\r\n    box-shadow: 0px 4px 25px rgba(172, 177, 193, 0.4);\r\n  }\r\n\r\n.search-auto-complete-wrp ul{\r\n    margin:0;\r\n    padding:0;\r\n    list-style-type: none;\r\n  }\r\n\r\n.search-auto-complete-wrp ul li{ \r\n    font-size:13px;\r\n    color: #5f6368;\r\n  }\r\n\r\n.search-auto-complete-wrp ul li div{\r\n    padding:6px 15px;\r\n    -webkit-transition:all 0.2s;\r\n    transition:all 0.2s;\r\n    cursor: pointer;\r\n  }\r\n\r\n.search-auto-complete-wrp ul li div:hover{\r\n    background-color: #f5f5f5;\r\n  }\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY2l0eS1zdGF0cy9jaXR5LXN0YXRzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxvQkFBYTtJQUFiLGFBQWE7SUFDYix5QkFBeUI7SUFDekIsa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksZUFBZTtBQUNuQjs7QUFFQTtJQUNJLGVBQWU7SUFDZix3QkFBd0I7SUFDeEIsbUJBQW1CO0lBQ25CLHVCQUF1QjtBQUMzQjs7QUFFQTtJQUNJLFVBQVU7SUFDVix3QkFBd0I7SUFDeEIsdUJBQXVCO0lBQ3ZCLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLG9CQUFhO0lBQWIsYUFBYTtJQUNiLHlCQUE4QjtZQUE5Qiw4QkFBOEI7SUFDOUIsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLGVBQWU7SUFDZixtQkFBbUI7QUFDdkI7O0FBRUE7SUFDSSw0QkFBNEI7SUFDNUIsOEJBQThCO0lBQzlCLFdBQVc7SUFDWCxnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxZQUFZO0lBQ1osaUJBQWlCO0lBQ2pCLG1CQUFtQjtJQUNuQixnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsUUFBUTtJQUNSLFVBQVU7SUFDVixnQkFBZ0I7SUFDaEIsNkJBQTZCO0lBQzdCLHlDQUF5QztJQUN6QyxVQUFVO0lBQ1YsaUJBQWlCO0lBQ2pCLGlEQUFpRDtFQUNuRDs7QUFFQTtJQUNFLFFBQVE7SUFDUixTQUFTO0lBQ1QscUJBQXFCO0VBQ3ZCOztBQUVBO0lBQ0UsY0FBYztJQUNkLGNBQWM7RUFDaEI7O0FBRUE7SUFDRSxnQkFBZ0I7SUFDaEIsMkJBQW1CO0lBQW5CLG1CQUFtQjtJQUNuQixlQUFlO0VBQ2pCOztBQUVBO0lBQ0UseUJBQXlCO0VBQzNCIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvY2l0eS1zdGF0cy9jaXR5LXN0YXRzLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3RhdC1zZWFyY2gtYm94IGZvcm17XHJcbiAgICBkaXNwbGF5OiBmbGV4OyAgXHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjMjY0MWFkOyAgXHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbn1cclxuXHJcbi5zdGF0LXNlYXJjaC1ib3ggZm9ybSAuc2VhcmNoLWlucHV0LXdycHtcclxuICAgIGZsZXgtYmFzaXM6IDkwJTtcclxufVxyXG5cclxuLnN0YXQtc2VhcmNoLWJveCBmb3JtIGJ1dHRvbntcclxuICAgIGZsZXgtYmFzaXM6IDEwJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IzI2NDFhZDtcclxuICAgIGNvbG9yOiB2YXIoLS13aGl0ZSk7XHJcbiAgICBib3JkZXI6IG5vbmUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnNlYXJjaC1pbnB1dC13cnAgaW5wdXR7XHJcbiAgICB3aWR0aDoxMDAlO1xyXG4gICAgb3V0bGluZTogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyOiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbn1cclxuXHJcbi5jb3VudGVycy13cmFwe1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgIGZsZXgtd3JhcDogd3JhcDtcclxufVxyXG5cclxuLmNvdW50ZXItaXRlbXtcclxuICAgIGZsZXgtYmFzaXM6IDMwJTtcclxuICAgIG1hcmdpbi1ib3R0b206IDM2cHg7XHJcbn1cclxuXHJcbi5jb3VudGVyLWl0ZW0gLnZhbHVle1xyXG4gICAgZm9udC1zaXplOiAyLjhyZW0gIWltcG9ydGFudDtcclxuICAgIGxpbmUtaGVpZ2h0OiAzLjJyZW0gIWltcG9ydGFudDtcclxuICAgIGNvbG9yOiAjMDAwO1xyXG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcclxufVxyXG5cclxuLmNvdW50ZXItaXRlbSAubmFtZXtcclxuICAgIG9wYWNpdHk6IDAuNTtcclxuICAgIGZvbnQtc2l6ZTogMC43cmVtO1xyXG4gICAgbGluZS1oZWlnaHQ6IDEuNHJlbTtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuXHJcbi5zZWFyY2gtaW5wdXQtd3JwIC5zZWFyY2gtYm94e1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcblxyXG4uc2VhcmNoLWF1dG8tY29tcGxldGUtd3Jwe1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOjUwcHg7XHJcbiAgICB3aWR0aDoxMDAlO1xyXG4gICAgb3ZlcmZsb3cteTogYXV0bztcclxuICAgIGJhY2tncm91bmQtY29sb3I6dmFyKC0td2hpdGUpO1xyXG4gICAgYm9yZGVyLXRvcDoxcHggc29saWQgI2MzYzdjZTc2ICFpbXBvcnRhbnQ7XHJcbiAgICB6LWluZGV4OjEwO1xyXG4gICAgYm9yZGVyLXJhZGl1czo2cHg7XHJcbiAgICBib3gtc2hhZG93OiAwcHggNHB4IDI1cHggcmdiYSgxNzIsIDE3NywgMTkzLCAwLjQpO1xyXG4gIH1cclxuICBcclxuICAuc2VhcmNoLWF1dG8tY29tcGxldGUtd3JwIHVse1xyXG4gICAgbWFyZ2luOjA7XHJcbiAgICBwYWRkaW5nOjA7XHJcbiAgICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XHJcbiAgfVxyXG4gIFxyXG4gIC5zZWFyY2gtYXV0by1jb21wbGV0ZS13cnAgdWwgbGl7IFxyXG4gICAgZm9udC1zaXplOjEzcHg7XHJcbiAgICBjb2xvcjogIzVmNjM2ODtcclxuICB9XHJcbiAgXHJcbiAgLnNlYXJjaC1hdXRvLWNvbXBsZXRlLXdycCB1bCBsaSBkaXZ7XHJcbiAgICBwYWRkaW5nOjZweCAxNXB4O1xyXG4gICAgdHJhbnNpdGlvbjphbGwgMC4ycztcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICB9XHJcbiAgXHJcbiAgLnNlYXJjaC1hdXRvLWNvbXBsZXRlLXdycCB1bCBsaSBkaXY6aG92ZXJ7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmNWY1O1xyXG4gIH1cclxuIl19 */");

/***/ }),

/***/ "./src/app/pages/city-stats/city-stats.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/pages/city-stats/city-stats.component.ts ***!
  \**********************************************************/
/*! exports provided: CityStatsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CityStatsComponent", function() { return CityStatsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _citystats_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./citystats-service.service */ "./src/app/pages/city-stats/citystats-service.service.ts");



let CityStatsComponent = class CityStatsComponent {
    constructor(_city) {
        this._city = _city;
        this.cityName = 'bengaluru'; //by default bengaluru will be displayed
    }
    ngOnInit() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            yield this.fetchCityData(this.cityName);
        });
    }
    fetchCityData(name) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                this.loading = true;
                let cityResp = yield this._city.getCityInformation(name);
                this.cityData = cityResp.data[0];
                this.loading = false;
            }
            catch (err) {
                console.log(err);
            }
        });
    }
    searchCity() {
        if (this.cityKeyWord.length == 0) {
            this.fetchCityData(this.cityName);
        }
        else {
            this.fetchCityData(this.cityKeyWord);
        }
        this.autoSuggestions = null;
    }
    autoComplete(keyword) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (keyword.length > 3) {
                this.autoSuggestions = yield this._city.getSearchSuggestions(keyword);
            }
            else {
                this.autoSuggestions = null;
            }
        });
    }
    searchAutoSuggestion(keyword) {
        this.cityKeyWord = keyword;
        this.autoSuggestions = null;
        this.fetchCityData(this.cityKeyWord);
    }
};
CityStatsComponent.ctorParameters = () => [
    { type: _citystats_service_service__WEBPACK_IMPORTED_MODULE_2__["CitystatsServiceService"] }
];
CityStatsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'city-stats',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./city-stats.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/city-stats/city-stats.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./city-stats.component.css */ "./src/app/pages/city-stats/city-stats.component.css")).default]
    })
], CityStatsComponent);



/***/ }),

/***/ "./src/app/pages/city-stats/citystats-service.service.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/city-stats/citystats-service.service.ts ***!
  \***************************************************************/
/*! exports provided: CitystatsServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CitystatsServiceService", function() { return CitystatsServiceService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");




let CitystatsServiceService = class CitystatsServiceService {
    constructor(http) {
        this.http = http;
        this.api_url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].api_url;
    }
    getCityInformation(cityName) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            return yield this.http.post(this.api_url + "/smart_cities/select_mul", {
                search: {
                    name: cityName
                }
            }).toPromise();
        });
    }
    getSearchSuggestions(keyword) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            return yield this.http.post(this.api_url + '/smart_cities/select_mul', {
                search: {
                    name: { contains: keyword }
                }
            }).toPromise();
        });
    }
};
CitystatsServiceService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
];
CitystatsServiceService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], CitystatsServiceService);



/***/ }),

/***/ "./src/app/pages/help/help.component.css":
/*!***********************************************!*\
  !*** ./src/app/pages/help/help.component.css ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".l-help-sec-1-cont{\r\n    border-top: 1px solid #DEE0E6;\r\n    border-bottom: 1px solid #DEE0E6;\r\n}\r\n.l-hlp-hdr{\r\n    color: var(--title-active) !important;\r\n}\r\n.l-help-sec-1-inpt-cont .l-help-sec-1-inpt-grp{\r\n    margin: auto;\r\n}\r\n.l-help-sec-1-inpt-grp input{\r\n    padding-top:8px !important;\r\n    padding-bottom: 8px !important;\r\n    border-top-left-radius: 5px;\r\n    border-bottom-left-radius: 5px;\r\n    background: #EEEFF3;\r\n}\r\n.l-help-sec-1-inpt-grp input:hover,.l-help-sec-1-inpt-grp input:focus,.l-help-sec-1-inpt-grp input:active{\r\n    outline: none !important;\r\n    box-shadow: none !important;\r\n}\r\n.l-help-sec-1-inpt-grp button {\r\n    background: var(--primary-clr) !important;\r\n    color:#fff !important;\r\n    border-top-right-radius: 5px;\r\n    border-bottom-right-radius: 5px;\r\n    padding-top:9px !important;\r\n    padding-bottom: 9px !important;\r\n}\r\n.l-help-sec-1-inpt-grp i {\r\n    font-size: 12px;\r\n    margin-right: 10px;\r\n}\r\n.l-help-sec-1-tabs ul li {\r\n    margin-right: 25px;\r\n    width: 193px;\r\n}\r\n.l-help-sec-1-tabs ul li:last-child{\r\n    margin-right: 0px;\r\n}\r\n.l-help-sec-1-tabs ul li a{\r\n   padding:15px 20px !important;\r\n}\r\n.l-help-sec-1-tabs{\r\n    max-width: 1300px;\r\n    margin: auto;\r\n}\r\n.l-help-sec-1-tabs .nav-tabs>li>a{\r\n    border: 2px solid #ddd;\r\n    border-radius: 4px;\r\n}\r\n.l-help-sec-1-tabs .nav-tabs>li.active>a{\r\n    border: 2px solid #2D9851;\r\n    color: var(--primary-clr) !important;\r\n\r\n}\r\n.l-help-sec-1-tabs .nav-tabs{\r\n    border-bottom:0px  !important;\r\n}\r\n.l-hlp-getting-start-col-1-hdr{\r\n    font-size: 12px;\r\n    text-transform: uppercase;\r\n}\r\n.l-hlp-getting-start-col-1-ul{\r\n    list-style-type: none;\r\n    padding-left: 0px;\r\n}\r\n.l-hlp-getting-start-col-1-ul li:first-child{\r\n    border-top:1px solid #4f4f4f52;\r\n}\r\n.l-hlp-getting-start-col-1-ul li{\r\n    border-bottom:1px solid #4f4f4f52;\r\n}\r\n.l-hlp-getting-start-col-1-ul li a{\r\n    color: var(--black-clr);\r\n}\r\n.l-hlp-getting-start-col-2-cont{\r\n    border: 1px solid #DEDEDE;\r\n    border-radius: 4px;\r\n}\r\n.l-hlp-getting-start-col-2-cont .panel-group .panel-heading+.panel-collapse>.panel-body{\r\n    border-top: 0px\r\n}\r\n.l-hlp-getting-start-col-2-cont .panel-default{\r\n    border-left: 0px;\r\n    border-right: 0px;\r\n    border-bottom: 0px;\r\n    box-shadow: none  !important;\r\n}\r\n.l-hlp-getting-start-col-2-cont .panel-default>.panel-heading{\r\n    background-color: transparent  !important;\r\n}\r\n.l-hlp-getting-start-col-2-cont .panel-group .panel{\r\n    border-radius: 0px !important;\r\n}\r\n.l-hlp-getting-start-col-2-acc-hdr{\r\n    color: var(--black-clr)\r\n}\r\n.l-hlp-getting-start-col-2-acc-icon{\r\n    float:right;\r\n}\r\n.l-hlp-getting-start-desc{\r\n    color :var(--black-clr) !important;\r\n}\r\n.l-hlp-getting-start-prod-pub-date{\r\n    color :var(--black-clr) !important;\r\n}\r\n.l-hlp-getting-start-prod-ul li{\r\n    color :var(--black-clr) !important;\r\n}\r\n.l-hlp-get-started-glos-cont{\r\n    border-bottom: 1px solid #DEE0E6;\r\n}\r\n.l-hlp-get-started-glos-cont:last-child{\r\n    border-bottom: 0px!important;\r\n}\r\n.l-hlp-cont-labl{\r\n    color:#0E2E18;\r\n}\r\n.l-get-strd-hlp-cont-frm textarea {\r\n    resize: none;\r\n}\r\n.l-get-star-cont-col-2-text{\r\n    color: #4F4F4F;\r\n    border-bottom: 1px solid #4f4f4f40;\r\n}\r\n.l-get-start-cont-icn-cont{\r\n    margin-top: 10px;\r\n}\r\n.l-get-start-cont-col-2-text{\r\n    color :var(--black-clr) !important;\r\n    margin-top: 23px;\r\n}\r\n.l-get-start-cont-col-2-cont{\r\n    border-bottom: 1px solid #4f4f4f40;\r\n}\r\n.l-hlp-getting-start-cnt-frm-msg-cont{\r\n    border: 1px solid #186A34;\r\n}\r\n.l-get-start-cont-us-link{\r\n    color :var(--black-clr) !important;\r\n}\r\n.help-content-area{\r\n    min-height: 100vh;\r\n}\r\n.l-tble-right-chev-icon{\r\n    float: right;\r\n    margin-top: 5px;\r\n}\r\n.l-hlp-tabs-title{\r\n    color: #4F4F4F;\r\n}\r\n.l-hlp-get-strd-li a.active{\r\n    color: #4F4F4F;\r\n    font-weight: 700 !important;\r\n}\r\n.dwnld_smrt_pro{\r\n    margin-top: 30px;\r\n}\r\n.dwnld_smrt_pro a{\r\n    color: #fff;\r\n    background: #2d9851;\r\n    border-radius: 4px;\r\n    padding: 14px 16px;\r\n    font-size: 12px;\r\n    font-weight: 400;\r\n}\r\n.dwnld_smrt_pro_lbl{\r\n    font-size: 10px;\r\n    line-height: 15px;\r\n    font-weight: 400;\r\n    margin-top: 15px;\r\n}\r\n.resouces_img_btn_wrapper{\r\n    display: -webkit-box;\r\n    display: flex;\r\n    gap: 40px;\r\n    flex-wrap: wrap;\r\n}\r\n.resouces_img_btn_cont img{\r\n    max-width: 177px;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaGVscC9oZWxwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSw2QkFBNkI7SUFDN0IsZ0NBQWdDO0FBQ3BDO0FBQ0E7SUFDSSxxQ0FBcUM7QUFDekM7QUFDQTtJQUNJLFlBQVk7QUFDaEI7QUFDQTtJQUNJLDBCQUEwQjtJQUMxQiw4QkFBOEI7SUFDOUIsMkJBQTJCO0lBQzNCLDhCQUE4QjtJQUM5QixtQkFBbUI7QUFDdkI7QUFDQTtJQUNJLHdCQUF3QjtJQUN4QiwyQkFBMkI7QUFDL0I7QUFDQTtJQUNJLHlDQUF5QztJQUN6QyxxQkFBcUI7SUFDckIsNEJBQTRCO0lBQzVCLCtCQUErQjtJQUMvQiwwQkFBMEI7SUFDMUIsOEJBQThCO0FBQ2xDO0FBQ0E7SUFDSSxlQUFlO0lBQ2Ysa0JBQWtCO0FBQ3RCO0FBQ0E7SUFDSSxrQkFBa0I7SUFDbEIsWUFBWTtBQUNoQjtBQUNBO0lBQ0ksaUJBQWlCO0FBQ3JCO0FBQ0E7R0FDRyw0QkFBNEI7QUFDL0I7QUFDQTtJQUNJLGlCQUFpQjtJQUNqQixZQUFZO0FBQ2hCO0FBQ0E7SUFDSSxzQkFBc0I7SUFDdEIsa0JBQWtCO0FBQ3RCO0FBQ0E7SUFDSSx5QkFBeUI7SUFDekIsb0NBQW9DOztBQUV4QztBQUNBO0lBQ0ksNkJBQTZCO0FBQ2pDO0FBQ0E7SUFDSSxlQUFlO0lBQ2YseUJBQXlCO0FBQzdCO0FBQ0E7SUFDSSxxQkFBcUI7SUFDckIsaUJBQWlCO0FBQ3JCO0FBQ0E7SUFDSSw4QkFBOEI7QUFDbEM7QUFDQTtJQUNJLGlDQUFpQztBQUNyQztBQUNBO0lBQ0ksdUJBQXVCO0FBQzNCO0FBQ0E7SUFDSSx5QkFBeUI7SUFDekIsa0JBQWtCO0FBQ3RCO0FBQ0E7SUFDSTtBQUNKO0FBQ0E7SUFDSSxnQkFBZ0I7SUFDaEIsaUJBQWlCO0lBQ2pCLGtCQUFrQjtJQUNsQiw0QkFBNEI7QUFDaEM7QUFDQTtJQUNJLHlDQUF5QztBQUM3QztBQUNBO0lBQ0ksNkJBQTZCO0FBQ2pDO0FBQ0E7SUFDSTtBQUNKO0FBQ0E7SUFDSSxXQUFXO0FBQ2Y7QUFDQTtJQUNJLGtDQUFrQztBQUN0QztBQUNBO0lBQ0ksa0NBQWtDO0FBQ3RDO0FBQ0E7SUFDSSxrQ0FBa0M7QUFDdEM7QUFDQTtJQUNJLGdDQUFnQztBQUNwQztBQUNBO0lBQ0ksNEJBQTRCO0FBQ2hDO0FBQ0E7SUFDSSxhQUFhO0FBQ2pCO0FBQ0E7SUFDSSxZQUFZO0FBQ2hCO0FBQ0E7SUFDSSxjQUFjO0lBQ2Qsa0NBQWtDO0FBQ3RDO0FBQ0E7SUFDSSxnQkFBZ0I7QUFDcEI7QUFDQTtJQUNJLGtDQUFrQztJQUNsQyxnQkFBZ0I7QUFDcEI7QUFDQTtJQUNJLGtDQUFrQztBQUN0QztBQUNBO0lBQ0kseUJBQXlCO0FBQzdCO0FBQ0E7SUFDSSxrQ0FBa0M7QUFDdEM7QUFFQTtJQUNJLGlCQUFpQjtBQUNyQjtBQUNBO0lBQ0ksWUFBWTtJQUNaLGVBQWU7QUFDbkI7QUFDQTtJQUNJLGNBQWM7QUFDbEI7QUFDQTtJQUNJLGNBQWM7SUFDZCwyQkFBMkI7QUFDL0I7QUFDQTtJQUNJLGdCQUFnQjtBQUNwQjtBQUNBO0lBQ0ksV0FBVztJQUNYLG1CQUFtQjtJQUNuQixrQkFBa0I7SUFDbEIsa0JBQWtCO0lBQ2xCLGVBQWU7SUFDZixnQkFBZ0I7QUFDcEI7QUFDQTtJQUNJLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsZ0JBQWdCO0lBQ2hCLGdCQUFnQjtBQUNwQjtBQUNBO0lBQ0ksb0JBQWE7SUFBYixhQUFhO0lBQ2IsU0FBUztJQUNULGVBQWU7QUFDbkI7QUFDQTtJQUNJLGdCQUFnQjtBQUNwQiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2hlbHAvaGVscC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmwtaGVscC1zZWMtMS1jb250e1xyXG4gICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNERUUwRTY7XHJcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI0RFRTBFNjtcclxufVxyXG4ubC1obHAtaGRye1xyXG4gICAgY29sb3I6IHZhcigtLXRpdGxlLWFjdGl2ZSkgIWltcG9ydGFudDtcclxufVxyXG4ubC1oZWxwLXNlYy0xLWlucHQtY29udCAubC1oZWxwLXNlYy0xLWlucHQtZ3Jwe1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG59XHJcbi5sLWhlbHAtc2VjLTEtaW5wdC1ncnAgaW5wdXR7XHJcbiAgICBwYWRkaW5nLXRvcDo4cHggIWltcG9ydGFudDtcclxuICAgIHBhZGRpbmctYm90dG9tOiA4cHggIWltcG9ydGFudDtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDVweDtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDVweDtcclxuICAgIGJhY2tncm91bmQ6ICNFRUVGRjM7XHJcbn1cclxuLmwtaGVscC1zZWMtMS1pbnB0LWdycCBpbnB1dDpob3ZlciwubC1oZWxwLXNlYy0xLWlucHQtZ3JwIGlucHV0OmZvY3VzLC5sLWhlbHAtc2VjLTEtaW5wdC1ncnAgaW5wdXQ6YWN0aXZle1xyXG4gICAgb3V0bGluZTogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcbi5sLWhlbHAtc2VjLTEtaW5wdC1ncnAgYnV0dG9uIHtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLXByaW1hcnktY2xyKSAhaW1wb3J0YW50O1xyXG4gICAgY29sb3I6I2ZmZiAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDVweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1cHg7XHJcbiAgICBwYWRkaW5nLXRvcDo5cHggIWltcG9ydGFudDtcclxuICAgIHBhZGRpbmctYm90dG9tOiA5cHggIWltcG9ydGFudDtcclxufVxyXG4ubC1oZWxwLXNlYy0xLWlucHQtZ3JwIGkge1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG59XHJcbi5sLWhlbHAtc2VjLTEtdGFicyB1bCBsaSB7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDI1cHg7XHJcbiAgICB3aWR0aDogMTkzcHg7XHJcbn1cclxuLmwtaGVscC1zZWMtMS10YWJzIHVsIGxpOmxhc3QtY2hpbGR7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDBweDtcclxufVxyXG4ubC1oZWxwLXNlYy0xLXRhYnMgdWwgbGkgYXtcclxuICAgcGFkZGluZzoxNXB4IDIwcHggIWltcG9ydGFudDtcclxufVxyXG4ubC1oZWxwLXNlYy0xLXRhYnN7XHJcbiAgICBtYXgtd2lkdGg6IDEzMDBweDtcclxuICAgIG1hcmdpbjogYXV0bztcclxufVxyXG4ubC1oZWxwLXNlYy0xLXRhYnMgLm5hdi10YWJzPmxpPmF7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCAjZGRkO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG59XHJcbi5sLWhlbHAtc2VjLTEtdGFicyAubmF2LXRhYnM+bGkuYWN0aXZlPmF7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCAjMkQ5ODUxO1xyXG4gICAgY29sb3I6IHZhcigtLXByaW1hcnktY2xyKSAhaW1wb3J0YW50O1xyXG5cclxufVxyXG4ubC1oZWxwLXNlYy0xLXRhYnMgLm5hdi10YWJze1xyXG4gICAgYm9yZGVyLWJvdHRvbTowcHggICFpbXBvcnRhbnQ7XHJcbn1cclxuLmwtaGxwLWdldHRpbmctc3RhcnQtY29sLTEtaGRye1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxufVxyXG4ubC1obHAtZ2V0dGluZy1zdGFydC1jb2wtMS11bHtcclxuICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcclxuICAgIHBhZGRpbmctbGVmdDogMHB4O1xyXG59XHJcbi5sLWhscC1nZXR0aW5nLXN0YXJ0LWNvbC0xLXVsIGxpOmZpcnN0LWNoaWxke1xyXG4gICAgYm9yZGVyLXRvcDoxcHggc29saWQgIzRmNGY0ZjUyO1xyXG59XHJcbi5sLWhscC1nZXR0aW5nLXN0YXJ0LWNvbC0xLXVsIGxpe1xyXG4gICAgYm9yZGVyLWJvdHRvbToxcHggc29saWQgIzRmNGY0ZjUyO1xyXG59XHJcbi5sLWhscC1nZXR0aW5nLXN0YXJ0LWNvbC0xLXVsIGxpIGF7XHJcbiAgICBjb2xvcjogdmFyKC0tYmxhY2stY2xyKTtcclxufVxyXG4ubC1obHAtZ2V0dGluZy1zdGFydC1jb2wtMi1jb250e1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI0RFREVERTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxufVxyXG4ubC1obHAtZ2V0dGluZy1zdGFydC1jb2wtMi1jb250IC5wYW5lbC1ncm91cCAucGFuZWwtaGVhZGluZysucGFuZWwtY29sbGFwc2U+LnBhbmVsLWJvZHl7XHJcbiAgICBib3JkZXItdG9wOiAwcHhcclxufVxyXG4ubC1obHAtZ2V0dGluZy1zdGFydC1jb2wtMi1jb250IC5wYW5lbC1kZWZhdWx0e1xyXG4gICAgYm9yZGVyLWxlZnQ6IDBweDtcclxuICAgIGJvcmRlci1yaWdodDogMHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMHB4O1xyXG4gICAgYm94LXNoYWRvdzogbm9uZSAgIWltcG9ydGFudDtcclxufVxyXG4ubC1obHAtZ2V0dGluZy1zdGFydC1jb2wtMi1jb250IC5wYW5lbC1kZWZhdWx0Pi5wYW5lbC1oZWFkaW5ne1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQgICFpbXBvcnRhbnQ7XHJcbn1cclxuLmwtaGxwLWdldHRpbmctc3RhcnQtY29sLTItY29udCAucGFuZWwtZ3JvdXAgLnBhbmVse1xyXG4gICAgYm9yZGVyLXJhZGl1czogMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuLmwtaGxwLWdldHRpbmctc3RhcnQtY29sLTItYWNjLWhkcntcclxuICAgIGNvbG9yOiB2YXIoLS1ibGFjay1jbHIpXHJcbn1cclxuLmwtaGxwLWdldHRpbmctc3RhcnQtY29sLTItYWNjLWljb257XHJcbiAgICBmbG9hdDpyaWdodDtcclxufVxyXG4ubC1obHAtZ2V0dGluZy1zdGFydC1kZXNje1xyXG4gICAgY29sb3IgOnZhcigtLWJsYWNrLWNscikgIWltcG9ydGFudDtcclxufVxyXG4ubC1obHAtZ2V0dGluZy1zdGFydC1wcm9kLXB1Yi1kYXRle1xyXG4gICAgY29sb3IgOnZhcigtLWJsYWNrLWNscikgIWltcG9ydGFudDtcclxufVxyXG4ubC1obHAtZ2V0dGluZy1zdGFydC1wcm9kLXVsIGxpe1xyXG4gICAgY29sb3IgOnZhcigtLWJsYWNrLWNscikgIWltcG9ydGFudDtcclxufVxyXG4ubC1obHAtZ2V0LXN0YXJ0ZWQtZ2xvcy1jb250e1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNERUUwRTY7XHJcbn1cclxuLmwtaGxwLWdldC1zdGFydGVkLWdsb3MtY29udDpsYXN0LWNoaWxke1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMHB4IWltcG9ydGFudDtcclxufVxyXG4ubC1obHAtY29udC1sYWJse1xyXG4gICAgY29sb3I6IzBFMkUxODtcclxufVxyXG4ubC1nZXQtc3RyZC1obHAtY29udC1mcm0gdGV4dGFyZWEge1xyXG4gICAgcmVzaXplOiBub25lO1xyXG59XHJcbi5sLWdldC1zdGFyLWNvbnQtY29sLTItdGV4dHtcclxuICAgIGNvbG9yOiAjNEY0RjRGO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICM0ZjRmNGY0MDtcclxufVxyXG4ubC1nZXQtc3RhcnQtY29udC1pY24tY29udHtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuLmwtZ2V0LXN0YXJ0LWNvbnQtY29sLTItdGV4dHtcclxuICAgIGNvbG9yIDp2YXIoLS1ibGFjay1jbHIpICFpbXBvcnRhbnQ7XHJcbiAgICBtYXJnaW4tdG9wOiAyM3B4O1xyXG59XHJcbi5sLWdldC1zdGFydC1jb250LWNvbC0yLWNvbnR7XHJcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgIzRmNGY0ZjQwO1xyXG59XHJcbi5sLWhscC1nZXR0aW5nLXN0YXJ0LWNudC1mcm0tbXNnLWNvbnR7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjMTg2QTM0O1xyXG59XHJcbi5sLWdldC1zdGFydC1jb250LXVzLWxpbmt7XHJcbiAgICBjb2xvciA6dmFyKC0tYmxhY2stY2xyKSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaGVscC1jb250ZW50LWFyZWF7XHJcbiAgICBtaW4taGVpZ2h0OiAxMDB2aDtcclxufVxyXG4ubC10YmxlLXJpZ2h0LWNoZXYtaWNvbntcclxuICAgIGZsb2F0OiByaWdodDtcclxuICAgIG1hcmdpbi10b3A6IDVweDtcclxufVxyXG4ubC1obHAtdGFicy10aXRsZXtcclxuICAgIGNvbG9yOiAjNEY0RjRGO1xyXG59XHJcbi5sLWhscC1nZXQtc3RyZC1saSBhLmFjdGl2ZXtcclxuICAgIGNvbG9yOiAjNEY0RjRGO1xyXG4gICAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG59XHJcbi5kd25sZF9zbXJ0X3Byb3tcclxuICAgIG1hcmdpbi10b3A6IDMwcHg7XHJcbn1cclxuLmR3bmxkX3NtcnRfcHJvIGF7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGJhY2tncm91bmQ6ICMyZDk4NTE7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBwYWRkaW5nOiAxNHB4IDE2cHg7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG59XHJcbi5kd25sZF9zbXJ0X3Byb19sYmx7XHJcbiAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICBsaW5lLWhlaWdodDogMTVweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG59XHJcbi5yZXNvdWNlc19pbWdfYnRuX3dyYXBwZXJ7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZ2FwOiA0MHB4O1xyXG4gICAgZmxleC13cmFwOiB3cmFwO1xyXG59XHJcbi5yZXNvdWNlc19pbWdfYnRuX2NvbnQgaW1ne1xyXG4gICAgbWF4LXdpZHRoOiAxNzdweDtcclxufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/help/help.component.ts":
/*!**********************************************!*\
  !*** ./src/app/pages/help/help.component.ts ***!
  \**********************************************/
/*! exports provided: HelpComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HelpComponent", function() { return HelpComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _help_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./help.service */ "./src/app/pages/help/help.service.ts");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngxs/store */ "./node_modules/@ngxs/store/fesm2015/ngxs-store.js");
/* harmony import */ var _state_loggedinuser_state__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../state/loggedinuser.state */ "./src/app/state/loggedinuser.state.ts");






let HelpComponent = class HelpComponent {
    constructor(fb, _hs) {
        this.fb = fb;
        this._hs = _hs;
        this.resources_tb_arr = [
            { id: "1", name: "Policies", a_tag: "#policies" },
            { id: "2", name: "Model Documents", a_tag: "#model-documents" },
        ];
        this.getting_started_tb_arr = [
            { id: "1", name: "City Innovation exchange", a_tag: "#gett-started-1" },
            { id: "2", name: "About Platform", a_tag: "#gett-started-2" },
        ];
        this.faq_tb_arr = [
            { id: "1", name: "About CiX", a_tag: "#abt-cix" },
            { id: "2", name: "Feature & Process - City Administrators", a_tag: "#city-admin" },
            { id: "3", name: "Feature & Process - Innovators", a_tag: "#innovator" },
            { id: "4", name: "Promotions", a_tag: "#promotion" },
            { id: "5", name: "Privacy", a_tag: "#privacy" },
            { id: "6", name: "Your account", a_tag: "#account" },
        ];
        this.glossary_tb_arr = [
            { id: "1", name: "Solution", a_tag: "#solution" },
            { id: "2", name: "Challenges", a_tag: "#challenges" },
            { id: "3", name: "City Administrator", a_tag: "#cityadmin" },
            { id: "4", name: "Innovator", a_tag: "#innovator_g" },
            { id: "5", name: "Anchor Process", a_tag: "#anchor" },
        ];
        this.faqs = [
            {
                section_name: "About CiX",
                section_id: "abt-cix",
                content: [
                    {
                        id: "col_1",
                        title: "What are the core objectives of CiX?",
                        desc_type: "ul_li",
                        status: false,
                        li_arr: [
                            { name: "In house support system for Cities to Run Multiple Challenges" },
                            { name: "Reducing market barriers for innovations" },
                            { name: "Transforming cities into Living Labs promoting sustainable growth" },
                            { name: "Institutionalising Open Innovation" },
                            { name: "Innovator-User Co-Creation in Cities involving the Quadruple Helix" },
                            { name: "Catalysing Innovation for Economic Growth, Improved Quality of Life, and Sustainability of cities" },
                        ],
                    },
                    {
                        id: "col_2",
                        title: "What are steps from Challenge to Procurement",
                        desc_type: "ul_li",
                        status: false,
                        li_arr: [
                            { name: "Challenge curation" },
                            { name: "Solution discovery" },
                            { name: "Innovation co-creation" },
                            { name: "Solution validation" },
                            { name: "Solution certification" },
                            { name: "Commercial procurement" },
                        ],
                    },
                ],
            },
            {
                section_name: "Feature & Process - City Administrators",
                section_id: "city-admin",
                content: [
                    {
                        id: "col_3",
                        title: "How do I create a Challenge?",
                        desc_type: "para",
                        status: false,
                        desc: "To create a challenge, the “Create Challenge” button from the discover page should be clicked. It will open to a “Challenge Brief” form where the challenge        details are to be provisioned. The challenge will be hosted on the platform once approved by the City Admin.",
                    },
                    {
                        id: "col_4",
                        title: " How do I select a solution after posting a Challenge?",
                        desc_type: "para",
                        status: false,
                        desc: " Solutions are assessed & scored with the help of the “CiX Solution Evaluation Rubric.” The assessment parameters include relevance, advantages, value/RoI, viability, and innovator capability. Solutions are selected based on the rank order of their scores.",
                    },
                ],
            },
            {
                section_name: "Feature & Process - Innovators",
                section_id: "innovator",
                content: [
                    {
                        id: "col_5",
                        title: "How do I create a Challenge?",
                        desc_type: "para",
                        status: false,
                        desc: "To create a challenge, the “Create Challenge” button from the discover page should be clicked. It will open to a “Challenge Brief” form where the challenge        details are to be provisioned. The challenge will be hosted on the platform once approved by the City Admin.",
                    },
                    {
                        id: "col_6",
                        title: " How do I select a solution after posting a Challenge?",
                        desc_type: "para",
                        status: false,
                        desc: " Solutions are assessed & scored with the help of the “CiX Solution Evaluation Rubric.” The assessment parameters include relevance, advantages, value/RoI, viability, and innovator capability. Solutions are selected based on the rank order of their scores.",
                    },
                ],
            },
            {
                section_name: "Promotions",
                section_id: "promotion",
                content: [
                    {
                        id: "col_7",
                        title: "Are there any promotions that we can do for my city/solutions?",
                        desc_type: "para",
                        status: false,
                        desc: "Platform currently does not have an option for promotions directly. Please contact the Program management team regarding this support.",
                    },
                    {
                        id: "col_8",
                        title: " Can I promote any specific challenge to invite more Solutions?",
                        desc_type: "para",
                        status: false,
                        desc: " Yes, promotions & outreach can be done for a specific challenge, beyond the platform, to invite more innovators to apply for the challenge through cities  social media handles and outreach activities.",
                    },
                ],
            },
            {
                section_name: "Privacy",
                section_id: "privacy",
                content: [
                    {
                        id: "col_9",
                        title: "I'm concerned about the data I'm giving to the platform. Is it secure?",
                        desc_type: "para",
                        status: false,
                        desc: "Your trust is our priority and we have implemented responsible and sophisticated, technical and physical controls that are designed to prevent unauthorized access to or disclosure of your content. To also safeguard innovators' privacy of the innovation IP, access to other solutions are restricted",
                    },
                    {
                        id: "col_10",
                        title: " Who all has access to the data I'm submitting to the platform?",
                        desc_type: "para",
                        status: false,
                        desc: "  If you are an innovator your solution is visible only to you and city administrators.",
                    },
                ],
            },
            {
                section_name: "Your account",
                section_id: "account",
                content: [
                    {
                        id: "col_11",
                        title: "Can I add/edit the details of my account?",
                        desc_type: "para",
                        status: false,
                        desc: " Yes, you can add and edit your account details in the profile section of the platform.",
                    },
                ],
            },
        ];
        this.contactForm = {};
        this.isSubmitted = false;
        this.show_msg = false;
        this.get_selectedItem = 1;
        this.faq_selectedItem = 1;
        this.loggedInUser$.subscribe((resp) => {
            this.loggedInUser = resp.LoggedInUser;
        });
    }
    ngOnInit() {
        this.contactForm = this.fb.group({
            fname: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern("[a-zA-Z .]*")]],
            lname: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern("[a-zA-Z .]*")]],
            email: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email]],
            phone: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern("(0|91)?[5-9][0-9]{9}")]],
            shortdesc: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern("[a-zA-Z .]*")]],
            longdesc: [""],
        });
    }
    get contactFormControl() {
        return this.contactForm.controls;
    }
    onSubmit() {
        if (this.contactForm.valid) {
            var post_data = {
                fname: this.contactForm.value.fname,
                lname: this.contactForm.value.lname,
                email: this.contactForm.value.email,
                phone: this.contactForm.value.phone,
                shortdesc: this.contactForm.value.shortdesc,
                longdesc: this.contactForm.value.longdesc,
            };
            // console.log(post_data);
            this._hs.submitContactFormAPI(post_data).subscribe((response) => {
                if (response.status == true) {
                    this.contactForm.reset();
                    this.show_msg = true;
                }
            });
        }
        else {
            this.isSubmitted = true;
        }
    }
    getstartedActionListner(event, itm, index) {
        this.get_selectedItem = itm.id;
    }
    faqActionListner(event, itm, index) {
        this.faq_selectedItem = itm.id;
    }
    glossaryActionListner(event, itm, index) {
        this.faq_selectedItem = itm.id;
    }
    showIcon(item) {
        // console.log(item);
        item.status = !item.status;
    }
};
HelpComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _help_service__WEBPACK_IMPORTED_MODULE_3__["HelpService"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngxs_store__WEBPACK_IMPORTED_MODULE_4__["Select"])(_state_loggedinuser_state__WEBPACK_IMPORTED_MODULE_5__["LoggedInUserState"])
], HelpComponent.prototype, "loggedInUser$", void 0);
HelpComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-help",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./help.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/help/help.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./help.component.css */ "./src/app/pages/help/help.component.css")).default]
    })
], HelpComponent);



/***/ }),

/***/ "./src/app/pages/help/help.service.ts":
/*!********************************************!*\
  !*** ./src/app/pages/help/help.service.ts ***!
  \********************************************/
/*! exports provided: HelpService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HelpService", function() { return HelpService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");




let HelpService = class HelpService {
    constructor(http) {
        this.http = http;
        this.api_url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].api_url;
    }
    submitContactFormAPI(post_data) {
        return this.http.post(this.api_url + '/users/submit_contact_form', post_data);
    }
};
HelpService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
HelpService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], HelpService);



/***/ }),

/***/ "./src/app/pages/home.service.ts":
/*!***************************************!*\
  !*** ./src/app/pages/home.service.ts ***!
  \***************************************/
/*! exports provided: HomeService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeService", function() { return HomeService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _services_helpers_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/helpers.service */ "./src/app/services/helpers.service.ts");





let HomeService = class HomeService {
    constructor(http, _hs) {
        this.http = http;
        this._hs = _hs;
        this.api_url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].api_url;
        this._hs.setAppLogo('assets/imglandingpage-hdr-logo.png');
    }
    getCitiesCount() {
        return this.http.post(this.api_url + '/smart_cities/count', null);
    }
    getSeekersCount() {
        return this.http.post(this.api_url + '/seekers/count', null);
    }
    getSolutionsCount() {
        return this.http.post(this.api_url + '/solutions/count', null);
    }
    getChallengeSector() {
        return this.http.post(this.api_url + '/challenge_sectors/count', null);
    }
    getchallengesCount() {
        return this.http.post(this.api_url + '/challenges/count', null);
    }
    getChallengeSectors() {
        return this.http.post(this.api_url + '/challenge_sectors/select_mul', null);
    }
    getProvidersCount() {
        return this.http.post(this.api_url + '/providers/count', null);
    }
};
HomeService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _services_helpers_service__WEBPACK_IMPORTED_MODULE_4__["HelpersService"] }
];
HomeService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], HomeService);



/***/ }),

/***/ "./src/app/pages/home/home.component.css":
/*!***********************************************!*\
  !*** ./src/app/pages/home/home.component.css ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".a-lp-navbar a {\r\n  color: black !important;\r\n  font-size: 14px;\r\n  font-weight: 500;\r\n  padding: 10px 20px;\r\n}\r\n.a-s1 {\r\n  background-image: url('landing-img1.jpg');\r\n  background-size: cover;\r\n  background-repeat: no-repeat;\r\n  background-position: center;\r\n}\r\n.a-lp-search {\r\n  max-width: 967px;\r\n  margin: 0 auto;\r\n}\r\n.a-lp-s3-wrapper1 {\r\n  max-width: 570px;\r\n  margin: 0 auto;\r\n}\r\n.a-lp-s3-wrapper2 {\r\n  padding-top: 70%;\r\n}\r\n.a-lp-s5-list > li {\r\n  display: inline-block;\r\n}\r\n.a-lp-s5-list > li button {\r\n  outline-style: none !important;\r\n  box-shadow: none !important;\r\n}\r\n.a-lp-s5-list > li button:hover,\r\n.a-lp-s5-list > li button:focus,\r\n.a-lp-s5-list > li button:active {\r\n  background-color: transparent !important;\r\n  color: #2641ad !important;\r\n  opacity: 1 !important;\r\n  font-weight: 700 !important;\r\n}\r\n.a-lp-s5-col2 {\r\n  padding-top: 75%;\r\n}\r\n.a-lp-s6 {\r\n  background: #eff6f2;\r\n}\r\n.a-lp-s6 .carousel-control {\r\n  background-image: none !important;\r\n  opacity: unset !important;\r\n}\r\n.a-lp-s6 .carousel-indicators .active {\r\n  width: 20px;\r\n  height: 20px;\r\n  margin: 1px 5px !important;\r\n  background-color: #1b7a43;\r\n}\r\n.a-lp-s6 .carousel-indicators li {\r\n  width: 20px;\r\n  height: 20px;\r\n  border: 1px solid #1b7a43;\r\n  margin: 1px 5px !important;\r\n  border-radius: 10px;\r\n}\r\n.a-lp-s6 .carousel-control .fa-chevron-left,\r\n.carousel-control .icon-prev {\r\n  left: 15% !important;\r\n  width: 30px;\r\n  height: 30px;\r\n  margin-top: -10px;\r\n  font-size: 30px;\r\n  position: absolute;\r\n  top: 50%;\r\n  z-index: 5;\r\n  display: inline-block;\r\n}\r\n.a-lp-s6 .carousel-control .fa-chevron-right,\r\n.carousel-control .icon-next {\r\n  right: 15% !important;\r\n  width: 30px;\r\n  height: 50px;\r\n  margin-top: -10px;\r\n  font-size: 30px;\r\n  position: absolute;\r\n  top: 50%;\r\n  z-index: 5;\r\n  display: inline-block;\r\n}\r\n.a-lp-s8 {\r\n  background-image: url('landingpage-s8-bg.png');\r\n  background-position: bottom;\r\n  background-repeat: no-repeat;\r\n}\r\n.a-lp-panel1 {\r\n  max-width: 1150px;\r\n  margin: 0 auto;\r\n}\r\n.a-lp-s9 {\r\n  border: 1px solid rgba(16, 27, 71, 0.15);\r\n}\r\n.a-lp-s9 ul > li {\r\n  display: inline-block;\r\n  list-style: none;\r\n}\r\n.a-lp-s9 ul li:not(:first-child):not(:last-child) {\r\n  margin-left: 50px;\r\n  margin-right: 50px;\r\n}\r\n.a-lp-footer {\r\n  background-color: #182751;\r\n}\r\n.a-lp-footer2 {\r\n  background-color: #0a142e;\r\n}\r\n.a-lp-ftr-list > li {\r\n  display: inline-block;\r\n}\r\n.a-lp-ftr-list > li:not(:first-child):not(:last-child) {\r\n  margin-left: 25px;\r\n  margin-right: 25px;\r\n}\r\n/* ::ng-deep .t-app-header,\r\n::ng-deep .t-app-footer{\r\n    display:none;\r\n} */\r\n.g-blue10-bg {\r\n  background: #2641ad;\r\n}\r\n.g-green2-bg {\r\n  background: #27ae60;\r\n}\r\n.hm-city-inx-logo img {\r\n  max-width: 650px;\r\n  margin:auto;\r\n}\r\n.t-hm-s1-cnt {\r\n  max-width: 400px;\r\n  margin: auto;\r\n}\r\n.t-hm-search-bx {\r\n  max-width:630px;\r\n  margin: auto;\r\n}\r\n.t-hm-search-bx input {\r\n  outline: none !important;\r\n  border:2px solid #2641ad !important;\r\n}\r\n.t-hm-search-bx .input-group-addon {\r\n  border-color: #2641ad;\r\n}\r\n\r\n\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG9tZS9ob21lLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx1QkFBdUI7RUFDdkIsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixrQkFBa0I7QUFDcEI7QUFDQTtFQUNFLHlDQUE2RDtFQUM3RCxzQkFBc0I7RUFDdEIsNEJBQTRCO0VBQzVCLDJCQUEyQjtBQUM3QjtBQUNBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGNBQWM7QUFDaEI7QUFDQTtFQUNFLGdCQUFnQjtFQUNoQixjQUFjO0FBQ2hCO0FBQ0E7RUFDRSxnQkFBZ0I7QUFDbEI7QUFDQTtFQUNFLHFCQUFxQjtBQUN2QjtBQUNBO0VBQ0UsOEJBQThCO0VBQzlCLDJCQUEyQjtBQUM3QjtBQUNBOzs7RUFHRSx3Q0FBd0M7RUFDeEMseUJBQXlCO0VBQ3pCLHFCQUFxQjtFQUNyQiwyQkFBMkI7QUFDN0I7QUFDQTtFQUNFLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxpQ0FBaUM7RUFDakMseUJBQXlCO0FBQzNCO0FBQ0E7RUFDRSxXQUFXO0VBQ1gsWUFBWTtFQUNaLDBCQUEwQjtFQUMxQix5QkFBeUI7QUFDM0I7QUFDQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1oseUJBQXlCO0VBQ3pCLDBCQUEwQjtFQUMxQixtQkFBbUI7QUFDckI7QUFDQTs7RUFFRSxvQkFBb0I7RUFDcEIsV0FBVztFQUNYLFlBQVk7RUFDWixpQkFBaUI7RUFDakIsZUFBZTtFQUNmLGtCQUFrQjtFQUNsQixRQUFRO0VBQ1IsVUFBVTtFQUNWLHFCQUFxQjtBQUN2QjtBQUNBOztFQUVFLHFCQUFxQjtFQUNyQixXQUFXO0VBQ1gsWUFBWTtFQUNaLGlCQUFpQjtFQUNqQixlQUFlO0VBQ2Ysa0JBQWtCO0VBQ2xCLFFBQVE7RUFDUixVQUFVO0VBQ1YscUJBQXFCO0FBQ3ZCO0FBQ0E7RUFDRSw4Q0FBa0U7RUFDbEUsMkJBQTJCO0VBQzNCLDRCQUE0QjtBQUM5QjtBQUNBO0VBQ0UsaUJBQWlCO0VBQ2pCLGNBQWM7QUFDaEI7QUFDQTtFQUNFLHdDQUF3QztBQUMxQztBQUNBO0VBQ0UscUJBQXFCO0VBQ3JCLGdCQUFnQjtBQUNsQjtBQUNBO0VBQ0UsaUJBQWlCO0VBQ2pCLGtCQUFrQjtBQUNwQjtBQUNBO0VBQ0UseUJBQXlCO0FBQzNCO0FBQ0E7RUFDRSx5QkFBeUI7QUFDM0I7QUFDQTtFQUNFLHFCQUFxQjtBQUN2QjtBQUNBO0VBQ0UsaUJBQWlCO0VBQ2pCLGtCQUFrQjtBQUNwQjtBQUVBOzs7R0FHRztBQUVIO0VBQ0UsbUJBQW1CO0FBQ3JCO0FBRUE7RUFDRSxtQkFBbUI7QUFDckI7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixXQUFXO0FBQ2I7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixZQUFZO0FBQ2Q7QUFFQTtFQUNFLGVBQWU7RUFDZixZQUFZO0FBQ2Q7QUFFQTtFQUNFLHdCQUF3QjtFQUN4QixtQ0FBbUM7QUFDckM7QUFFQTtFQUNFLHFCQUFxQjtBQUN2QiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2hvbWUvaG9tZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmEtbHAtbmF2YmFyIGEge1xyXG4gIGNvbG9yOiBibGFjayAhaW1wb3J0YW50O1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIHBhZGRpbmc6IDEwcHggMjBweDtcclxufVxyXG4uYS1zMSB7XHJcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi4vLi4vLi4vYXNzZXRzL2ltZy9sYW5kaW5nLWltZzEuanBnXCIpO1xyXG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XHJcbn1cclxuLmEtbHAtc2VhcmNoIHtcclxuICBtYXgtd2lkdGg6IDk2N3B4O1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG59XHJcbi5hLWxwLXMzLXdyYXBwZXIxIHtcclxuICBtYXgtd2lkdGg6IDU3MHB4O1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG59XHJcbi5hLWxwLXMzLXdyYXBwZXIyIHtcclxuICBwYWRkaW5nLXRvcDogNzAlO1xyXG59XHJcbi5hLWxwLXM1LWxpc3QgPiBsaSB7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG59XHJcbi5hLWxwLXM1LWxpc3QgPiBsaSBidXR0b24ge1xyXG4gIG91dGxpbmUtc3R5bGU6IG5vbmUgIWltcG9ydGFudDtcclxuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuLmEtbHAtczUtbGlzdCA+IGxpIGJ1dHRvbjpob3ZlcixcclxuLmEtbHAtczUtbGlzdCA+IGxpIGJ1dHRvbjpmb2N1cyxcclxuLmEtbHAtczUtbGlzdCA+IGxpIGJ1dHRvbjphY3RpdmUge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbiAgY29sb3I6ICMyNjQxYWQgIWltcG9ydGFudDtcclxuICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XHJcbiAgZm9udC13ZWlnaHQ6IDcwMCAhaW1wb3J0YW50O1xyXG59XHJcbi5hLWxwLXM1LWNvbDIge1xyXG4gIHBhZGRpbmctdG9wOiA3NSU7XHJcbn1cclxuLmEtbHAtczYge1xyXG4gIGJhY2tncm91bmQ6ICNlZmY2ZjI7XHJcbn1cclxuLmEtbHAtczYgLmNhcm91c2VsLWNvbnRyb2wge1xyXG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vbmUgIWltcG9ydGFudDtcclxuICBvcGFjaXR5OiB1bnNldCAhaW1wb3J0YW50O1xyXG59XHJcbi5hLWxwLXM2IC5jYXJvdXNlbC1pbmRpY2F0b3JzIC5hY3RpdmUge1xyXG4gIHdpZHRoOiAyMHB4O1xyXG4gIGhlaWdodDogMjBweDtcclxuICBtYXJnaW46IDFweCA1cHggIWltcG9ydGFudDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMWI3YTQzO1xyXG59XHJcbi5hLWxwLXM2IC5jYXJvdXNlbC1pbmRpY2F0b3JzIGxpIHtcclxuICB3aWR0aDogMjBweDtcclxuICBoZWlnaHQ6IDIwcHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgIzFiN2E0MztcclxuICBtYXJnaW46IDFweCA1cHggIWltcG9ydGFudDtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG59XHJcbi5hLWxwLXM2IC5jYXJvdXNlbC1jb250cm9sIC5mYS1jaGV2cm9uLWxlZnQsXHJcbi5jYXJvdXNlbC1jb250cm9sIC5pY29uLXByZXYge1xyXG4gIGxlZnQ6IDE1JSAhaW1wb3J0YW50O1xyXG4gIHdpZHRoOiAzMHB4O1xyXG4gIGhlaWdodDogMzBweDtcclxuICBtYXJnaW4tdG9wOiAtMTBweDtcclxuICBmb250LXNpemU6IDMwcHg7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogNTAlO1xyXG4gIHotaW5kZXg6IDU7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG59XHJcbi5hLWxwLXM2IC5jYXJvdXNlbC1jb250cm9sIC5mYS1jaGV2cm9uLXJpZ2h0LFxyXG4uY2Fyb3VzZWwtY29udHJvbCAuaWNvbi1uZXh0IHtcclxuICByaWdodDogMTUlICFpbXBvcnRhbnQ7XHJcbiAgd2lkdGg6IDMwcHg7XHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG4gIG1hcmdpbi10b3A6IC0xMHB4O1xyXG4gIGZvbnQtc2l6ZTogMzBweDtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiA1MCU7XHJcbiAgei1pbmRleDogNTtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbn1cclxuLmEtbHAtczgge1xyXG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi4uLy4uLy4uL2Fzc2V0cy9pbWcvbGFuZGluZ3BhZ2UtczgtYmcucG5nXCIpO1xyXG4gIGJhY2tncm91bmQtcG9zaXRpb246IGJvdHRvbTtcclxuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG59XHJcbi5hLWxwLXBhbmVsMSB7XHJcbiAgbWF4LXdpZHRoOiAxMTUwcHg7XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcbn1cclxuLmEtbHAtczkge1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoMTYsIDI3LCA3MSwgMC4xNSk7XHJcbn1cclxuLmEtbHAtczkgdWwgPiBsaSB7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIGxpc3Qtc3R5bGU6IG5vbmU7XHJcbn1cclxuLmEtbHAtczkgdWwgbGk6bm90KDpmaXJzdC1jaGlsZCk6bm90KDpsYXN0LWNoaWxkKSB7XHJcbiAgbWFyZ2luLWxlZnQ6IDUwcHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1MHB4O1xyXG59XHJcbi5hLWxwLWZvb3RlciB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzE4Mjc1MTtcclxufVxyXG4uYS1scC1mb290ZXIyIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMGExNDJlO1xyXG59XHJcbi5hLWxwLWZ0ci1saXN0ID4gbGkge1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxufVxyXG4uYS1scC1mdHItbGlzdCA+IGxpOm5vdCg6Zmlyc3QtY2hpbGQpOm5vdCg6bGFzdC1jaGlsZCkge1xyXG4gIG1hcmdpbi1sZWZ0OiAyNXB4O1xyXG4gIG1hcmdpbi1yaWdodDogMjVweDtcclxufVxyXG5cclxuLyogOjpuZy1kZWVwIC50LWFwcC1oZWFkZXIsXHJcbjo6bmctZGVlcCAudC1hcHAtZm9vdGVye1xyXG4gICAgZGlzcGxheTpub25lO1xyXG59ICovXHJcblxyXG4uZy1ibHVlMTAtYmcge1xyXG4gIGJhY2tncm91bmQ6ICMyNjQxYWQ7XHJcbn1cclxuXHJcbi5nLWdyZWVuMi1iZyB7XHJcbiAgYmFja2dyb3VuZDogIzI3YWU2MDtcclxufVxyXG5cclxuLmhtLWNpdHktaW54LWxvZ28gaW1nIHtcclxuICBtYXgtd2lkdGg6IDY1MHB4O1xyXG4gIG1hcmdpbjphdXRvO1xyXG59XHJcblxyXG4udC1obS1zMS1jbnQge1xyXG4gIG1heC13aWR0aDogNDAwcHg7XHJcbiAgbWFyZ2luOiBhdXRvO1xyXG59XHJcblxyXG4udC1obS1zZWFyY2gtYngge1xyXG4gIG1heC13aWR0aDo2MzBweDtcclxuICBtYXJnaW46IGF1dG87XHJcbn1cclxuXHJcbi50LWhtLXNlYXJjaC1ieCBpbnB1dCB7XHJcbiAgb3V0bGluZTogbm9uZSAhaW1wb3J0YW50O1xyXG4gIGJvcmRlcjoycHggc29saWQgIzI2NDFhZCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udC1obS1zZWFyY2gtYnggLmlucHV0LWdyb3VwLWFkZG9uIHtcclxuICBib3JkZXItY29sb3I6ICMyNjQxYWQ7XHJcbn1cclxuXHJcblxyXG4iXX0= */");

/***/ }),

/***/ "./src/app/pages/home/home.component.ts":
/*!**********************************************!*\
  !*** ./src/app/pages/home/home.component.ts ***!
  \**********************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_helpers_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/helpers.service */ "./src/app/services/helpers.service.ts");
/* harmony import */ var _home_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../home.service */ "./src/app/pages/home.service.ts");




let HomeComponent = class HomeComponent {
    constructor(_hs, _hlps) {
        this._hs = _hs;
        this._hlps = _hlps;
        this.challengeSectors = [];
        this.smarcity = {
            city: 100,
            seekers: 100,
            solutions: 112,
            challenge_sectors: 10,
            challenges: 60,
        };
        this.search_data = {
            name: "Maharashtra",
            desc: "State with the highest GDP in India",
            solutions: 80,
            challenges: 95,
            seekers: 42,
            providers: 35,
            pilots: 0,
            challenge_sectors: 10,
        };
        this.banner_images = [
            { url: 'assets/img/home/frg_hmpg_5.jpg' },
            { url: 'assets/img/home/frg_hmpg_3.jpg' },
            { url: 'assets/img/home/frg_hmpg_1.jpg' }
        ];
        this.challenge_sectors = [
            {
                image_url: "assets/img/landingpage-s6-icon2.png",
                name: "Energy Management",
                desc: "Smart Energy Management is an integral part of urban transformation. The goal is to achieve sustainable and low-carbon urban development through renewable energy and digital governance.",
                solutions: 22,
                challenges: 18,
                pilots: 0,
                certified_solutons: 0,
            },
            {
                image_url: "assets/img/landingpage-s6-icon3.png",
                name: "Safety & Security",
                desc: "The quality of safety and security system in a city directly impacts the quality of life of the citizens. The goal is to enhance the safety and security of the city through intelligent and digital systems.",
                solutions: 22,
                challenges: 18,
                pilots: 0,
                certified_solutons: 0,
            },
            {
                image_url: "assets/img/landingpage-s6-icon4.png",
                name: "Healthcare",
                desc: "Cities constantly endeavour to improve the quality of life and the quality of healthcare services provided strongly influence the quality of life. The focus here would be on providing better healthcare services to the citizens through technology & innovation.",
                solutions: 22,
                challenges: 18,
                pilots: 0,
                certified_solutons: 0,
            },
            {
                image_url: "assets/img/landingpage-s6-icon5.png",
                name: "Urban Infra and Buildings",
                desc: "Urban infrastructure is one of the crucial elements that contribute to a city’s development. This sector focuses on enhancing the city’s existing infrastructure, both digital and physical infrastructure, through intelligent systems and technologies.",
                solutions: 22,
                challenges: 18,
                pilots: 0,
                certified_solutons: 0,
            },
            {
                image_url: "assets/img/landingpage-s6-icon6.png",
                name: "Governance",
                desc: "Smart Governance involves using technology to support planning and decision making in the city’s administration. It also involves the use of Digital Technologies in delivering various public services.",
                solutions: 22,
                challenges: 18,
                pilots: 0,
                certified_solutons: 0,
            },
            {
                image_url: "assets/img/landingpage-s6-icon7.png",
                name: "Education",
                desc: "Education is a fundamental driver of human development, from improving incomes to deepening democracy. The focus would be on providing support & resources to institutions, skill development, access to learning materials for citizens, etc.",
                solutions: 22,
                challenges: 18,
                pilots: 0,
                certified_solutons: 0,
            },
            {
                image_url: "assets/img/landingpage-s6-icon8.png",
                name: "Mobility Infrastructure",
                desc: "Rapid urbanisation puts a strain on the mobility infrastructure such as traffic congestion, pollution, poor road safety, and parking. This sector aims to make an efficient urban mobility infrastructure through smart technologies and better infrastructure planning.",
                solutions: 22,
                challenges: 18,
                pilots: 0,
                certified_solutons: 0,
            },
            {
                image_url: "assets/img/landingpage-s6-icon9.png",
                name: "Environment Management",
                desc: "Environmental Management is a critical factor that determines the sustainability of any city and also contributes to the quality of life in that city. This sector focuses on bringing innovative solutions to preserve the environment thus making the city sustainable.",
                solutions: 22,
                challenges: 18,
                pilots: 0,
                certified_solutons: 0,
            },
            {
                image_url: "assets/img/landingpage-s6-icon10.png",
                name: "Water Management",
                desc: "Efficient water management is a basic necessity of any city, and it involves planning, developing, distributing and managing the optimum use of water resources. The objective of this sector to efficiently manage the water resources of the entire city.",
                solutions: 22,
                challenges: 18,
                pilots: 0,
                certified_solutons: 0,
            },
            {
                image_url: "assets/img/landingpage-s6-icon11.png",
                name: "Waste Management",
                desc: "Waste management is an essential city service and is crucial to a city’s development due to rapid urbanization and growing population. The objective is to effectively manage the entire process from segregation, collection, distribution, to recycling.",
                solutions: 22,
                challenges: 18,
                pilots: 0,
                certified_solutons: 0,
            },
        ];
        this._hlps
            .setAppLogo(`<a class="" href="http://mohua.gov.in/" target="_blank" >
    <img class="app-logo" src="assets/img/landingpage-hdr-logo.png" alt="Logo" />
  </a>`);
    }
    ngOnInit() {
        this.getAllCount();
        this.getChallengeSectors();
    }
    ngOnDestroy() {
        // switch logo
        this._hlps.setAppLogo(`<a class="" href="/" >
    <img class="app-logo" src="assets/img/cix-logo.png" alt="Logo" />
  </a>`);
    }
    getAllCount() {
        // CitiesCount
        this._hs.getCitiesCount().subscribe((resp) => {
            this.citiesCount = resp.data;
        });
        // Seekers
        this._hs.getSeekersCount().subscribe((resp) => {
            this.seekersCount = resp.data;
        });
        // Solutions
        this._hs.getSolutionsCount().subscribe((resp) => {
            this.solutionsCount = resp.data;
        });
        // ChallengeSectors
        this._hs.getChallengeSector().subscribe((resp) => {
            this.challengeSectorCount = resp.data;
        });
        // Challenges
        this._hs.getchallengesCount().subscribe((resp) => {
            this.challengesCount = resp.data;
        });
        // Innovators (Provider)
        this._hs.getProvidersCount().subscribe((resp) => {
            this.innovatorsCount = resp.data;
        });
    }
    getChallengeSectors() {
        this._hs.getChallengeSectors().subscribe((resp) => {
            resp.data.forEach((el) => {
                let challengesCount = el.challenges.length;
                let solutionsCount = el.solutions.length;
                this.challenge_sectors.forEach((element) => {
                    if (element.name.toLowerCase() == el.name.toLowerCase()) {
                        element.solutions = solutionsCount;
                        element.challenges = challengesCount;
                    }
                });
                // this.challengeSectors.push(
                //   el['name'] = {
                //     name: el.name,
                //     challengesCount: challengesCount,
                //     solutionsCount: solutionsCount
                //   }
                // )
            });
        });
    }
};
HomeComponent.ctorParameters = () => [
    { type: _home_service__WEBPACK_IMPORTED_MODULE_3__["HomeService"] },
    { type: _services_helpers_service__WEBPACK_IMPORTED_MODULE_2__["HelpersService"] }
];
HomeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-home",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./home.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.component.html")).default,
        encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewEncapsulation"].None,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./home.component.css */ "./src/app/pages/home/home.component.css")).default]
    })
], HomeComponent);



/***/ }),

/***/ "./src/app/route-cache.ts":
/*!********************************!*\
  !*** ./src/app/route-cache.ts ***!
  \********************************/
/*! exports provided: RouteCache */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RouteCache", function() { return RouteCache; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

class RouteCache {
    constructor() {
        this.storedRoutes = new Map();
    }
    flushRouteCache() {
        this.storedRoutes.forEach((handle) => this.destroyComponent(handle));
        this.storedRoutes.clear();
        // console.log('cache cleared');
    }
    // Decides if the route should be stored
    shouldDetach(route) {
        return route.data.reuseRoute === true;
    }
    //Store the information for the route we're destructing
    store(route, handle) {
        this.storedRoutes.set(route.routeConfig.path, handle);
    }
    //Return true if we have a stored route object for the next route
    shouldAttach(route) {
        return this.storedRoutes.has(route.routeConfig.path);
    }
    //If we returned true in shouldAttach(), now return the actual route data for restoration
    retrieve(route) {
        return this.storedRoutes.get(route.routeConfig.path);
    }
    //Reuse the route if we're going to and from the same route
    shouldReuseRoute(future, curr) {
        return future.routeConfig === curr.routeConfig;
    }
    destroyComponent(handle) {
        const componentRef = handle['componentRef'];
        if (componentRef) {
            componentRef.destroy();
        }
    }
}


/***/ }),

/***/ "./src/app/services/appinit.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/appinit.service.ts ***!
  \*********************************************/
/*! exports provided: AppinitService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppinitService", function() { return AppinitService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jwt-decode */ "./node_modules/jwt-decode/build/jwt-decode.esm.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngxs/store */ "./node_modules/@ngxs/store/fesm2015/ngxs-store.js");
/* harmony import */ var _state_action_loggedinuser_action__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../state/action/loggedinuser.action */ "./src/app/state/action/loggedinuser.action.ts");







let AppinitService = class AppinitService {
    constructor(http, store) {
        this.http = http;
        this.store = store;
        this.api_url = _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].api_url;
        this.server_url = _environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].server_url;
    }
    runAtAppStartUp() {
        return new Promise((resolve, reject) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.refreshToken = localStorage.getItem("refresh_token") || null;
            if (this.refreshToken) {
                try {
                    let currentUserDecoded = Object(jwt_decode__WEBPACK_IMPORTED_MODULE_3__["default"])(this.refreshToken);
                    const response = yield this.http.post(this.api_url + "/users/select", { slug: { id: currentUserDecoded.id } }).toPromise();
                    if (response.status) {
                        if (response.data.role_seeker) {
                            // setting the loggedin user state(seeker)
                            this.store.dispatch(new _state_action_loggedinuser_action__WEBPACK_IMPORTED_MODULE_6__["SetLoggedInUser"]({
                                id: response.data.id,
                                email: response.data.email,
                                name: response.data.seeker[0].fullname,
                                userType: "seeker",
                                userTypeId: response.data.seeker[0].id,
                                avatar: `${this.server_url}` + response.data.seeker[0].avatar,
                                slug: response.data.seeker[0].slug,
                                isLoggedIn: true,
                            }));
                        }
                        else if (response.data.role_provider) {
                            // setting the loggedin user state(innovator)
                            this.store.dispatch(new _state_action_loggedinuser_action__WEBPACK_IMPORTED_MODULE_6__["SetLoggedInUser"]({
                                id: response.data.id,
                                email: response.data.email,
                                name: response.data.provider[0].fullname,
                                userType: "provider",
                                userTypeId: response.data.provider[0].id,
                                avatar: `${this.server_url}` + response.data.provider[0].avatar,
                                slug: response.data.provider[0].slug,
                                isLoggedIn: true,
                            }));
                        }
                    }
                }
                catch (err) {
                    localStorage.clear();
                    console.log(err);
                }
            }
            resolve();
        }));
    }
};
AppinitService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: _ngxs_store__WEBPACK_IMPORTED_MODULE_5__["Store"] }
];
AppinitService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: "root",
    })
], AppinitService);



/***/ }),

/***/ "./src/app/services/auth.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngxs/store */ "./node_modules/@ngxs/store/fesm2015/ngxs-store.js");
/* harmony import */ var _state_action_loggedinuser_action__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../state/action/loggedinuser.action */ "./src/app/state/action/loggedinuser.action.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");








let AuthService = class AuthService {
    constructor(http, _store, router) {
        this.http = http;
        this._store = _store;
        this.router = router;
        this.api_url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].api_url;
    }
    login(credentials) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            return yield this.http
                .post(`${this.api_url}/auth/login`, {
                data: {
                    email: credentials.email,
                    password: credentials.password,
                },
            })
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])((tokens) => {
                this.storeTokens(tokens);
            }))
                .toPromise();
        });
    }
    refreshToken() {
        const currentToken = localStorage.getItem("refresh_token") || null;
        return this.http
            .post(`${this.api_url}/auth/refresh_token`, {
            refresh_token: currentToken,
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])((tokens) => {
            this.storeTokens(tokens);
        }));
    }
    storeTokens(tokens) {
        localStorage.setItem("access_token", tokens.access_token);
        localStorage.setItem("refresh_token", tokens.refresh_token);
    }
    logout() {
        localStorage.removeItem("access_token");
        localStorage.removeItem("refresh_token");
        this._store.dispatch(new _state_action_loggedinuser_action__WEBPACK_IMPORTED_MODULE_6__["ClearLoggedInUserSession"]());
        this.router.navigateByUrl("/login").then(() => {
            window.location.reload();
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ngxs_store__WEBPACK_IMPORTED_MODULE_5__["Store"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] }
];
AuthService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: "root",
    })
], AuthService);



/***/ }),

/***/ "./src/app/services/customvalidation.service.ts":
/*!******************************************************!*\
  !*** ./src/app/services/customvalidation.service.ts ***!
  \******************************************************/
/*! exports provided: CustomvalidationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomvalidationService", function() { return CustomvalidationService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngxs/store */ "./node_modules/@ngxs/store/fesm2015/ngxs-store.js");
/* harmony import */ var _state_loggedinuser_state__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../state/loggedinuser.state */ "./src/app/state/loggedinuser.state.ts");






let CustomvalidationService = class CustomvalidationService {
    constructor(http) {
        this.http = http;
        this.api_url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].api_url;
        this.loggedInUser$.subscribe((resp) => {
            this.loggedInUser = resp.LoggedInUser;
        });
    }
    MatchPassword(password, confirmPassword) {
        return (formGroup) => {
            const passwordControl = formGroup.controls[password];
            const confirmPasswordControl = formGroup.controls[confirmPassword];
            if (!passwordControl || !confirmPasswordControl) {
                return null;
            }
            if (confirmPasswordControl.errors && !confirmPasswordControl.errors.passwordMismatch) {
                return null;
            }
            if (passwordControl.value !== confirmPasswordControl.value) {
                confirmPasswordControl.setErrors({ passwordMismatch: true });
            }
            else {
                confirmPasswordControl.setErrors(null);
            }
        };
    }
    comparePassword(old_password, password) {
        return (formGroup) => {
            const oldPasswordControl = formGroup.controls[old_password];
            const passwordControl = formGroup.controls[password];
            if (!oldPasswordControl || !passwordControl) {
                return null;
            }
            if (oldPasswordControl.errors && !passwordControl.errors.passwordSame) {
                return null;
            }
            if (oldPasswordControl.value == passwordControl.value) {
                passwordControl.setErrors({ passwordSame: true });
            }
            else {
                passwordControl.setErrors(null);
            }
        };
    }
    emailAvailabilityValidator(userControl) {
        return new Promise((resolve) => {
            const post_data = { filter: { email: userControl.value } };
            const currentUserID = this.loggedInUser.id;
            this.http.post(this.api_url + "/users/select_mul", post_data).subscribe((response) => {
                let isCurrentUserEmail = response.data.some((user) => {
                    if (currentUserID == user.id) {
                        return true;
                    }
                });
                setTimeout(() => {
                    if (response.status === true && response.data.length > 0) {
                        isCurrentUserEmail ? resolve(null) : resolve({ emailAlreadyExist: true });
                    }
                    else {
                        resolve(null);
                    }
                }, 200);
            });
        });
    }
    phoneAvailabilityValidator(userControl) {
        return new Promise((resolve) => {
            const post_data = { filter: { mobile: userControl.value } };
            const currentUserID = this.loggedInUser.id;
            this.http.post(this.api_url + "/users/select_mul", post_data).subscribe((response) => {
                let isCurrentUserphonenum = response.data.some((user) => {
                    if (currentUserID == user.id) {
                        return true;
                    }
                });
                setTimeout(() => {
                    if (response.status === true && response.data.length > 0) {
                        isCurrentUserphonenum ? resolve(null) : resolve({ phonenumAlreadyExist: true });
                    }
                    else {
                        resolve(null);
                    }
                }, 200);
            });
        });
    }
    checkRegisteredEmail(userControl) {
        return new Promise((resolve) => {
            const postData = { filter: { email: userControl.value } };
            this.http.post(this.api_url + "/users/select_mul", postData).subscribe((response) => {
                setTimeout(() => {
                    if (response.status === true && response.data.length > 0) {
                        resolve(null);
                    }
                    else {
                        resolve({ emailNotRegistered: true });
                    }
                }, 200);
            });
        });
    }
    checkForDuplicateChallenges(userControl) {
        return new Promise((resolve) => {
            const postData = { filter: { name: userControl.value.trim() } };
            this.http.post(this.api_url + "/challenges/select_mul", postData).subscribe((response) => {
                if (response.status === false && response.data.length <= 0) {
                    resolve(null);
                }
                else {
                    resolve({ challengeAlreadyExist: true });
                }
            });
        });
    }
    validateDate(startDate, closeDate) {
        return (formGroup) => {
            const closeControl = formGroup.controls[closeDate];
            const startControl = formGroup.controls[startDate];
            console.log(closeControl, startControl);
            if (new Date(closeControl.value) <= new Date(startControl.value)) {
                closeControl.setErrors({ dateError: true });
            }
            else {
                closeControl.setErrors(null);
            }
        };
    }
};
CustomvalidationService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngxs_store__WEBPACK_IMPORTED_MODULE_4__["Select"])(_state_loggedinuser_state__WEBPACK_IMPORTED_MODULE_5__["LoggedInUserState"])
], CustomvalidationService.prototype, "loggedInUser$", void 0);
CustomvalidationService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: "root",
    })
], CustomvalidationService);



/***/ }),

/***/ "./src/app/services/firestore.service.ts":
/*!***********************************************!*\
  !*** ./src/app/services/firestore.service.ts ***!
  \***********************************************/
/*! exports provided: FirestoreService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FirestoreService", function() { return FirestoreService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ "./node_modules/@angular/fire/firestore/es2015/index.js");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngxs/store */ "./node_modules/@ngxs/store/fesm2015/ngxs-store.js");
/* harmony import */ var _state_loggedinuser_state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../state/loggedinuser.state */ "./src/app/state/loggedinuser.state.ts");





let FirestoreService = class FirestoreService {
    constructor(firestore) {
        this.firestore = firestore;
        this.loggedInUser$.subscribe((resp) => {
            this.loggedUserData = resp.LoggedInUser;
            console.log("this.loggedUserData", this.loggedUserData);
        });
    }
    getNotifications() {
        return this.firestore.collection("notifications", (ref) => ref.where("userId", "==", this.loggedUserData.id).where("read", "==", false).orderBy("createdAt", "desc")).valueChanges();
    }
    updateReadStatus(notificationId) {
        let notification = this.firestore.collection("notifications", (ref) => ref.where("id", "==", notificationId));
        notification.snapshotChanges().subscribe((res) => {
            let id = res[0].payload.doc.id;
            this.firestore.collection("notifications").doc(id).update({ read: true });
            console.log("updated");
        });
    }
    updateReadStatusAll() {
        let notification = this.firestore.collection("notifications", (ref) => ref.where("userId", "==", this.loggedUserData.id));
        notification.snapshotChanges().subscribe((res) => {
            res.forEach(e => {
                let id = e.payload.doc.id;
                // console.log("updateall Id", id);
                this.firestore.collection("notifications").doc(id).update({ read: true });
            });
            console.log("All notifications Updated");
        });
    }
    getAllNotifications() {
        return this.firestore.collection("notifications", (ref) => ref.where("userId", "==", this.loggedUserData.id).orderBy("createdAt", "desc")).valueChanges();
    }
};
FirestoreService.ctorParameters = () => [
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngxs_store__WEBPACK_IMPORTED_MODULE_3__["Select"])(_state_loggedinuser_state__WEBPACK_IMPORTED_MODULE_4__["LoggedInUserState"])
], FirestoreService.prototype, "loggedInUser$", void 0);
FirestoreService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: "root",
    })
], FirestoreService);



/***/ }),

/***/ "./src/app/services/helpers.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/helpers.service.ts ***!
  \*********************************************/
/*! exports provided: HelpersService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HelpersService", function() { return HelpersService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var fuzzysort__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! fuzzysort */ "./node_modules/fuzzysort/fuzzysort.js");
/* harmony import */ var fuzzysort__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(fuzzysort__WEBPACK_IMPORTED_MODULE_3__);




let HelpersService = class HelpersService {
    constructor() {
        this.logoSrc$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](`<a class="" href="/" >
    <img class="app-logo" src="assets/img/cix-logo.png" alt="Logo" />
  </a>`);
    }
    sortBestMatches(search, targets) {
        const results = fuzzysort__WEBPACK_IMPORTED_MODULE_3__["go"](search, targets);
        // console.log(results);
        return results;
    }
    getAppLogo() {
        return this.logoSrc$.asObservable();
    }
    setAppLogo(path) {
        this.logoSrc$.next(path);
    }
};
HelpersService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: "root",
    })
], HelpersService);



/***/ }),

/***/ "./src/app/shared/widgets/add-achievement-innovator/achievement-item/achievement-item.component.css":
/*!**********************************************************************************************************!*\
  !*** ./src/app/shared/widgets/add-achievement-innovator/achievement-item/achievement-item.component.css ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".achievementitem-card {\r\n\tposition: relative;\r\n\tpadding: 14px 36px 14px 18px;\r\n\tborder-radius: 4px;\r\n\tborder: 1px solid #dedede;\r\n\tmargin-bottom: 15px;\r\n}\r\n\r\n.achievementitem-card .title {\r\n\tfont-size: 12px;\r\n\tfont-weight: 500;\r\n\tcolor: var(--body-grey);\r\n}\r\n\r\n.achievementitem-card .monthyear {\r\n\tfont-size: 10px;\r\n\tcolor: var(--lable-grey);\r\n}\r\n\r\n.achievementitem-card .description {\r\n\tfont-size: 10px;\r\n\tline-height: 12px;\r\n\tcolor: var(--lable-grey);\r\n}\r\n\r\n.achievementitem-card .menu {\r\n\tposition: absolute;\r\n\ttop: 8px;\r\n\tright: 8px;\r\n}\r\n\r\n.achievementitem-card .menu button {\r\n\tborder: 2px solid #dedede !important;\r\n\tborder-radius: 15px;\r\n\tbackground: var(--white);\r\n\tpadding: 2px 5px;\r\n\tfont-size: 14px;\r\n}\r\n\r\n.achievementitem-card .menu .dropdown-menu {\r\n\tright: 0 !important;\r\n\tleft: unset !important;\r\n\tborder: none !important;\r\n\tbox-shadow: 0px 2.38049px 11.9024px rgba(0, 0, 0, 0.1) !important;\r\n}\r\n\r\n.dropdown-menu span {\r\n\tdisplay: block;\r\n\tpadding: 8px 10px;\r\n\tfont-size: 10px;\r\n\tline-height: 10px;\r\n\t-webkit-transition: all 0.3s;\r\n\ttransition: all 0.3s;\r\n\tcursor: pointer;\r\n}\r\n\r\n.dropdown-menu span:hover {\r\n\tbackground-color: #f5f5f5;\r\n}\r\n\r\n.edit-achievements-modal .modal-dialog {\r\n\twidth: 100%;\r\n\tmax-width: 580px;\r\n}\r\n\r\n.edit-achievements-modal .modal-content {\r\n\tbox-shadow: none !important;\r\n}\r\n\r\n.edit-achievements-modal .modal-body {\r\n\tpadding: 18px 36px;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3dpZGdldHMvYWRkLWFjaGlldmVtZW50LWlubm92YXRvci9hY2hpZXZlbWVudC1pdGVtL2FjaGlldmVtZW50LWl0ZW0uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtDQUNDLGtCQUFrQjtDQUNsQiw0QkFBNEI7Q0FDNUIsa0JBQWtCO0NBQ2xCLHlCQUF5QjtDQUN6QixtQkFBbUI7QUFDcEI7O0FBRUE7Q0FDQyxlQUFlO0NBQ2YsZ0JBQWdCO0NBQ2hCLHVCQUF1QjtBQUN4Qjs7QUFFQTtDQUNDLGVBQWU7Q0FDZix3QkFBd0I7QUFDekI7O0FBRUE7Q0FDQyxlQUFlO0NBQ2YsaUJBQWlCO0NBQ2pCLHdCQUF3QjtBQUN6Qjs7QUFFQTtDQUNDLGtCQUFrQjtDQUNsQixRQUFRO0NBQ1IsVUFBVTtBQUNYOztBQUVBO0NBQ0Msb0NBQW9DO0NBQ3BDLG1CQUFtQjtDQUNuQix3QkFBd0I7Q0FDeEIsZ0JBQWdCO0NBQ2hCLGVBQWU7QUFDaEI7O0FBRUE7Q0FDQyxtQkFBbUI7Q0FDbkIsc0JBQXNCO0NBQ3RCLHVCQUF1QjtDQUN2QixpRUFBaUU7QUFDbEU7O0FBRUE7Q0FDQyxjQUFjO0NBQ2QsaUJBQWlCO0NBQ2pCLGVBQWU7Q0FDZixpQkFBaUI7Q0FDakIsNEJBQW9CO0NBQXBCLG9CQUFvQjtDQUNwQixlQUFlO0FBQ2hCOztBQUVBO0NBQ0MseUJBQXlCO0FBQzFCOztBQUVBO0NBQ0MsV0FBVztDQUNYLGdCQUFnQjtBQUNqQjs7QUFFQTtDQUNDLDJCQUEyQjtBQUM1Qjs7QUFFQTtDQUNDLGtCQUFrQjtBQUNuQiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC93aWRnZXRzL2FkZC1hY2hpZXZlbWVudC1pbm5vdmF0b3IvYWNoaWV2ZW1lbnQtaXRlbS9hY2hpZXZlbWVudC1pdGVtLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYWNoaWV2ZW1lbnRpdGVtLWNhcmQge1xyXG5cdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRwYWRkaW5nOiAxNHB4IDM2cHggMTRweCAxOHB4O1xyXG5cdGJvcmRlci1yYWRpdXM6IDRweDtcclxuXHRib3JkZXI6IDFweCBzb2xpZCAjZGVkZWRlO1xyXG5cdG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbn1cclxuXHJcbi5hY2hpZXZlbWVudGl0ZW0tY2FyZCAudGl0bGUge1xyXG5cdGZvbnQtc2l6ZTogMTJweDtcclxuXHRmb250LXdlaWdodDogNTAwO1xyXG5cdGNvbG9yOiB2YXIoLS1ib2R5LWdyZXkpO1xyXG59XHJcblxyXG4uYWNoaWV2ZW1lbnRpdGVtLWNhcmQgLm1vbnRoeWVhciB7XHJcblx0Zm9udC1zaXplOiAxMHB4O1xyXG5cdGNvbG9yOiB2YXIoLS1sYWJsZS1ncmV5KTtcclxufVxyXG5cclxuLmFjaGlldmVtZW50aXRlbS1jYXJkIC5kZXNjcmlwdGlvbiB7XHJcblx0Zm9udC1zaXplOiAxMHB4O1xyXG5cdGxpbmUtaGVpZ2h0OiAxMnB4O1xyXG5cdGNvbG9yOiB2YXIoLS1sYWJsZS1ncmV5KTtcclxufVxyXG5cclxuLmFjaGlldmVtZW50aXRlbS1jYXJkIC5tZW51IHtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0dG9wOiA4cHg7XHJcblx0cmlnaHQ6IDhweDtcclxufVxyXG5cclxuLmFjaGlldmVtZW50aXRlbS1jYXJkIC5tZW51IGJ1dHRvbiB7XHJcblx0Ym9yZGVyOiAycHggc29saWQgI2RlZGVkZSAhaW1wb3J0YW50O1xyXG5cdGJvcmRlci1yYWRpdXM6IDE1cHg7XHJcblx0YmFja2dyb3VuZDogdmFyKC0td2hpdGUpO1xyXG5cdHBhZGRpbmc6IDJweCA1cHg7XHJcblx0Zm9udC1zaXplOiAxNHB4O1xyXG59XHJcblxyXG4uYWNoaWV2ZW1lbnRpdGVtLWNhcmQgLm1lbnUgLmRyb3Bkb3duLW1lbnUge1xyXG5cdHJpZ2h0OiAwICFpbXBvcnRhbnQ7XHJcblx0bGVmdDogdW5zZXQgIWltcG9ydGFudDtcclxuXHRib3JkZXI6IG5vbmUgIWltcG9ydGFudDtcclxuXHRib3gtc2hhZG93OiAwcHggMi4zODA0OXB4IDExLjkwMjRweCByZ2JhKDAsIDAsIDAsIDAuMSkgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmRyb3Bkb3duLW1lbnUgc3BhbiB7XHJcblx0ZGlzcGxheTogYmxvY2s7XHJcblx0cGFkZGluZzogOHB4IDEwcHg7XHJcblx0Zm9udC1zaXplOiAxMHB4O1xyXG5cdGxpbmUtaGVpZ2h0OiAxMHB4O1xyXG5cdHRyYW5zaXRpb246IGFsbCAwLjNzO1xyXG5cdGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmRyb3Bkb3duLW1lbnUgc3Bhbjpob3ZlciB7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcclxufVxyXG5cclxuLmVkaXQtYWNoaWV2ZW1lbnRzLW1vZGFsIC5tb2RhbC1kaWFsb2cge1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdG1heC13aWR0aDogNTgwcHg7XHJcbn1cclxuXHJcbi5lZGl0LWFjaGlldmVtZW50cy1tb2RhbCAubW9kYWwtY29udGVudCB7XHJcblx0Ym94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZWRpdC1hY2hpZXZlbWVudHMtbW9kYWwgLm1vZGFsLWJvZHkge1xyXG5cdHBhZGRpbmc6IDE4cHggMzZweDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "./src/app/shared/widgets/add-achievement-innovator/achievement-item/achievement-item.component.ts":
/*!*********************************************************************************************************!*\
  !*** ./src/app/shared/widgets/add-achievement-innovator/achievement-item/achievement-item.component.ts ***!
  \*********************************************************************************************************/
/*! exports provided: AchievementItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AchievementItemComponent", function() { return AchievementItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm2015/ngx-toastr.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_5__);






let AchievementItemComponent = class AchievementItemComponent {
    constructor(toastr, router, fb) {
        this.toastr = toastr;
        this.router = router;
        this.fb = fb;
        this.onDelete = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onEdit = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.yearArr = lodash__WEBPACK_IMPORTED_MODULE_5__["range"](1950, new Date().getFullYear() + 1);
        this.monthArr = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        this.achievementsArr = [];
        this.yearSelected = false;
        this.monthDropdown = [];
    }
    ngOnInit() {
        this.editAchievementsForm = this.fb.group({
            month: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]],
            year: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]],
            title: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(45), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(80)]],
        });
        this.patchEditForm();
        this.yearSelected = true;
        if (this.editAchievementsForm.controls.year.value) {
            this.monthDropdown = this.monthArr;
        }
    }
    get editAchievementFormContorl() {
        return this.editAchievementsForm.controls;
    }
    patchEditForm() {
        this.editAchievementsForm.patchValue({
            month: this.achievementData.month,
            year: this.achievementData.year,
            title: this.achievementData.title,
            description: this.achievementData.description,
        });
    }
    handleYearSelect() {
        let currentYear = new Date().getFullYear();
        let currentMonth = new Date().getMonth();
        if (this.editAchievementsForm.controls.year.value) {
            if (this.editAchievementsForm.controls.year.value < currentYear) {
                this.monthDropdown = this.monthArr;
            }
            else {
                this.editAchievementsForm.controls['month'].setValue('');
                this.monthDropdown = this.monthArr.slice(0, currentMonth + 1);
            }
            this.yearSelected = true;
        }
        else {
            this.yearSelected = false;
            this.editAchievementsForm.controls['month'].setValue('');
        }
    }
    editAchievement() {
        this.isSubmitted = true;
        if (this.editAchievementsForm.valid) {
            this.isSubmitted = false;
            this.onEdit.emit({
                data: this.editAchievementsForm.value,
                index: this.id,
            });
            document.getElementById(`editachievements${this.id}`).click();
        }
        else {
            // console.log("add achivement item");
            this.toastr.error("Please provide the required values to proceed further", "Validation Error");
        }
    }
    emitDeleteIndex() {
        this.onDelete.emit(this.id);
    }
};
AchievementItemComponent.ctorParameters = () => [
    { type: ngx_toastr__WEBPACK_IMPORTED_MODULE_4__["ToastrService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], AchievementItemComponent.prototype, "id", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], AchievementItemComponent.prototype, "achievementData", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
], AchievementItemComponent.prototype, "onDelete", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
], AchievementItemComponent.prototype, "onEdit", void 0);
AchievementItemComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-achievement-item",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./achievement-item.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/add-achievement-innovator/achievement-item/achievement-item.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./achievement-item.component.css */ "./src/app/shared/widgets/add-achievement-innovator/achievement-item/achievement-item.component.css")).default]
    })
], AchievementItemComponent);



/***/ }),

/***/ "./src/app/shared/widgets/add-achievement-innovator/add-achievement-innovator.component.css":
/*!**************************************************************************************************!*\
  !*** ./src/app/shared/widgets/add-achievement-innovator/add-achievement-innovator.component.css ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".add-achievements.btn {\r\n\tmargin-bottom: 10px;\r\n\tbackground-color: var(--white);\r\n\tcolor: var(--primary-green);\r\n\tborder: 1px solid #dedede !important;\r\n\twidth: 100%;\r\n\tfont-size: 14px;\r\n\tpadding: 8px 10px;\r\n\tfont-weight: 500;\r\n}\r\n\r\n.add-achievements-modal .modal-dialog {\r\n\twidth: 100%;\r\n\tmax-width: 580px;\r\n}\r\n\r\n.add-achievements-modal .modal-content {\r\n\tbox-shadow: none !important;\r\n}\r\n\r\n.add-achievements-modal .modal-body {\r\n\tpadding: 18px 36px;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3dpZGdldHMvYWRkLWFjaGlldmVtZW50LWlubm92YXRvci9hZGQtYWNoaWV2ZW1lbnQtaW5ub3ZhdG9yLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Q0FDQyxtQkFBbUI7Q0FDbkIsOEJBQThCO0NBQzlCLDJCQUEyQjtDQUMzQixvQ0FBb0M7Q0FDcEMsV0FBVztDQUNYLGVBQWU7Q0FDZixpQkFBaUI7Q0FDakIsZ0JBQWdCO0FBQ2pCOztBQUVBO0NBQ0MsV0FBVztDQUNYLGdCQUFnQjtBQUNqQjs7QUFFQTtDQUNDLDJCQUEyQjtBQUM1Qjs7QUFFQTtDQUNDLGtCQUFrQjtBQUNuQiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC93aWRnZXRzL2FkZC1hY2hpZXZlbWVudC1pbm5vdmF0b3IvYWRkLWFjaGlldmVtZW50LWlubm92YXRvci5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmFkZC1hY2hpZXZlbWVudHMuYnRuIHtcclxuXHRtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG5cdGJhY2tncm91bmQtY29sb3I6IHZhcigtLXdoaXRlKTtcclxuXHRjb2xvcjogdmFyKC0tcHJpbWFyeS1ncmVlbik7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgI2RlZGVkZSAhaW1wb3J0YW50O1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGZvbnQtc2l6ZTogMTRweDtcclxuXHRwYWRkaW5nOiA4cHggMTBweDtcclxuXHRmb250LXdlaWdodDogNTAwO1xyXG59XHJcblxyXG4uYWRkLWFjaGlldmVtZW50cy1tb2RhbCAubW9kYWwtZGlhbG9nIHtcclxuXHR3aWR0aDogMTAwJTtcclxuXHRtYXgtd2lkdGg6IDU4MHB4O1xyXG59XHJcblxyXG4uYWRkLWFjaGlldmVtZW50cy1tb2RhbCAubW9kYWwtY29udGVudCB7XHJcblx0Ym94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYWRkLWFjaGlldmVtZW50cy1tb2RhbCAubW9kYWwtYm9keSB7XHJcblx0cGFkZGluZzogMThweCAzNnB4O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "./src/app/shared/widgets/add-achievement-innovator/add-achievement-innovator.component.ts":
/*!*************************************************************************************************!*\
  !*** ./src/app/shared/widgets/add-achievement-innovator/add-achievement-innovator.component.ts ***!
  \*************************************************************************************************/
/*! exports provided: AddAchievementInnovatorComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddAchievementInnovatorComponent", function() { return AddAchievementInnovatorComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm2015/ngx-toastr.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_5__);






let AddAchievementInnovatorComponent = class AddAchievementInnovatorComponent {
    constructor(toastr, router, fb) {
        this.toastr = toastr;
        this.router = router;
        this.fb = fb;
        this.onAchievementChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.yearArr = lodash__WEBPACK_IMPORTED_MODULE_5__["range"](1950, new Date().getFullYear() + 1);
        this.monthDropdown = [];
        this.monthArr = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        this.achievementsArr = [];
        this.yearSelected = false;
    }
    ngOnInit() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.addAchievementsForm = this.fb.group({
                month: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]],
                year: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]],
                title: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(45), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(80)]],
            });
            if (this.achievements) {
                this.achievementsArr = this.achievements;
                // console.log(this.achievementsArr);
                this.onAchievementChange.emit(this.achievementsArr);
            }
        });
    }
    get addAchievementFormContorl() {
        return this.addAchievementsForm.controls;
    }
    createAchievement() {
        this.isSubmitted = true;
        if (this.addAchievementsForm.valid) {
            this.achievementsArr.push(this.addAchievementsForm.value);
            this.onAchievementChange.emit(this.achievementsArr);
            this.isSubmitted = false;
            this.addAchievementsForm.reset();
            document.getElementById("addachievements").click();
        }
        else {
            // console.log("add achivement");
            this.toastr.error("Please provide the required values to proceed further", "Validation Error");
        }
    }
    handleYearSelect() {
        let currentYear = new Date().getFullYear();
        let currentMonth = new Date().getMonth();
        if (this.addAchievementsForm.controls.year.value) {
            if (this.addAchievementsForm.controls.year.value < currentYear) {
                this.monthDropdown = this.monthArr;
            }
            else {
                this.addAchievementsForm.controls['month'].setValue('');
                this.monthDropdown = this.monthArr.slice(0, currentMonth + 1);
            }
            this.yearSelected = true;
        }
        else {
            this.yearSelected = false;
            this.addAchievementsForm.controls['month'].setValue('');
        }
    }
    handleEditAchievement(editData) {
        let editIndex = editData.index;
        let editArr = this.achievementsArr;
        if (~editIndex) {
            editArr[editIndex] = editData.data;
            this.achievementsArr = editArr;
            this.onAchievementChange.emit(this.achievementsArr);
        }
    }
    handleDeleteAchievement(deleteIndex) {
        if (~deleteIndex) {
            this.achievementsArr.splice(deleteIndex, 1);
            this.onAchievementChange.emit(this.achievementsArr);
        }
    }
};
AddAchievementInnovatorComponent.ctorParameters = () => [
    { type: ngx_toastr__WEBPACK_IMPORTED_MODULE_4__["ToastrService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], AddAchievementInnovatorComponent.prototype, "achievements", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
], AddAchievementInnovatorComponent.prototype, "onAchievementChange", void 0);
AddAchievementInnovatorComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "add-achievement",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./add-achievement-innovator.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/add-achievement-innovator/add-achievement-innovator.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./add-achievement-innovator.component.css */ "./src/app/shared/widgets/add-achievement-innovator/add-achievement-innovator.component.css")).default]
    })
], AddAchievementInnovatorComponent);



/***/ }),

/***/ "./src/app/shared/widgets/avatar-upload/avatar-upload.component.css":
/*!**************************************************************************!*\
  !*** ./src/app/shared/widgets/avatar-upload/avatar-upload.component.css ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".avatar-upload .avatar-upload-mdl-tgr {\r\n    position: absolute;\r\n    right: 8%;\r\n    bottom: 1%;\r\n    z-index: 10;\r\n  }\r\n\r\n  .avatar-upload {\r\n    position: relative;\r\n    border-radius: 50%;\r\n    max-width: 140px;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3dpZGdldHMvYXZhdGFyLXVwbG9hZC9hdmF0YXItdXBsb2FkLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxrQkFBa0I7SUFDbEIsU0FBUztJQUNULFVBQVU7SUFDVixXQUFXO0VBQ2I7O0VBRUE7SUFDRSxrQkFBa0I7SUFDbEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtBQUNwQiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC93aWRnZXRzL2F2YXRhci11cGxvYWQvYXZhdGFyLXVwbG9hZC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmF2YXRhci11cGxvYWQgLmF2YXRhci11cGxvYWQtbWRsLXRnciB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICByaWdodDogOCU7XHJcbiAgICBib3R0b206IDElO1xyXG4gICAgei1pbmRleDogMTA7XHJcbiAgfVxyXG5cclxuICAuYXZhdGFyLXVwbG9hZCB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBtYXgtd2lkdGg6IDE0MHB4O1xyXG59Il19 */");

/***/ }),

/***/ "./src/app/shared/widgets/avatar-upload/avatar-upload.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/shared/widgets/avatar-upload/avatar-upload.component.ts ***!
  \*************************************************************************/
/*! exports provided: AvatarUploadComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AvatarUploadComponent", function() { return AvatarUploadComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var ngx_image_cropper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ngx-image-cropper */ "./node_modules/ngx-image-cropper/fesm2015/ngx-image-cropper.js");



let AvatarUploadComponent = class AvatarUploadComponent {
    constructor() {
        this.onSaveImage = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.defaultImg = "./assets/img/default-avatar.jpg";
        this.avatarFileChangedEvent = "";
        this.croppedAvatar = "";
    }
    ngOnInit() {
        if (typeof this.Src === "undefined") {
            this.Src = this.defaultImg;
        }
    }
    avatarChangeEvent(event) {
        this.avatarFileChangedEvent = event;
    }
    avatarImageCropped(event) {
        this.croppedAvatar = event.base64;
    }
    avatarImageLoaded(image) {
        this.avatarRawFileLoaded = true;
        // show cropper
    }
    avatarCropperReady() {
        // cropper ready
    }
    avatarLoadImageFailed(err) {
        console.log(err, "failed image");
        // show message
    }
    saveEditedImage() {
        const fileBeforeCrop = this.avatarFileChangedEvent.target.files[0];
        // setting preview    
        this.Src = this.croppedAvatar;
        // converting base64 to BLOB
        const fileBLOB = new File([Object(ngx_image_cropper__WEBPACK_IMPORTED_MODULE_2__["base64ToFile"])(this.croppedAvatar)], fileBeforeCrop.name, {
            type: fileBeforeCrop.type,
        });
        this.onSaveImage.emit(fileBLOB);
        document.getElementById("imageModal").click();
    }
    removeImage(fileInput) {
        fileInput.value = '';
        this.croppedAvatar = "";
        this.Src = this.defaultImg;
        this.onSaveImage.emit(null);
        this.avatarFileChangedEvent = "";
        this.avatarRawFileLoaded = false;
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], AvatarUploadComponent.prototype, "avatar", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], AvatarUploadComponent.prototype, "Src", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
], AvatarUploadComponent.prototype, "onSaveImage", void 0);
AvatarUploadComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "Avatar-Upload",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./avatar-upload.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/avatar-upload/avatar-upload.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./avatar-upload.component.css */ "./src/app/shared/widgets/avatar-upload/avatar-upload.component.css")).default]
    })
], AvatarUploadComponent);



/***/ }),

/***/ "./src/app/shared/widgets/collapsable-content/collapsable-content.component.css":
/*!**************************************************************************************!*\
  !*** ./src/app/shared/widgets/collapsable-content/collapsable-content.component.css ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".content {\r\n\t-webkit-transition: all 0.3s;\r\n\ttransition: all 0.3s;\r\n\tcolor: var(--body-grey);\r\n\tword-break: break-word;\r\n}\r\n\r\n.content p {\r\n\tmargin: 0;\r\n}\r\n\r\n.content {\r\n\tposition: relative;\r\n}\r\n\r\n.content.collapsed {\r\n\toverflow: hidden;\r\n}\r\n\r\n.content.collapsed::after {\r\n\tcontent: \"\";\r\n\tposition: absolute;\r\n\ttop: 0;\r\n\tleft: 0;\r\n\twidth: 100%;\r\n\theight: 100%;\r\n\tbackground: rgb(255, 255, 255);\r\n\tbackground: -webkit-gradient(linear, left top, left bottom, from(rgba(255, 255, 255, 0)), color-stop(55%, rgba(255, 255, 255, 0.7147233893557423)), color-stop(88%, rgba(255, 255, 255, 1)));\r\n\tbackground: linear-gradient(180deg, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.7147233893557423) 55%, rgba(255, 255, 255, 1) 88%);\r\n}\r\n\r\n.content .read-btn-wrp a {\r\n\tfont-weight: 400;\r\n\tcolor: var(--body-grey);\r\n\tcursor: pointer;\r\n\tfont-size: 14px;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3dpZGdldHMvY29sbGFwc2FibGUtY29udGVudC9jb2xsYXBzYWJsZS1jb250ZW50LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Q0FDQyw0QkFBb0I7Q0FBcEIsb0JBQW9CO0NBQ3BCLHVCQUF1QjtDQUN2QixzQkFBc0I7QUFDdkI7O0FBRUE7Q0FDQyxTQUFTO0FBQ1Y7O0FBRUE7Q0FDQyxrQkFBa0I7QUFDbkI7O0FBRUE7Q0FDQyxnQkFBZ0I7QUFDakI7O0FBRUE7Q0FDQyxXQUFXO0NBQ1gsa0JBQWtCO0NBQ2xCLE1BQU07Q0FDTixPQUFPO0NBQ1AsV0FBVztDQUNYLFlBQVk7Q0FDWiw4QkFBOEI7Q0FDOUIsNExBQXVJO0NBQXZJLHVJQUF1STtBQUN4STs7QUFFQTtDQUNDLGdCQUFnQjtDQUNoQix1QkFBdUI7Q0FDdkIsZUFBZTtDQUNmLGVBQWU7QUFDaEIiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvd2lkZ2V0cy9jb2xsYXBzYWJsZS1jb250ZW50L2NvbGxhcHNhYmxlLWNvbnRlbnQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250ZW50IHtcclxuXHR0cmFuc2l0aW9uOiBhbGwgMC4zcztcclxuXHRjb2xvcjogdmFyKC0tYm9keS1ncmV5KTtcclxuXHR3b3JkLWJyZWFrOiBicmVhay13b3JkO1xyXG59XHJcblxyXG4uY29udGVudCBwIHtcclxuXHRtYXJnaW46IDA7XHJcbn1cclxuXHJcbi5jb250ZW50IHtcclxuXHRwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi5jb250ZW50LmNvbGxhcHNlZCB7XHJcblx0b3ZlcmZsb3c6IGhpZGRlbjtcclxufVxyXG5cclxuLmNvbnRlbnQuY29sbGFwc2VkOjphZnRlciB7XHJcblx0Y29udGVudDogXCJcIjtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0dG9wOiAwO1xyXG5cdGxlZnQ6IDA7XHJcblx0d2lkdGg6IDEwMCU7XHJcblx0aGVpZ2h0OiAxMDAlO1xyXG5cdGJhY2tncm91bmQ6IHJnYigyNTUsIDI1NSwgMjU1KTtcclxuXHRiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTgwZGVnLCByZ2JhKDI1NSwgMjU1LCAyNTUsIDApIDAlLCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNzE0NzIzMzg5MzU1NzQyMykgNTUlLCByZ2JhKDI1NSwgMjU1LCAyNTUsIDEpIDg4JSk7XHJcbn1cclxuXHJcbi5jb250ZW50IC5yZWFkLWJ0bi13cnAgYSB7XHJcblx0Zm9udC13ZWlnaHQ6IDQwMDtcclxuXHRjb2xvcjogdmFyKC0tYm9keS1ncmV5KTtcclxuXHRjdXJzb3I6IHBvaW50ZXI7XHJcblx0Zm9udC1zaXplOiAxNHB4O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "./src/app/shared/widgets/collapsable-content/collapsable-content.component.ts":
/*!*************************************************************************************!*\
  !*** ./src/app/shared/widgets/collapsable-content/collapsable-content.component.ts ***!
  \*************************************************************************************/
/*! exports provided: CollapsableContentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CollapsableContentComponent", function() { return CollapsableContentComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let CollapsableContentComponent = class CollapsableContentComponent {
    constructor(elementRef, cdRef) {
        this.elementRef = elementRef;
        this.cdRef = cdRef;
        //maximum height of the container
        this.maxHeight = 70;
        //set these to false to get the height of the expended container
        this.isCollapsed = false;
        this.isCollapsable = false;
    }
    ngOnInit() { }
    ngAfterViewInit() {
        let currentHeight = this.elementRef.nativeElement.getElementsByTagName("div")[0].offsetHeight;
        //collapsable only if the contents make container exceed the max height
        if (currentHeight > this.maxHeight) {
            this.isCollapsed = true;
            this.isCollapsable = true;
            this.cdRef.detectChanges();
        }
    }
};
CollapsableContentComponent.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], CollapsableContentComponent.prototype, "text", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], CollapsableContentComponent.prototype, "maxHeight", void 0);
CollapsableContentComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "collapse-content",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./collapsable-content.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/collapsable-content/collapsable-content.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./collapsable-content.component.css */ "./src/app/shared/widgets/collapsable-content/collapsable-content.component.css")).default]
    })
], CollapsableContentComponent);



/***/ }),

/***/ "./src/app/shared/widgets/companylogo-upload/companylogo-upload.component.css":
/*!************************************************************************************!*\
  !*** ./src/app/shared/widgets/companylogo-upload/companylogo-upload.component.css ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".uploader-wrp {\r\n    margin-top: 4px;\r\n    border: 1px solid #dedede;\r\n    border-radius: 4px;\r\n    overflow: hidden;\r\n    padding: 12px;\r\n  }\r\n  \r\n  .uploader-wrp.error{\r\n    border-color: #f8483d;\r\n  }\r\n  \r\n  .add-image {\r\n    display: -webkit-box;\r\n    display: flex;\r\n    -webkit-box-pack: center;\r\n            justify-content: center;\r\n    -webkit-box-align: center;\r\n            align-items: center;\r\n    height: 125px;\r\n  }\r\n  \r\n  .add-image i {\r\n    cursor: pointer;\r\n    color: var(--primary-green);\r\n  }\r\n  \r\n  .preview-image {\r\n    position: relative;\r\n    text-align: center;\r\n  }\r\n  \r\n  .preview-image img {\r\n    height: 125px;\r\n    -o-object-fit: cover;\r\n       object-fit: cover;\r\n  }\r\n  \r\n  .preview-image .remove-img {\r\n    padding: 6px 7px;\r\n    background-color: var(--white);\r\n    display: -webkit-box;\r\n    display: flex;\r\n    -webkit-box-align: center;\r\n            align-items: center;\r\n    position: absolute;\r\n    top: -10px;\r\n    right: -10px;\r\n    font-size: 12px;\r\n    border-radius: 16px;\r\n    color: #f8483d;\r\n    cursor: pointer;\r\n    visibility: hidden;\r\n    opacity: 0;\r\n    z-index: 10;\r\n    -webkit-transition: all 0.3s;\r\n    transition: all 0.3s;\r\n    border: 1px solid #dedede;\r\n    box-shadow: 0px 4px 25px rgba(172, 177, 193, 0.4);\r\n  }\r\n  \r\n  .preview-image:hover .remove-img {\r\n    visibility: visible;\r\n    opacity: 1;\r\n  }\r\n  \r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3dpZGdldHMvY29tcGFueWxvZ28tdXBsb2FkL2NvbXBhbnlsb2dvLXVwbG9hZC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZUFBZTtJQUNmLHlCQUF5QjtJQUN6QixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLGFBQWE7RUFDZjs7RUFFQTtJQUNFLHFCQUFxQjtFQUN2Qjs7RUFFQTtJQUNFLG9CQUFhO0lBQWIsYUFBYTtJQUNiLHdCQUF1QjtZQUF2Qix1QkFBdUI7SUFDdkIseUJBQW1CO1lBQW5CLG1CQUFtQjtJQUNuQixhQUFhO0VBQ2Y7O0VBRUE7SUFDRSxlQUFlO0lBQ2YsMkJBQTJCO0VBQzdCOztFQUVBO0lBQ0Usa0JBQWtCO0lBQ2xCLGtCQUFrQjtFQUNwQjs7RUFFQTtJQUNFLGFBQWE7SUFDYixvQkFBaUI7T0FBakIsaUJBQWlCO0VBQ25COztFQUVBO0lBQ0UsZ0JBQWdCO0lBQ2hCLDhCQUE4QjtJQUM5QixvQkFBYTtJQUFiLGFBQWE7SUFDYix5QkFBbUI7WUFBbkIsbUJBQW1CO0lBQ25CLGtCQUFrQjtJQUNsQixVQUFVO0lBQ1YsWUFBWTtJQUNaLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsY0FBYztJQUNkLGVBQWU7SUFDZixrQkFBa0I7SUFDbEIsVUFBVTtJQUNWLFdBQVc7SUFDWCw0QkFBb0I7SUFBcEIsb0JBQW9CO0lBQ3BCLHlCQUF5QjtJQUN6QixpREFBaUQ7RUFDbkQ7O0VBRUE7SUFDRSxtQkFBbUI7SUFDbkIsVUFBVTtFQUNaIiwiZmlsZSI6InNyYy9hcHAvc2hhcmVkL3dpZGdldHMvY29tcGFueWxvZ28tdXBsb2FkL2NvbXBhbnlsb2dvLXVwbG9hZC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnVwbG9hZGVyLXdycCB7XHJcbiAgICBtYXJnaW4tdG9wOiA0cHg7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZGVkZWRlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgIHBhZGRpbmc6IDEycHg7XHJcbiAgfVxyXG4gIFxyXG4gIC51cGxvYWRlci13cnAuZXJyb3J7XHJcbiAgICBib3JkZXItY29sb3I6ICNmODQ4M2Q7XHJcbiAgfVxyXG5cclxuICAuYWRkLWltYWdlIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBoZWlnaHQ6IDEyNXB4O1xyXG4gIH1cclxuICBcclxuICAuYWRkLWltYWdlIGkge1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgY29sb3I6IHZhcigtLXByaW1hcnktZ3JlZW4pO1xyXG4gIH1cclxuICBcclxuICAucHJldmlldy1pbWFnZSB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgfVxyXG4gIFxyXG4gIC5wcmV2aWV3LWltYWdlIGltZyB7XHJcbiAgICBoZWlnaHQ6IDEyNXB4O1xyXG4gICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgfVxyXG4gIFxyXG4gIC5wcmV2aWV3LWltYWdlIC5yZW1vdmUtaW1nIHtcclxuICAgIHBhZGRpbmc6IDZweCA3cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS13aGl0ZSk7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogLTEwcHg7XHJcbiAgICByaWdodDogLTEwcHg7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxNnB4O1xyXG4gICAgY29sb3I6ICNmODQ4M2Q7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICB2aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgICBvcGFjaXR5OiAwO1xyXG4gICAgei1pbmRleDogMTA7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4zcztcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNkZWRlZGU7XHJcbiAgICBib3gtc2hhZG93OiAwcHggNHB4IDI1cHggcmdiYSgxNzIsIDE3NywgMTkzLCAwLjQpO1xyXG4gIH1cclxuICBcclxuICAucHJldmlldy1pbWFnZTpob3ZlciAucmVtb3ZlLWltZyB7XHJcbiAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xyXG4gICAgb3BhY2l0eTogMTtcclxuICB9XHJcbiAgIl19 */");

/***/ }),

/***/ "./src/app/shared/widgets/companylogo-upload/companylogo-upload.component.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/shared/widgets/companylogo-upload/companylogo-upload.component.ts ***!
  \***********************************************************************************/
/*! exports provided: CompanylogoUploadComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompanylogoUploadComponent", function() { return CompanylogoUploadComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var ngx_image_cropper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ngx-image-cropper */ "./node_modules/ngx-image-cropper/fesm2015/ngx-image-cropper.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");




let CompanylogoUploadComponent = class CompanylogoUploadComponent {
    constructor() {
        // logo
        this.logoChangedEvent = "";
        this.croppedLogo = "";
        this.logoLoaded = false;
        this.logoSaved = false;
        this.error = false;
        this.onSaveLogo = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onRemoveLogo = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.serverUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].server_url;
    }
    ngOnInit() {
        if (this.logo) {
            this.Src = this.serverUrl + this.logo;
        }
    }
    logoChangeEvent(event) {
        this.logoChangedEvent = event;
    }
    logoCropped(event) {
        this.croppedLogo = event.base64;
    }
    logoLoadedEvent() {
        this.logoLoaded = true;
    }
    removeImage() {
        if (isBase64(this.Src)) {
            const fileBeforeCrop = this.logoChangedEvent.target.files[0];
            this.onRemoveLogo.emit(new File([Object(ngx_image_cropper__WEBPACK_IMPORTED_MODULE_2__["base64ToFile"])(this.croppedLogo)], fileBeforeCrop.name, {
                type: fileBeforeCrop.type,
            }));
        }
        else {
            this.onRemoveLogo.emit(this.Src);
        }
        this.Src = null;
        this.croppedLogo = "";
        this.logoChangedEvent = null;
        this.logoLoaded = false;
    }
    saveCropedLogo() {
        const fileBeforeCrop = this.logoChangedEvent.target.files[0];
        this.Src = this.croppedLogo;
        this.onSaveLogo.emit(new File([Object(ngx_image_cropper__WEBPACK_IMPORTED_MODULE_2__["base64ToFile"])(this.croppedLogo)], fileBeforeCrop.name, {
            type: fileBeforeCrop.type,
        }));
        this.logoSaved = true;
        document.getElementById("logoModal").click();
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], CompanylogoUploadComponent.prototype, "logo", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], CompanylogoUploadComponent.prototype, "Src", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], CompanylogoUploadComponent.prototype, "error", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
], CompanylogoUploadComponent.prototype, "onSaveLogo", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
], CompanylogoUploadComponent.prototype, "onRemoveLogo", void 0);
CompanylogoUploadComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "companylogo-upload",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./companylogo-upload.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/companylogo-upload/companylogo-upload.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./companylogo-upload.component.css */ "./src/app/shared/widgets/companylogo-upload/companylogo-upload.component.css")).default]
    })
], CompanylogoUploadComponent);

function isBase64(str) {
    if (str === "" || str.trim() === "") {
        return false;
    }
    try {
        Object(ngx_image_cropper__WEBPACK_IMPORTED_MODULE_2__["base64ToFile"])(str);
        return true;
    }
    catch (err) {
        return false;
    }
}


/***/ }),

/***/ "./src/app/shared/widgets/doc-upload/doc-upload.component.css":
/*!********************************************************************!*\
  !*** ./src/app/shared/widgets/doc-upload/doc-upload.component.css ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".add-doc input[type=\"file\"] {\r\n\tdisplay: none;\r\n}\r\n\r\n.add-doc {\r\n\tmargin-top: 15px;\r\n}\r\n\r\n.add-doc label {\r\n\tdisplay: -webkit-box;\r\n\tdisplay: flex;\r\n\t-webkit-box-align: center;\r\n\t        align-items: center;\r\n\t-webkit-box-pack: center;\r\n\t        justify-content: center;\r\n\tborder: 1px solid #dedede;\r\n\tborder-radius: 4px;\r\n\tcursor: pointer;\r\n}\r\n\r\n.add-doc label svg {\r\n\twidth: 20px;\r\n}\r\n\r\n.add-doc label span {\r\n\tcolor: #2d9851;\r\n\tfont-weight: 500;\r\n}\r\n\r\n.file-item {\r\n\tdisplay: -webkit-box;\r\n\tdisplay: flex;\r\n\tpadding: 8px;\r\n\tborder: 1px solid #dedede;\r\n\tborder-radius: 4px;\r\n\tfont-size: 12px;\r\n\t-webkit-box-align: center;\r\n\t        align-items: center;\r\n\t-webkit-box-pack: justify;\r\n\t        justify-content: space-between;\r\n\tmargin-bottom: 6px;\r\n}\r\n\r\n.file-col {\r\n\tcolor: #2d9851;\r\n\tpadding-right: 5px;\r\n\tflex-basis: 80%;\r\n}\r\n\r\n.file-col i {\r\n\tfont-size: 14px;\r\n\tmargin-right: 6px;\r\n}\r\n\r\n.remove-col {\r\n\tflex-basis: 20%;\r\n}\r\n\r\n.act-span {\r\n\tpadding: 3px 6px;\r\n\tborder: 1px solid var(--primary-green);\r\n\tfont-size: 12px;\r\n\tcolor: #2d9851;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3dpZGdldHMvZG9jLXVwbG9hZC9kb2MtdXBsb2FkLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Q0FDQyxhQUFhO0FBQ2Q7O0FBRUE7Q0FDQyxnQkFBZ0I7QUFDakI7O0FBRUE7Q0FDQyxvQkFBYTtDQUFiLGFBQWE7Q0FDYix5QkFBbUI7U0FBbkIsbUJBQW1CO0NBQ25CLHdCQUF1QjtTQUF2Qix1QkFBdUI7Q0FDdkIseUJBQXlCO0NBQ3pCLGtCQUFrQjtDQUNsQixlQUFlO0FBQ2hCOztBQUVBO0NBQ0MsV0FBVztBQUNaOztBQUVBO0NBQ0MsY0FBYztDQUNkLGdCQUFnQjtBQUNqQjs7QUFFQTtDQUNDLG9CQUFhO0NBQWIsYUFBYTtDQUNiLFlBQVk7Q0FDWix5QkFBeUI7Q0FDekIsa0JBQWtCO0NBQ2xCLGVBQWU7Q0FDZix5QkFBbUI7U0FBbkIsbUJBQW1CO0NBQ25CLHlCQUE4QjtTQUE5Qiw4QkFBOEI7Q0FDOUIsa0JBQWtCO0FBQ25COztBQUVBO0NBQ0MsY0FBYztDQUNkLGtCQUFrQjtDQUNsQixlQUFlO0FBQ2hCOztBQUVBO0NBQ0MsZUFBZTtDQUNmLGlCQUFpQjtBQUNsQjs7QUFFQTtDQUNDLGVBQWU7QUFDaEI7O0FBRUE7Q0FDQyxnQkFBZ0I7Q0FDaEIsc0NBQXNDO0NBQ3RDLGVBQWU7Q0FDZixjQUFjO0FBQ2YiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvd2lkZ2V0cy9kb2MtdXBsb2FkL2RvYy11cGxvYWQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5hZGQtZG9jIGlucHV0W3R5cGU9XCJmaWxlXCJdIHtcclxuXHRkaXNwbGF5OiBub25lO1xyXG59XHJcblxyXG4uYWRkLWRvYyB7XHJcblx0bWFyZ2luLXRvcDogMTVweDtcclxufVxyXG5cclxuLmFkZC1kb2MgbGFiZWwge1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcblx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHRqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHRib3JkZXI6IDFweCBzb2xpZCAjZGVkZWRlO1xyXG5cdGJvcmRlci1yYWRpdXM6IDRweDtcclxuXHRjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5hZGQtZG9jIGxhYmVsIHN2ZyB7XHJcblx0d2lkdGg6IDIwcHg7XHJcbn1cclxuXHJcbi5hZGQtZG9jIGxhYmVsIHNwYW4ge1xyXG5cdGNvbG9yOiAjMmQ5ODUxO1xyXG5cdGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuXHJcbi5maWxlLWl0ZW0ge1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcblx0cGFkZGluZzogOHB4O1xyXG5cdGJvcmRlcjogMXB4IHNvbGlkICNkZWRlZGU7XHJcblx0Ym9yZGVyLXJhZGl1czogNHB4O1xyXG5cdGZvbnQtc2l6ZTogMTJweDtcclxuXHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuXHRtYXJnaW4tYm90dG9tOiA2cHg7XHJcbn1cclxuXHJcbi5maWxlLWNvbCB7XHJcblx0Y29sb3I6ICMyZDk4NTE7XHJcblx0cGFkZGluZy1yaWdodDogNXB4O1xyXG5cdGZsZXgtYmFzaXM6IDgwJTtcclxufVxyXG5cclxuLmZpbGUtY29sIGkge1xyXG5cdGZvbnQtc2l6ZTogMTRweDtcclxuXHRtYXJnaW4tcmlnaHQ6IDZweDtcclxufVxyXG5cclxuLnJlbW92ZS1jb2wge1xyXG5cdGZsZXgtYmFzaXM6IDIwJTtcclxufVxyXG5cclxuLmFjdC1zcGFuIHtcclxuXHRwYWRkaW5nOiAzcHggNnB4O1xyXG5cdGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLXByaW1hcnktZ3JlZW4pO1xyXG5cdGZvbnQtc2l6ZTogMTJweDtcclxuXHRjb2xvcjogIzJkOTg1MTtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "./src/app/shared/widgets/doc-upload/doc-upload.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/shared/widgets/doc-upload/doc-upload.component.ts ***!
  \*******************************************************************/
/*! exports provided: DocUploadComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DocUploadComponent", function() { return DocUploadComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");



let DocUploadComponent = class DocUploadComponent {
    constructor() {
        this.onUploadChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.fileNameArr = [];
        this.fileArr = [];
        this.serverUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].server_url;
    }
    ngOnInit() {
        if (this.docs) {
            this.fileNameArr = this.docs.map((d) => this.extractFileName(d));
            this.fileArr = this.docs;
            console.log(this.docs);
        }
    }
    fileChangeEvent(uploadedFile) {
        if (uploadedFile.length) {
            this.fileArr.push(uploadedFile[0]);
            this.fileNameArr.push(uploadedFile[0].name);
            this.onUploadChange.emit(this.fileArr);
        }
    }
    removeFile(removeAt) {
        if (~removeAt) {
            this.fileArr.splice(removeAt, 1);
            this.fileNameArr.splice(removeAt, 1);
            this.onUploadChange.emit(this.fileArr);
        }
    }
    extractFileName(path) {
        let filename = path.replace(/^.*[\\\/]/, "");
        return filename;
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], DocUploadComponent.prototype, "uploadName", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], DocUploadComponent.prototype, "docs", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
], DocUploadComponent.prototype, "onUploadChange", void 0);
DocUploadComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "doc-upload",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./doc-upload.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/doc-upload/doc-upload.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./doc-upload.component.css */ "./src/app/shared/widgets/doc-upload/doc-upload.component.css")).default]
    })
], DocUploadComponent);



/***/ }),

/***/ "./src/app/shared/widgets/gallery-upload/gallery-upload.component.css":
/*!****************************************************************************!*\
  !*** ./src/app/shared/widgets/gallery-upload/gallery-upload.component.css ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".gallery-upload-wrp {\r\n    display: -webkit-box;\r\n    display: flex;\r\n    -webkit-box-pack: justify;\r\n            justify-content: space-between;\r\n    padding: 18px 15px;\r\n    margin-bottom: 15px;\r\n    border: 1px solid #dedede;\r\n    border-radius: 4px;\r\n  }\r\n  \r\n  .gallery-sqaure {\r\n    flex-basis: 18%;\r\n    border: 1px solid #dedede;\r\n    border-radius: 4px;\r\n  }\r\n  \r\n  .add-img-wrp {\r\n    display: -webkit-box;\r\n    display: flex;\r\n    height: 83px;\r\n    -webkit-box-align: center;\r\n            align-items: center;\r\n    -webkit-box-pack: center;\r\n            justify-content: center;\r\n  }\r\n  \r\n  .add-img-wrp i {\r\n    color: var(--primary-green);\r\n    cursor: pointer;\r\n  }\r\n  \r\n  .preview-img-wrp {\r\n    position: relative;\r\n  }\r\n  \r\n  .preview-img-wrp img {\r\n    border-radius: 4px;\r\n  }\r\n  \r\n  .remove-img {\r\n    padding: 2px 7px;\r\n    background-color: var(--white);\r\n    display: inline-block;\r\n    position: absolute;\r\n    top: -10px;\r\n    right: -10px;\r\n    font-size: 12px;\r\n    border-radius: 16px;\r\n    color: #f8483d;\r\n    cursor: pointer;\r\n    visibility: hidden;\r\n    opacity: 0;\r\n    z-index: 10;\r\n    -webkit-transition: all 0.3s;\r\n    transition: all 0.3s;\r\n    border: 1px solid #dedede;\r\n    box-shadow: 0px 4px 25px rgb(172 177 193 / 40%);\r\n  }\r\n  \r\n  .preview-img-wrp:hover .remove-img {\r\n    opacity: 1;\r\n    visibility: visible;\r\n  }\r\n  \r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3dpZGdldHMvZ2FsbGVyeS11cGxvYWQvZ2FsbGVyeS11cGxvYWQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLG9CQUFhO0lBQWIsYUFBYTtJQUNiLHlCQUE4QjtZQUE5Qiw4QkFBOEI7SUFDOUIsa0JBQWtCO0lBQ2xCLG1CQUFtQjtJQUNuQix5QkFBeUI7SUFDekIsa0JBQWtCO0VBQ3BCOztFQUVBO0lBQ0UsZUFBZTtJQUNmLHlCQUF5QjtJQUN6QixrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxvQkFBYTtJQUFiLGFBQWE7SUFDYixZQUFZO0lBQ1oseUJBQW1CO1lBQW5CLG1CQUFtQjtJQUNuQix3QkFBdUI7WUFBdkIsdUJBQXVCO0VBQ3pCOztFQUVBO0lBQ0UsMkJBQTJCO0lBQzNCLGVBQWU7RUFDakI7O0VBRUE7SUFDRSxrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxrQkFBa0I7RUFDcEI7O0VBRUE7SUFDRSxnQkFBZ0I7SUFDaEIsOEJBQThCO0lBQzlCLHFCQUFxQjtJQUNyQixrQkFBa0I7SUFDbEIsVUFBVTtJQUNWLFlBQVk7SUFDWixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLGNBQWM7SUFDZCxlQUFlO0lBQ2Ysa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixXQUFXO0lBQ1gsNEJBQTRCO0lBQzVCLG9CQUFvQjtJQUNwQix5QkFBeUI7SUFDekIsK0NBQStDO0VBQ2pEOztFQUVBO0lBQ0UsVUFBVTtJQUNWLG1CQUFtQjtFQUNyQiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC93aWRnZXRzL2dhbGxlcnktdXBsb2FkL2dhbGxlcnktdXBsb2FkLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZ2FsbGVyeS11cGxvYWQtd3JwIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBwYWRkaW5nOiAxOHB4IDE1cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2RlZGVkZTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICB9XHJcbiAgXHJcbiAgLmdhbGxlcnktc3FhdXJlIHtcclxuICAgIGZsZXgtYmFzaXM6IDE4JTtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNkZWRlZGU7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5hZGQtaW1nLXdycCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgaGVpZ2h0OiA4M3B4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIH1cclxuICBcclxuICAuYWRkLWltZy13cnAgaSB7XHJcbiAgICBjb2xvcjogdmFyKC0tcHJpbWFyeS1ncmVlbik7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgfVxyXG4gIFxyXG4gIC5wcmV2aWV3LWltZy13cnAge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIH1cclxuICBcclxuICAucHJldmlldy1pbWctd3JwIGltZyB7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5yZW1vdmUtaW1nIHtcclxuICAgIHBhZGRpbmc6IDJweCA3cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS13aGl0ZSk7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IC0xMHB4O1xyXG4gICAgcmlnaHQ6IC0xMHB4O1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTZweDtcclxuICAgIGNvbG9yOiAjZjg0ODNkO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgdmlzaWJpbGl0eTogaGlkZGVuO1xyXG4gICAgb3BhY2l0eTogMDtcclxuICAgIHotaW5kZXg6IDEwO1xyXG4gICAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgMC4zcztcclxuICAgIHRyYW5zaXRpb246IGFsbCAwLjNzO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2RlZGVkZTtcclxuICAgIGJveC1zaGFkb3c6IDBweCA0cHggMjVweCByZ2IoMTcyIDE3NyAxOTMgLyA0MCUpO1xyXG4gIH1cclxuICBcclxuICAucHJldmlldy1pbWctd3JwOmhvdmVyIC5yZW1vdmUtaW1nIHtcclxuICAgIG9wYWNpdHk6IDE7XHJcbiAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xyXG4gIH1cclxuICAiXX0= */");

/***/ }),

/***/ "./src/app/shared/widgets/gallery-upload/gallery-upload.component.ts":
/*!***************************************************************************!*\
  !*** ./src/app/shared/widgets/gallery-upload/gallery-upload.component.ts ***!
  \***************************************************************************/
/*! exports provided: GalleryUploadComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GalleryUploadComponent", function() { return GalleryUploadComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var ngx_image_cropper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ngx-image-cropper */ "./node_modules/ngx-image-cropper/fesm2015/ngx-image-cropper.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");




let GalleryUploadComponent = class GalleryUploadComponent {
    constructor() {
        this.onGalleryChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.imageChangedEvent = "";
        this.croppedImage = "";
        this.previewArr = [];
        this.galleryArr = [];
        this.serverUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].server_url;
    }
    ngOnInit() {
        if (this.gallery) {
            this.previewArr = this.gallery.map(e => this.serverUrl + e);
            this.galleryArr = this.gallery;
        }
    }
    fileChangeEvent(event) {
        this.imageChangedEvent = event;
    }
    imageCropped(event) {
        this.croppedImage = event.base64;
    }
    imageLoaded(image) {
        this.fileLoaded = true;
    }
    cropperReady() {
        // cropper ready
    }
    loadImageFailed() {
        // show message
    }
    removeImage(removeIndex) {
        if (~removeIndex) {
            this.galleryArr.splice(removeIndex, 1);
            this.previewArr.splice(removeIndex, 1);
            this.onGalleryChange.emit(this.galleryArr);
        }
    }
    saveEditedGalleryImage() {
        const fileBeforeCrop = this.imageChangedEvent.target.files[0];
        const croppedFile = new File([Object(ngx_image_cropper__WEBPACK_IMPORTED_MODULE_2__["base64ToFile"])(this.croppedImage)], fileBeforeCrop.name, {
            type: fileBeforeCrop.type,
        });
        this.galleryArr.push(croppedFile);
        // console.log("cropped-file", croppedFile);
        this.previewArr.push(this.croppedImage);
        // console.log("croppedImage-previewArr", this.croppedImage);
        this.imageChangedEvent = null;
        this.fileLoaded = false;
        this.croppedImage = "";
        this.onGalleryChange.emit(this.galleryArr);
        document.getElementById("galleryModal").click();
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], GalleryUploadComponent.prototype, "gallery", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
], GalleryUploadComponent.prototype, "onGalleryChange", void 0);
GalleryUploadComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-gallery-upload',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./gallery-upload.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/gallery-upload/gallery-upload.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./gallery-upload.component.css */ "./src/app/shared/widgets/gallery-upload/gallery-upload.component.css")).default]
    })
], GalleryUploadComponent);



/***/ }),

/***/ "./src/app/shared/widgets/image-cropper/image-cropper.component.css":
/*!**************************************************************************!*\
  !*** ./src/app/shared/widgets/image-cropper/image-cropper.component.css ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC93aWRnZXRzL2ltYWdlLWNyb3BwZXIvaW1hZ2UtY3JvcHBlci5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/shared/widgets/image-cropper/image-cropper.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/shared/widgets/image-cropper/image-cropper.component.ts ***!
  \*************************************************************************/
/*! exports provided: ImageCropperComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageCropperComponent", function() { return ImageCropperComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let ImageCropperComponent = class ImageCropperComponent {
    constructor() {
        this.imageChangedEvent = "";
        this.croppedImage = "";
        this.defaultConfig = {
            aspectRatio: "1 / 1",
            format: "png",
            type: "normal",
            resizeWidth: 512,
        };
        this.config = Object.assign({}, this.defaultConfig, this.config);
    }
    ngOnInit() {
        // console.log(this.config);
    }
    fileChangeEvent(event) {
        this.imageChangedEvent = event;
    }
    imageCropped(event) {
        // console.log(event);
        this.croppedImage = event.base64;
    }
    imageLoaded(image) {
        this.fileLoaded = true;
        // show cropper
    }
    cropperReady() {
        // cropper ready
    }
    loadImageFailed() {
        // show message
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], ImageCropperComponent.prototype, "config", void 0);
ImageCropperComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "Image-Editor",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./image-cropper.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/image-cropper/image-cropper.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./image-cropper.component.css */ "./src/app/shared/widgets/image-cropper/image-cropper.component.css")).default]
    })
], ImageCropperComponent);



/***/ }),

/***/ "./src/app/shared/widgets/notifier/notifier.component.css":
/*!****************************************************************!*\
  !*** ./src/app/shared/widgets/notifier/notifier.component.css ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".notification-wrapper {\r\n\tmargin-top: 20px;\r\n\tposition: relative;\r\n}\r\n\r\n.notification-wrapper:hover .notification-tray {\r\n\tvisibility: visible;\r\n\topacity: 1;\r\n}\r\n\r\n.bell {\r\n\tfont-size: 20px;\r\n\tcolor: #a2a2a3;\r\n}\r\n\r\n.bell i {\r\n\tposition: relative;\r\n}\r\n\r\n.bell i:after {\r\n\tcontent: attr(data-count);\r\n\tposition: absolute;\r\n\tbackground: var(--primary-clr);\r\n\ttop: -11px;\r\n\tright: -10px;\r\n\ttext-align: center;\r\n\tfont-size: 10px;\r\n\tborder-radius: 50%;\r\n\tcolor: white;\r\n\tpadding: 5px 5px;\r\n\twidth: 20px;\r\n\theight: 20px;\r\n}\r\n\r\n.notification-tray {\r\n\tposition: absolute;\r\n\twidth: 500px;\r\n\tbackground: var(--white);\r\n\tz-index: 1000000;\r\n\ttop: 62px;\r\n\tleft: -15.5rem;\r\n\tbox-shadow: 0px 4px 25px rgba(172, 177, 193, 0.4);\r\n\tborder-radius: 4px;\r\n\t-webkit-transition: all 0.3s ease;\r\n\ttransition: all 0.3s ease;\r\n\tvisibility: hidden;\r\n\topacity: 0;\r\n}\r\n\r\n.notification-content {\r\n\theight: 420px;\r\n\toverflow-y: auto;\r\n}\r\n\r\n.notification-tray .title {\r\n\tfont-size: 0.95rem;\r\n\tfont-weight: 500;\r\n\tcolor: #222327;\r\n}\r\n\r\n.notification-tray .header {\r\n\tpadding: 18px;\r\n\tdisplay: -webkit-box;\r\n\tdisplay: flex;\r\n\t-webkit-box-align: center;\r\n\t        align-items: center;\r\n\t-webkit-box-pack: justify;\r\n\t        justify-content: space-between;\r\n\tborder-bottom: 1px solid #dedede;\r\n}\r\n\r\n.notification-tray .header .bell {\r\n\tmargin-left: 0.5rem;\r\n}\r\n\r\n.notification-tray .header .bell i:after {\r\n\tdisplay: none;\r\n}\r\n\r\n.notification-tray .header .view-link {\r\n\tfont-size: 0.75rem;\r\n\tfont-weight: 400;\r\n\tcolor: #222327;\r\n\topacity: 0.8;\r\n\tcursor: pointer;\r\n}\r\n\r\n.notification-tray .notification-item {\r\n\tpadding: 20px 18px;\r\n\tdisplay: grid;\r\n\tgrid-template-columns: 6fr 0.5fr 2fr;\r\n\t-webkit-box-align: center;\r\n\t        align-items: center;\r\n\tborder-bottom: 1px solid #dedede;\r\n}\r\n\r\n.notification-content::-webkit-scrollbar-track {\r\n\t/* -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);\r\n\tborder-radius: 10px;\r\n\tbackground-color: #f5f5f5; */\r\n}\r\n\r\n.notification-content::-webkit-scrollbar {\r\n\twidth: 6px;\r\n}\r\n\r\n.notification-content::-webkit-scrollbar-thumb {\r\n\tborder-radius: 12px;\r\n\tbackground-color: transparent;\r\n\t-webkit-transition: all 0.3s ease;\r\n\ttransition: all 0.3s ease;\r\n}\r\n\r\n.notification-tray:hover .notification-content::-webkit-scrollbar-thumb {\r\n\t-webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.2);\r\n\tbackground-color: #dedede;\r\n}\r\n\r\n.notification-item {\r\n\t-webkit-transition: all 0.3s ease;\r\n\ttransition: all 0.3s ease;\r\n\tcursor: pointer;\r\n}\r\n\r\n.notification-item:hover {\r\n\tbackground: #f7f7f9;\r\n}\r\n\r\n.notification-item .message {\r\n\tfont-size: 0.8rem !important;\r\n\t-webkit-box-flex: 1;\r\n\t        flex-grow: 1;\r\n}\r\n\r\n.notification-item .time {\r\n\tcolor: #4f4f4f;\r\n\topacity: 0.6;\r\n\tfont-size: 0.631rem;\r\n\ttext-align: right;\r\n}\r\n\r\n.notification-item .status {\r\n\twidth: 8px;\r\n\theight: 8px;\r\n\tborder-radius: 50%;\r\n\tmargin-left: 1rem;\r\n\tmargin-right: 1rem;\r\n}\r\n\r\n.notification-item .status.new {\r\n\tbackground-color: var(--primary-clr);\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3dpZGdldHMvbm90aWZpZXIvbm90aWZpZXIuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtDQUNDLGdCQUFnQjtDQUNoQixrQkFBa0I7QUFDbkI7O0FBRUE7Q0FDQyxtQkFBbUI7Q0FDbkIsVUFBVTtBQUNYOztBQUVBO0NBQ0MsZUFBZTtDQUNmLGNBQWM7QUFDZjs7QUFFQTtDQUNDLGtCQUFrQjtBQUNuQjs7QUFFQTtDQUNDLHlCQUF5QjtDQUN6QixrQkFBa0I7Q0FDbEIsOEJBQThCO0NBQzlCLFVBQVU7Q0FDVixZQUFZO0NBQ1osa0JBQWtCO0NBQ2xCLGVBQWU7Q0FDZixrQkFBa0I7Q0FDbEIsWUFBWTtDQUNaLGdCQUFnQjtDQUNoQixXQUFXO0NBQ1gsWUFBWTtBQUNiOztBQUVBO0NBQ0Msa0JBQWtCO0NBQ2xCLFlBQVk7Q0FDWix3QkFBd0I7Q0FDeEIsZ0JBQWdCO0NBQ2hCLFNBQVM7Q0FDVCxjQUFjO0NBQ2QsaURBQWlEO0NBQ2pELGtCQUFrQjtDQUNsQixpQ0FBaUM7Q0FDakMseUJBQXlCO0NBQ3pCLGtCQUFrQjtDQUNsQixVQUFVO0FBQ1g7O0FBRUE7Q0FDQyxhQUFhO0NBQ2IsZ0JBQWdCO0FBQ2pCOztBQUVBO0NBQ0Msa0JBQWtCO0NBQ2xCLGdCQUFnQjtDQUNoQixjQUFjO0FBQ2Y7O0FBRUE7Q0FDQyxhQUFhO0NBQ2Isb0JBQWE7Q0FBYixhQUFhO0NBQ2IseUJBQW1CO1NBQW5CLG1CQUFtQjtDQUNuQix5QkFBOEI7U0FBOUIsOEJBQThCO0NBQzlCLGdDQUFnQztBQUNqQzs7QUFFQTtDQUNDLG1CQUFtQjtBQUNwQjs7QUFFQTtDQUNDLGFBQWE7QUFDZDs7QUFFQTtDQUNDLGtCQUFrQjtDQUNsQixnQkFBZ0I7Q0FDaEIsY0FBYztDQUNkLFlBQVk7Q0FDWixlQUFlO0FBQ2hCOztBQUVBO0NBQ0Msa0JBQWtCO0NBQ2xCLGFBQWE7Q0FDYixvQ0FBb0M7Q0FDcEMseUJBQW1CO1NBQW5CLG1CQUFtQjtDQUNuQixnQ0FBZ0M7QUFDakM7O0FBRUE7Q0FDQzs7NkJBRTRCO0FBQzdCOztBQUVBO0NBQ0MsVUFBVTtBQUNYOztBQUVBO0NBQ0MsbUJBQW1CO0NBQ25CLDZCQUE2QjtDQUM3QixpQ0FBeUI7Q0FBekIseUJBQXlCO0FBQzFCOztBQUVBO0NBQ0Msb0RBQW9EO0NBQ3BELHlCQUF5QjtBQUMxQjs7QUFFQTtDQUNDLGlDQUF5QjtDQUF6Qix5QkFBeUI7Q0FDekIsZUFBZTtBQUNoQjs7QUFFQTtDQUNDLG1CQUFtQjtBQUNwQjs7QUFFQTtDQUNDLDRCQUE0QjtDQUM1QixtQkFBWTtTQUFaLFlBQVk7QUFDYjs7QUFFQTtDQUNDLGNBQWM7Q0FDZCxZQUFZO0NBQ1osbUJBQW1CO0NBQ25CLGlCQUFpQjtBQUNsQjs7QUFFQTtDQUNDLFVBQVU7Q0FDVixXQUFXO0NBQ1gsa0JBQWtCO0NBQ2xCLGlCQUFpQjtDQUNqQixrQkFBa0I7QUFDbkI7O0FBRUE7Q0FDQyxvQ0FBb0M7QUFDckMiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvd2lkZ2V0cy9ub3RpZmllci9ub3RpZmllci5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm5vdGlmaWNhdGlvbi13cmFwcGVyIHtcclxuXHRtYXJnaW4tdG9wOiAyMHB4O1xyXG5cdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLm5vdGlmaWNhdGlvbi13cmFwcGVyOmhvdmVyIC5ub3RpZmljYXRpb24tdHJheSB7XHJcblx0dmlzaWJpbGl0eTogdmlzaWJsZTtcclxuXHRvcGFjaXR5OiAxO1xyXG59XHJcblxyXG4uYmVsbCB7XHJcblx0Zm9udC1zaXplOiAyMHB4O1xyXG5cdGNvbG9yOiAjYTJhMmEzO1xyXG59XHJcblxyXG4uYmVsbCBpIHtcclxuXHRwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi5iZWxsIGk6YWZ0ZXIge1xyXG5cdGNvbnRlbnQ6IGF0dHIoZGF0YS1jb3VudCk7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdGJhY2tncm91bmQ6IHZhcigtLXByaW1hcnktY2xyKTtcclxuXHR0b3A6IC0xMXB4O1xyXG5cdHJpZ2h0OiAtMTBweDtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0Zm9udC1zaXplOiAxMHB4O1xyXG5cdGJvcmRlci1yYWRpdXM6IDUwJTtcclxuXHRjb2xvcjogd2hpdGU7XHJcblx0cGFkZGluZzogNXB4IDVweDtcclxuXHR3aWR0aDogMjBweDtcclxuXHRoZWlnaHQ6IDIwcHg7XHJcbn1cclxuXHJcbi5ub3RpZmljYXRpb24tdHJheSB7XHJcblx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdHdpZHRoOiA1MDBweDtcclxuXHRiYWNrZ3JvdW5kOiB2YXIoLS13aGl0ZSk7XHJcblx0ei1pbmRleDogMTAwMDAwMDtcclxuXHR0b3A6IDYycHg7XHJcblx0bGVmdDogLTE1LjVyZW07XHJcblx0Ym94LXNoYWRvdzogMHB4IDRweCAyNXB4IHJnYmEoMTcyLCAxNzcsIDE5MywgMC40KTtcclxuXHRib3JkZXItcmFkaXVzOiA0cHg7XHJcblx0LXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlO1xyXG5cdHRyYW5zaXRpb246IGFsbCAwLjNzIGVhc2U7XHJcblx0dmlzaWJpbGl0eTogaGlkZGVuO1xyXG5cdG9wYWNpdHk6IDA7XHJcbn1cclxuXHJcbi5ub3RpZmljYXRpb24tY29udGVudCB7XHJcblx0aGVpZ2h0OiA0MjBweDtcclxuXHRvdmVyZmxvdy15OiBhdXRvO1xyXG59XHJcblxyXG4ubm90aWZpY2F0aW9uLXRyYXkgLnRpdGxlIHtcclxuXHRmb250LXNpemU6IDAuOTVyZW07XHJcblx0Zm9udC13ZWlnaHQ6IDUwMDtcclxuXHRjb2xvcjogIzIyMjMyNztcclxufVxyXG5cclxuLm5vdGlmaWNhdGlvbi10cmF5IC5oZWFkZXIge1xyXG5cdHBhZGRpbmc6IDE4cHg7XHJcblx0ZGlzcGxheTogZmxleDtcclxuXHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuXHRib3JkZXItYm90dG9tOiAxcHggc29saWQgI2RlZGVkZTtcclxufVxyXG5cclxuLm5vdGlmaWNhdGlvbi10cmF5IC5oZWFkZXIgLmJlbGwge1xyXG5cdG1hcmdpbi1sZWZ0OiAwLjVyZW07XHJcbn1cclxuXHJcbi5ub3RpZmljYXRpb24tdHJheSAuaGVhZGVyIC5iZWxsIGk6YWZ0ZXIge1xyXG5cdGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuXHJcbi5ub3RpZmljYXRpb24tdHJheSAuaGVhZGVyIC52aWV3LWxpbmsge1xyXG5cdGZvbnQtc2l6ZTogMC43NXJlbTtcclxuXHRmb250LXdlaWdodDogNDAwO1xyXG5cdGNvbG9yOiAjMjIyMzI3O1xyXG5cdG9wYWNpdHk6IDAuODtcclxuXHRjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5ub3RpZmljYXRpb24tdHJheSAubm90aWZpY2F0aW9uLWl0ZW0ge1xyXG5cdHBhZGRpbmc6IDIwcHggMThweDtcclxuXHRkaXNwbGF5OiBncmlkO1xyXG5cdGdyaWQtdGVtcGxhdGUtY29sdW1uczogNmZyIDAuNWZyIDJmcjtcclxuXHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cdGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZGVkZWRlO1xyXG59XHJcblxyXG4ubm90aWZpY2F0aW9uLWNvbnRlbnQ6Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuXHQvKiAtd2Via2l0LWJveC1zaGFkb3c6IGluc2V0IDAgMCA2cHggcmdiYSgwLCAwLCAwLCAwLjMpO1xyXG5cdGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTsgKi9cclxufVxyXG5cclxuLm5vdGlmaWNhdGlvbi1jb250ZW50Ojotd2Via2l0LXNjcm9sbGJhciB7XHJcblx0d2lkdGg6IDZweDtcclxufVxyXG5cclxuLm5vdGlmaWNhdGlvbi1jb250ZW50Ojotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcblx0Ym9yZGVyLXJhZGl1czogMTJweDtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuXHR0cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlO1xyXG59XHJcblxyXG4ubm90aWZpY2F0aW9uLXRyYXk6aG92ZXIgLm5vdGlmaWNhdGlvbi1jb250ZW50Ojotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcblx0LXdlYmtpdC1ib3gtc2hhZG93OiBpbnNldCAwIDAgNnB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAjZGVkZWRlO1xyXG59XHJcblxyXG4ubm90aWZpY2F0aW9uLWl0ZW0ge1xyXG5cdHRyYW5zaXRpb246IGFsbCAwLjNzIGVhc2U7XHJcblx0Y3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4ubm90aWZpY2F0aW9uLWl0ZW06aG92ZXIge1xyXG5cdGJhY2tncm91bmQ6ICNmN2Y3Zjk7XHJcbn1cclxuXHJcbi5ub3RpZmljYXRpb24taXRlbSAubWVzc2FnZSB7XHJcblx0Zm9udC1zaXplOiAwLjhyZW0gIWltcG9ydGFudDtcclxuXHRmbGV4LWdyb3c6IDE7XHJcbn1cclxuXHJcbi5ub3RpZmljYXRpb24taXRlbSAudGltZSB7XHJcblx0Y29sb3I6ICM0ZjRmNGY7XHJcblx0b3BhY2l0eTogMC42O1xyXG5cdGZvbnQtc2l6ZTogMC42MzFyZW07XHJcblx0dGV4dC1hbGlnbjogcmlnaHQ7XHJcbn1cclxuXHJcbi5ub3RpZmljYXRpb24taXRlbSAuc3RhdHVzIHtcclxuXHR3aWR0aDogOHB4O1xyXG5cdGhlaWdodDogOHB4O1xyXG5cdGJvcmRlci1yYWRpdXM6IDUwJTtcclxuXHRtYXJnaW4tbGVmdDogMXJlbTtcclxuXHRtYXJnaW4tcmlnaHQ6IDFyZW07XHJcbn1cclxuXHJcbi5ub3RpZmljYXRpb24taXRlbSAuc3RhdHVzLm5ldyB7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogdmFyKC0tcHJpbWFyeS1jbHIpO1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "./src/app/shared/widgets/notifier/notifier.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/shared/widgets/notifier/notifier.component.ts ***!
  \***************************************************************/
/*! exports provided: NotifierComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotifierComponent", function() { return NotifierComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_firestore_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../services/firestore.service */ "./src/app/services/firestore.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);





let NotifierComponent = class NotifierComponent {
    constructor(fs, router) {
        this.fs = fs;
        this.router = router;
        this.notificationCount = 0;
    }
    ngOnInit() {
        this.fs.getNotifications().subscribe((data) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.notifications = data;
            yield this.notifications.map((n) => (n.timestamp = moment__WEBPACK_IMPORTED_MODULE_4__(n.createdAt.seconds * 1000).fromNow()));
            this.notificationCount = data.length || 0;
        }));
        // console.log("notifications unread", this.notifications )
    }
    ngOnChanges() { }
    handleNotificationRedirect(reDirectRoute, notificationId) {
        this.fs.updateReadStatus(notificationId);
        this.router.navigateByUrl(reDirectRoute);
    }
    viewAll() {
        this.router.navigateByUrl('notifications');
    }
};
NotifierComponent.ctorParameters = () => [
    { type: _services_firestore_service__WEBPACK_IMPORTED_MODULE_2__["FirestoreService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
NotifierComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-notifier",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./notifier.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/notifier/notifier.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./notifier.component.css */ "./src/app/shared/widgets/notifier/notifier.component.css")).default]
    })
], NotifierComponent);



/***/ }),

/***/ "./src/app/shared/widgets/pagination/pagination.component.css":
/*!********************************************************************!*\
  !*** ./src/app/shared/widgets/pagination/pagination.component.css ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".pagination li a{\r\n    color: var(--black8);\r\n    font-size: 14px !important;\r\n}\r\n\r\n.pagination li.active a{\r\n    background-color: var(--primary-clr) !important;\r\n    border-color: var(--primary-clr) !important;\r\n    color: var(--white);\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3dpZGdldHMvcGFnaW5hdGlvbi9wYWdpbmF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxvQkFBb0I7SUFDcEIsMEJBQTBCO0FBQzlCOztBQUVBO0lBQ0ksK0NBQStDO0lBQy9DLDJDQUEyQztJQUMzQyxtQkFBbUI7QUFDdkIiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvd2lkZ2V0cy9wYWdpbmF0aW9uL3BhZ2luYXRpb24uY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wYWdpbmF0aW9uIGxpIGF7XHJcbiAgICBjb2xvcjogdmFyKC0tYmxhY2s4KTtcclxuICAgIGZvbnQtc2l6ZTogMTRweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ucGFnaW5hdGlvbiBsaS5hY3RpdmUgYXtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXByaW1hcnktY2xyKSAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1wcmltYXJ5LWNscikgIWltcG9ydGFudDtcclxuICAgIGNvbG9yOiB2YXIoLS13aGl0ZSk7XHJcbn0iXX0= */");

/***/ }),

/***/ "./src/app/shared/widgets/pagination/pagination.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/shared/widgets/pagination/pagination.component.ts ***!
  \*******************************************************************/
/*! exports provided: PaginationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaginationComponent", function() { return PaginationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let PaginationComponent = class PaginationComponent {
    constructor() {
        this.pageSize = 10;
        this.onPageChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.pagination = null;
    }
    ngOnChanges() {
        this.selectedPage = 1;
        this.pagination = this.paginate(this.totalItems, this.selectedPage, this.pageSize);
    }
    goToPage(pageIndex) {
        this.selectedPage = pageIndex;
        this.pagination = this.paginate(this.totalItems, this.selectedPage, this.pageSize);
        this.onPageChange.emit(pageIndex);
        window.scroll(0, 0);
    }
    paginate(totalItems, currentPage, pageSize, maxPages = 10) {
        // calculate total pages
        let totalPages = Math.ceil(totalItems / pageSize);
        // ensure current page isn't out of range
        if (currentPage < 1) {
            currentPage = 1;
        }
        else if (currentPage > totalPages) {
            currentPage = totalPages;
        }
        let startPage, endPage;
        if (totalPages <= maxPages) {
            // total pages less than max so show all pages
            startPage = 1;
            endPage = totalPages;
        }
        else {
            // total pages more than max so calculate start and end pages
            let maxPagesBeforeCurrentPage = Math.floor(maxPages / 2);
            let maxPagesAfterCurrentPage = Math.ceil(maxPages / 2) - 1;
            if (currentPage <= maxPagesBeforeCurrentPage) {
                // current page near the start
                startPage = 1;
                endPage = maxPages;
            }
            else if (currentPage + maxPagesAfterCurrentPage >= totalPages) {
                // current page near the end
                startPage = totalPages - maxPages + 1;
                endPage = totalPages;
            }
            else {
                // current page somewhere in the middle
                startPage = currentPage - maxPagesBeforeCurrentPage;
                endPage = currentPage + maxPagesAfterCurrentPage;
            }
        }
        // calculate start and end item indexes
        let startIndex = (currentPage - 1) * pageSize;
        let endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);
        // create an array of pages to ng-repeat in the pager control
        let pages = Array.from(Array(endPage + 1 - startPage).keys()).map((i) => startPage + i);
        // return object with all pager properties required by the view
        return {
            totalItems: totalItems,
            currentPage: currentPage,
            pageSize: pageSize,
            totalPages: totalPages,
            startPage: startPage,
            endPage: endPage,
            startIndex: startIndex,
            endIndex: endIndex,
            pages: pages,
        };
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], PaginationComponent.prototype, "totalItems", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], PaginationComponent.prototype, "pageSize", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
], PaginationComponent.prototype, "onPageChange", void 0);
PaginationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "pagination-controller",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./pagination.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/pagination/pagination.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./pagination.component.css */ "./src/app/shared/widgets/pagination/pagination.component.css")).default]
    })
], PaginationComponent);



/***/ }),

/***/ "./src/app/shared/widgets/tooltip/tooltip.component.css":
/*!**************************************************************!*\
  !*** ./src/app/shared/widgets/tooltip/tooltip.component.css ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".tool-tip-icon {\r\n\tfont-size: 0.8rem;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3dpZGdldHMvdG9vbHRpcC90b29sdGlwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Q0FDQyxpQkFBaUI7QUFDbEIiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvd2lkZ2V0cy90b29sdGlwL3Rvb2x0aXAuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b29sLXRpcC1pY29uIHtcclxuXHRmb250LXNpemU6IDAuOHJlbTtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "./src/app/shared/widgets/tooltip/tooltip.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/shared/widgets/tooltip/tooltip.component.ts ***!
  \*************************************************************/
/*! exports provided: TooltipComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TooltipComponent", function() { return TooltipComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let TooltipComponent = class TooltipComponent {
    constructor() { }
    ngOnInit() {
        $(document).ready(function () {
            $('[data-toggle="tooltip"]').tooltip();
        });
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], TooltipComponent.prototype, "title", void 0);
TooltipComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-tooltip',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./tooltip.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/widgets/tooltip/tooltip.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./tooltip.component.css */ "./src/app/shared/widgets/tooltip/tooltip.component.css")).default]
    })
], TooltipComponent);



/***/ }),

/***/ "./src/app/shared/widgets/widgets.module.ts":
/*!**************************************************!*\
  !*** ./src/app/shared/widgets/widgets.module.ts ***!
  \**************************************************/
/*! exports provided: WidgetsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WidgetsModule", function() { return WidgetsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var ngx_image_cropper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-image-cropper */ "./node_modules/ngx-image-cropper/fesm2015/ngx-image-cropper.js");
/* harmony import */ var _image_cropper_image_cropper_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./image-cropper/image-cropper.component */ "./src/app/shared/widgets/image-cropper/image-cropper.component.ts");
/* harmony import */ var _avatar_upload_avatar_upload_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./avatar-upload/avatar-upload.component */ "./src/app/shared/widgets/avatar-upload/avatar-upload.component.ts");
/* harmony import */ var _gallery_upload_gallery_upload_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./gallery-upload/gallery-upload.component */ "./src/app/shared/widgets/gallery-upload/gallery-upload.component.ts");
/* harmony import */ var _pagination_pagination_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pagination/pagination.component */ "./src/app/shared/widgets/pagination/pagination.component.ts");
/* harmony import */ var _add_achievement_innovator_add_achievement_innovator_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./add-achievement-innovator/add-achievement-innovator.component */ "./src/app/shared/widgets/add-achievement-innovator/add-achievement-innovator.component.ts");
/* harmony import */ var _add_achievement_innovator_achievement_item_achievement_item_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./add-achievement-innovator/achievement-item/achievement-item.component */ "./src/app/shared/widgets/add-achievement-innovator/achievement-item/achievement-item.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _companylogo_upload_companylogo_upload_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./companylogo-upload/companylogo-upload.component */ "./src/app/shared/widgets/companylogo-upload/companylogo-upload.component.ts");
/* harmony import */ var _collapsable_content_collapsable_content_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./collapsable-content/collapsable-content.component */ "./src/app/shared/widgets/collapsable-content/collapsable-content.component.ts");
/* harmony import */ var _tooltip_tooltip_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./tooltip/tooltip.component */ "./src/app/shared/widgets/tooltip/tooltip.component.ts");
/* harmony import */ var _doc_upload_doc_upload_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./doc-upload/doc-upload.component */ "./src/app/shared/widgets/doc-upload/doc-upload.component.ts");
/* harmony import */ var _notifier_notifier_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./notifier/notifier.component */ "./src/app/shared/widgets/notifier/notifier.component.ts");
















let WidgetsModule = class WidgetsModule {
};
WidgetsModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [
            _image_cropper_image_cropper_component__WEBPACK_IMPORTED_MODULE_4__["ImageCropperComponent"],
            _avatar_upload_avatar_upload_component__WEBPACK_IMPORTED_MODULE_5__["AvatarUploadComponent"],
            _gallery_upload_gallery_upload_component__WEBPACK_IMPORTED_MODULE_6__["GalleryUploadComponent"],
            _pagination_pagination_component__WEBPACK_IMPORTED_MODULE_7__["PaginationComponent"],
            _add_achievement_innovator_add_achievement_innovator_component__WEBPACK_IMPORTED_MODULE_8__["AddAchievementInnovatorComponent"],
            _add_achievement_innovator_achievement_item_achievement_item_component__WEBPACK_IMPORTED_MODULE_9__["AchievementItemComponent"],
            _companylogo_upload_companylogo_upload_component__WEBPACK_IMPORTED_MODULE_11__["CompanylogoUploadComponent"],
            _collapsable_content_collapsable_content_component__WEBPACK_IMPORTED_MODULE_12__["CollapsableContentComponent"],
            _tooltip_tooltip_component__WEBPACK_IMPORTED_MODULE_13__["TooltipComponent"],
            _doc_upload_doc_upload_component__WEBPACK_IMPORTED_MODULE_14__["DocUploadComponent"],
            _notifier_notifier_component__WEBPACK_IMPORTED_MODULE_15__["NotifierComponent"],
        ],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], ngx_image_cropper__WEBPACK_IMPORTED_MODULE_3__["ImageCropperModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ReactiveFormsModule"]],
        exports: [
            _image_cropper_image_cropper_component__WEBPACK_IMPORTED_MODULE_4__["ImageCropperComponent"],
            _avatar_upload_avatar_upload_component__WEBPACK_IMPORTED_MODULE_5__["AvatarUploadComponent"],
            _gallery_upload_gallery_upload_component__WEBPACK_IMPORTED_MODULE_6__["GalleryUploadComponent"],
            _pagination_pagination_component__WEBPACK_IMPORTED_MODULE_7__["PaginationComponent"],
            _add_achievement_innovator_add_achievement_innovator_component__WEBPACK_IMPORTED_MODULE_8__["AddAchievementInnovatorComponent"],
            _companylogo_upload_companylogo_upload_component__WEBPACK_IMPORTED_MODULE_11__["CompanylogoUploadComponent"],
            _collapsable_content_collapsable_content_component__WEBPACK_IMPORTED_MODULE_12__["CollapsableContentComponent"],
            _tooltip_tooltip_component__WEBPACK_IMPORTED_MODULE_13__["TooltipComponent"],
            _doc_upload_doc_upload_component__WEBPACK_IMPORTED_MODULE_14__["DocUploadComponent"],
            _notifier_notifier_component__WEBPACK_IMPORTED_MODULE_15__["NotifierComponent"],
        ],
    })
], WidgetsModule);



/***/ }),

/***/ "./src/app/state/action/loggedinuser.action.ts":
/*!*****************************************************!*\
  !*** ./src/app/state/action/loggedinuser.action.ts ***!
  \*****************************************************/
/*! exports provided: SetLoggedInUser, UpdateLoggedInUser, ClearLoggedInUserSession, GetLoggedInUser */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SetLoggedInUser", function() { return SetLoggedInUser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdateLoggedInUser", function() { return UpdateLoggedInUser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ClearLoggedInUserSession", function() { return ClearLoggedInUserSession; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetLoggedInUser", function() { return GetLoggedInUser; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");

class SetLoggedInUser {
    constructor(payload) {
        this.payload = payload;
    }
}
SetLoggedInUser.type = "LoggedInUser Add";
class UpdateLoggedInUser {
    constructor(payload) {
        this.payload = payload;
    }
}
UpdateLoggedInUser.type = "LoggedInUser Update";
class ClearLoggedInUserSession {
}
ClearLoggedInUserSession.type = "LoggedInUser Delete";
class GetLoggedInUser {
}
GetLoggedInUser.type = "LoggedInUser Get";


/***/ }),

/***/ "./src/app/state/loggedinuser.state.ts":
/*!*********************************************!*\
  !*** ./src/app/state/loggedinuser.state.ts ***!
  \*********************************************/
/*! exports provided: LoggedInUserStateModel, LoggedInUserState */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoggedInUserStateModel", function() { return LoggedInUserStateModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoggedInUserState", function() { return LoggedInUserState; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngxs/store */ "./node_modules/@ngxs/store/fesm2015/ngxs-store.js");
/* harmony import */ var _action_loggedinuser_action__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./action/loggedinuser.action */ "./src/app/state/action/loggedinuser.action.ts");



class LoggedInUserStateModel {
}
let LoggedInUserState = class LoggedInUserState {
    static getLoggedInUserInfo(state) {
        return state.LoggedInUser;
    }
    setLoggedInUser({ setState }, { payload }) {
        setState({
            LoggedInUser: payload,
        });
    }
    updateUser({ setState }, { payload }) {
        setState({
            LoggedInUser: payload,
        });
    }
    logOutUserSession(context) {
        context.setState({
            LoggedInUser: {
                id: null,
                email: null,
                name: null,
                userType: null,
                userTypeId: null,
                avatar: null,
                slug: null,
                isLoggedIn: false,
            },
        });
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngxs_store__WEBPACK_IMPORTED_MODULE_1__["Action"])(_action_loggedinuser_action__WEBPACK_IMPORTED_MODULE_2__["SetLoggedInUser"])
], LoggedInUserState.prototype, "setLoggedInUser", null);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngxs_store__WEBPACK_IMPORTED_MODULE_1__["Action"])(_action_loggedinuser_action__WEBPACK_IMPORTED_MODULE_2__["UpdateLoggedInUser"])
], LoggedInUserState.prototype, "updateUser", null);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngxs_store__WEBPACK_IMPORTED_MODULE_1__["Action"])(_action_loggedinuser_action__WEBPACK_IMPORTED_MODULE_2__["ClearLoggedInUserSession"])
], LoggedInUserState.prototype, "logOutUserSession", null);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngxs_store__WEBPACK_IMPORTED_MODULE_1__["Selector"])()
], LoggedInUserState, "getLoggedInUserInfo", null);
LoggedInUserState = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_ngxs_store__WEBPACK_IMPORTED_MODULE_1__["State"])({
        name: "loggedinuser",
        defaults: {
            LoggedInUser: {
                id: null,
                email: null,
                name: null,
                userType: null,
                userTypeId: null,
                avatar: null,
                slug: null,
                isLoggedIn: false,
            },
        },
    })
], LoggedInUserState);



/***/ }),

/***/ "./src/app/token.interceptor.ts":
/*!**************************************!*\
  !*** ./src/app/token.interceptor.ts ***!
  \**************************************/
/*! exports provided: JwtInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JwtInterceptor", function() { return JwtInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./services/auth.service */ "./src/app/services/auth.service.ts");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm2015/ngx-toastr.js");







let JwtInterceptor = class JwtInterceptor {
    constructor(auth, toastr) {
        this.auth = auth;
        this.toastr = toastr;
        this.isRefreshing = false;
        this.refreshTokenSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"](null);
    }
    intercept(request, next) {
        const token = localStorage.getItem("access_token") || null;
        if (token) {
            request = request.clone({
                setHeaders: {
                    Authorization: `Bearer ${token}`,
                },
            });
        }
        return next.handle(request).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])((err) => {
            // prevent refresh token for these routes
            if (request.url.includes("login") || request.url.includes("refresh_token")) {
                if (request.url.includes("refresh_token")) {
                    this.toastr.warning("", "Session expired!");
                    this.auth.logout();
                    return;
                }
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
            }
            // throw other errors
            if (err instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpErrorResponse"] && err.status != 401) {
                return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(err);
            }
            // handle 401 errors
            if (!this.isRefreshing) {
                this.isRefreshing = true;
                this.refreshTokenSubject.next(null);
                return this.auth.refreshToken().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((token) => {
                    this.isRefreshing = false;
                    this.refreshTokenSubject.next(token.access_token);
                    return next.handle(this.addToken(request, token.access_token));
                }));
            }
            else {
                return this.refreshTokenSubject.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["filter"])((token) => token != null), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])((token) => {
                    return next.handle(this.addToken(request, token));
                }));
            }
        }));
    }
    addToken(request, token) {
        return request.clone({
            setHeaders: {
                Authorization: `Bearer ${token}`,
            },
        });
    }
};
JwtInterceptor.ctorParameters = () => [
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"] },
    { type: ngx_toastr__WEBPACK_IMPORTED_MODULE_6__["ToastrService"] }
];
JwtInterceptor = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
], JwtInterceptor);



/***/ }),

/***/ "./src/app/users/forgot-password/forgot-password.component.css":
/*!*********************************************************************!*\
  !*** ./src/app/users/forgot-password/forgot-password.component.css ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".forgot-password-parent{\r\n    min-height:100vh;\r\n}\r\n\r\n.forgot-password-step-form-wrp{\r\n    max-width:570px;\r\n    margin:auto;\r\n}\r\n\r\n.step-card-wrp{\r\n    background-color:var(--white);\r\n    padding:56px;\r\n    border-radius:10px;\r\n    box-shadow: 5px 5px 20px rgba(157, 189, 252, 0.5);\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlcnMvZm9yZ290LXBhc3N3b3JkL2ZvcmdvdC1wYXNzd29yZC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZ0JBQWdCO0FBQ3BCOztBQUVBO0lBQ0ksZUFBZTtJQUNmLFdBQVc7QUFDZjs7QUFFQTtJQUNJLDZCQUE2QjtJQUM3QixZQUFZO0lBQ1osa0JBQWtCO0lBQ2xCLGlEQUFpRDtBQUNyRCIsImZpbGUiOiJzcmMvYXBwL3VzZXJzL2ZvcmdvdC1wYXNzd29yZC9mb3Jnb3QtcGFzc3dvcmQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5mb3Jnb3QtcGFzc3dvcmQtcGFyZW50e1xyXG4gICAgbWluLWhlaWdodDoxMDB2aDtcclxufVxyXG5cclxuLmZvcmdvdC1wYXNzd29yZC1zdGVwLWZvcm0td3Jwe1xyXG4gICAgbWF4LXdpZHRoOjU3MHB4O1xyXG4gICAgbWFyZ2luOmF1dG87XHJcbn1cclxuXHJcbi5zdGVwLWNhcmQtd3Jwe1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjp2YXIoLS13aGl0ZSk7XHJcbiAgICBwYWRkaW5nOjU2cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOjEwcHg7XHJcbiAgICBib3gtc2hhZG93OiA1cHggNXB4IDIwcHggcmdiYSgxNTcsIDE4OSwgMjUyLCAwLjUpO1xyXG59Il19 */");

/***/ }),

/***/ "./src/app/users/forgot-password/forgot-password.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/users/forgot-password/forgot-password.component.ts ***!
  \********************************************************************/
/*! exports provided: ForgotPasswordComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPasswordComponent", function() { return ForgotPasswordComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm2015/ngx-toastr.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _services_customvalidation_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/customvalidation.service */ "./src/app/services/customvalidation.service.ts");
/* harmony import */ var _reset_password_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./reset-password.service */ "./src/app/users/forgot-password/reset-password.service.ts");







let ForgotPasswordComponent = class ForgotPasswordComponent {
    constructor(toastr, router, fb, customValidator, _reset) {
        this.toastr = toastr;
        this.router = router;
        this.fb = fb;
        this.customValidator = customValidator;
        this._reset = _reset;
        this.ForgotPassword = {
            Step1: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"],
            Step2: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"],
            Step3: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormGroup"],
        };
        this.isSubmitted = {
            Step1: false,
            Step2: false,
            Step3: false,
        };
        this.step1Loading = false;
        this.step2Loading = false;
        this.step3Loading = false;
        this.resendCodeLoading = false;
    }
    ngOnInit() {
        this.forgotPasswordStep1 = false;
        this.forgotPasswordStep2 = true;
        this.forgotPasswordStep3 = true;
        this.ForgotPassword = {
            Step1: this.fb.group({
                email: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].email], this.customValidator.checkRegisteredEmail.bind(this.customValidator)],
            }),
            Step2: this.fb.group({
                verificationCode: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]],
            }),
            Step3: this.fb.group({
                password: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].pattern("^(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")]],
                confirmPassword: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]],
            }, { validator: this.customValidator.MatchPassword("password", "confirmPassword") }),
        };
    }
    get formControlStep1() {
        return this.ForgotPassword.Step1.controls;
    }
    get formControlStep2() {
        return this.ForgotPassword.Step2.controls;
    }
    get formControlStep3() {
        return this.ForgotPassword.Step3.controls;
    }
    gotoStep(step) {
        switch (step) {
            case "step1": {
                this.forgotPasswordStep1 = false;
                this.forgotPasswordStep2 = true;
                this.forgotPasswordStep3 = true;
                break;
            }
            case "step2": {
                this.forgotPasswordStep1 = true;
                this.forgotPasswordStep2 = false;
                this.forgotPasswordStep3 = true;
                break;
            }
            case "step3": {
                this.forgotPasswordStep1 = true;
                this.forgotPasswordStep2 = true;
                this.forgotPasswordStep3 = false;
                break;
            }
        }
    }
    ShowNextStep(step) {
        if (step == "step2") {
            this.forgotPasswordStep1 = true;
            this.forgotPasswordStep2 = false;
            this.forgotPasswordStep3 = true;
        }
        else if (step == "step3") {
            this.forgotPasswordStep1 = true;
            this.forgotPasswordStep2 = true;
            this.forgotPasswordStep3 = false;
        }
    }
    goBack(step) {
        if (step == "step1") {
            this.forgotPasswordStep1 = false;
            this.forgotPasswordStep2 = true;
            this.forgotPasswordStep3 = true;
        }
    }
    sendCode(form) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isSubmitted.Step1 = true;
            if (this.ForgotPassword.Step1.valid) {
                this.step1Loading = true;
                try {
                    let resp = yield this._reset.sendVerificationCode({
                        data: {
                            email: this.ForgotPassword.Step1.value.email,
                        },
                    });
                    this.step1Loading = false;
                    if (resp.status == true) {
                        this.toastr.info("", resp.msg);
                        this.ShowNextStep("step2");
                    }
                    else {
                        this.toastr.error("", resp.msg);
                    }
                }
                catch (err) {
                    this.step1Loading = false;
                    this.toastr.error("", "Something went wrong please try again");
                }
            }
            else {
                this.toastr.error("", "Please provide the registered email to proceed further");
            }
        });
    }
    verifyCode(form) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isSubmitted.Step2 = true;
            if (this.ForgotPassword.Step2.valid) {
                this.step2Loading = true;
                try {
                    let resp = yield this._reset.verifyResetCode({
                        data: {
                            email: this.ForgotPassword.Step1.value.email,
                            verification_code: this.ForgotPassword.Step2.value.verificationCode,
                        },
                    });
                    this.step2Loading = false;
                    if (resp.status == true) {
                        this.toastr.info("", resp.msg);
                        this.ShowNextStep("step3");
                    }
                    else {
                        this.toastr.error("", resp.msg);
                    }
                }
                catch (err) {
                    this.step2Loading = false;
                    this.toastr.error("", "Something went wrong please try again");
                }
            }
            else {
                this.toastr.error("", "Please provide the verfication code to proceed further");
            }
        });
    }
    resetPassword(form) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isSubmitted.Step3 = true;
            if (this.ForgotPassword.Step3.valid) {
                this.step3Loading = true;
                try {
                    let resp = yield this._reset.resetPassword({
                        data: {
                            email: this.ForgotPassword.Step1.value.email,
                            verification_code: this.ForgotPassword.Step2.value.verificationCode,
                            new_password: this.ForgotPassword.Step3.value.password,
                        },
                    });
                    this.step3Loading = false;
                    if (resp.status == true) {
                        this.toastr.success("", resp.msg);
                        this.router.navigate(["/login"]);
                    }
                    else {
                        this.toastr.error("", resp.msg);
                    }
                }
                catch (err) {
                    this.step3Loading = false;
                    this.toastr.error("", "Something went wrong please try again");
                }
            }
            else {
                this.toastr.error("", "Please provide the required values to proceed further");
            }
        });
    }
    resendCode() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                this.resendCodeLoading = true;
                let resp = yield this._reset.sendVerificationCode({
                    data: {
                        email: this.ForgotPassword.Step1.value.email,
                    },
                });
                this.resendCodeLoading = false;
                if (resp.status == true) {
                    this.toastr.info("", resp.msg);
                }
                else {
                    this.toastr.error("", resp.msg);
                }
            }
            catch (err) {
                this.resendCodeLoading = false;
                this.toastr.error("", "Something went wrong please try again");
            }
        });
    }
    onSubmit(formIndex) {
        switch (formIndex) {
            case "Step1": {
                this.isSubmitted.Step1 = true;
                break;
            }
            case "Step2": {
                this.isSubmitted.Step2 = true;
                break;
            }
            case "Step3": {
                this.isSubmitted.Step3 = true;
                break;
            }
        }
    }
};
ForgotPasswordComponent.ctorParameters = () => [
    { type: ngx_toastr__WEBPACK_IMPORTED_MODULE_3__["ToastrService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _services_customvalidation_service__WEBPACK_IMPORTED_MODULE_5__["CustomvalidationService"] },
    { type: _reset_password_service__WEBPACK_IMPORTED_MODULE_6__["ResetPasswordService"] }
];
ForgotPasswordComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-forgot-password",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./forgot-password.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/users/forgot-password/forgot-password.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./forgot-password.component.css */ "./src/app/users/forgot-password/forgot-password.component.css")).default]
    })
], ForgotPasswordComponent);



/***/ }),

/***/ "./src/app/users/forgot-password/reset-password.service.ts":
/*!*****************************************************************!*\
  !*** ./src/app/users/forgot-password/reset-password.service.ts ***!
  \*****************************************************************/
/*! exports provided: ResetPasswordService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResetPasswordService", function() { return ResetPasswordService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");




let ResetPasswordService = class ResetPasswordService {
    constructor(http) {
        this.http = http;
        this.api_url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].api_url;
    }
    sendVerificationCode(postData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            return yield this.http.post(this.api_url + '/users/send_verification_code_password', postData).toPromise();
        });
    }
    verifyResetCode(postData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            return yield this.http.post(this.api_url + '/users/verify_password_reset_code', postData).toPromise();
        });
    }
    resetPassword(postData) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            return yield this.http.post(this.api_url + '/users/reset_password', postData).toPromise();
        });
    }
};
ResetPasswordService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
ResetPasswordService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ResetPasswordService);



/***/ }),

/***/ "./src/app/users/login/login.component.css":
/*!*************************************************!*\
  !*** ./src/app/users/login/login.component.css ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\r\n.l-login-card{\r\n    max-width:460px;\r\n}\r\n.menu-item{\r\n    display: none !important;\r\n}\r\n.left-bg-lyr{\r\n    background-image: url('login_image.jpg');\r\n    background-position: -5% top;\r\n    background-size: 46%;\r\n    background-repeat: no-repeat;\r\n}\r\n@media only screen and (max-width: 1480px){\r\n    .left-bg-lyr{\r\n        background-size: 50%;\r\n    }\r\n}\r\n@media only screen and (max-width: 991px){\r\n    .left-bg-lyr{\r\n        background-image: unset !important;\r\n    }\r\n    .l-login-card{\r\n        margin-left: auto !important;\r\n        margin-right: auto !important;\r\n    }\r\n}\r\n.right-bg-lyr{\r\n    background-image: url('login_patten_bg.png');\r\n    background-size: 15%;\r\n    background-position: right center;\r\n    background-repeat: no-repeat;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlcnMvbG9naW4vbG9naW4uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQ0E7SUFDSSxlQUFlO0FBQ25CO0FBQ0E7SUFDSSx3QkFBd0I7QUFDNUI7QUFFQTtJQUNJLHdDQUE0RDtJQUM1RCw0QkFBNEI7SUFDNUIsb0JBQW9CO0lBQ3BCLDRCQUE0QjtBQUNoQztBQUVBO0lBQ0k7UUFDSSxvQkFBb0I7SUFDeEI7QUFDSjtBQUNBO0lBQ0k7UUFDSSxrQ0FBa0M7SUFDdEM7SUFDQTtRQUNJLDRCQUE0QjtRQUM1Qiw2QkFBNkI7SUFDakM7QUFDSjtBQUVBO0lBQ0ksNENBQWdFO0lBQ2hFLG9CQUFvQjtJQUNwQixpQ0FBaUM7SUFDakMsNEJBQTRCO0FBQ2hDIiwiZmlsZSI6InNyYy9hcHAvdXNlcnMvbG9naW4vbG9naW4uY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4ubC1sb2dpbi1jYXJke1xyXG4gICAgbWF4LXdpZHRoOjQ2MHB4O1xyXG59XHJcbi5tZW51LWl0ZW17XHJcbiAgICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5sZWZ0LWJnLWx5cntcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnLi4vLi4vLi4vYXNzZXRzL2ltZy9sb2dpbl9pbWFnZS5qcGcnKTtcclxuICAgIGJhY2tncm91bmQtcG9zaXRpb246IC01JSB0b3A7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IDQ2JTtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbn1cclxuXHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogMTQ4MHB4KXtcclxuICAgIC5sZWZ0LWJnLWx5cntcclxuICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IDUwJTtcclxuICAgIH1cclxufVxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDk5MXB4KXtcclxuICAgIC5sZWZ0LWJnLWx5cntcclxuICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiB1bnNldCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgLmwtbG9naW4tY2FyZHtcclxuICAgICAgICBtYXJnaW4tbGVmdDogYXV0byAhaW1wb3J0YW50O1xyXG4gICAgICAgIG1hcmdpbi1yaWdodDogYXV0byAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG59XHJcblxyXG4ucmlnaHQtYmctbHlye1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi8uLi9hc3NldHMvaW1nL2xvZ2luX3BhdHRlbl9iZy5wbmcnKTtcclxuICAgIGJhY2tncm91bmQtc2l6ZTogMTUlO1xyXG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogcmlnaHQgY2VudGVyO1xyXG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxufSJdfQ== */");

/***/ }),

/***/ "./src/app/users/login/login.component.ts":
/*!************************************************!*\
  !*** ./src/app/users/login/login.component.ts ***!
  \************************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm2015/ngx-toastr.js");
/* harmony import */ var _login_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.service */ "./src/app/users/login/login.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngxs/store */ "./node_modules/@ngxs/store/fesm2015/ngxs-store.js");
/* harmony import */ var _state_action_loggedinuser_action__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../state/action/loggedinuser.action */ "./src/app/state/action/loggedinuser.action.ts");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../services/auth.service */ "./src/app/services/auth.service.ts");











let LoginComponent = class LoginComponent {
    constructor(_ls, router, toastr, fb, _renderer2, activatedRoute, _document, store, auth) {
        this._ls = _ls;
        this.router = router;
        this.toastr = toastr;
        this.fb = fb;
        this._renderer2 = _renderer2;
        this.activatedRoute = activatedRoute;
        this._document = _document;
        this.store = store;
        this.auth = auth;
        this.server_url = _environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].server_url;
        this.login_frm = {};
        this.isSubmitted = false;
        this.isLoading = false;
        this.urlParams = null;
        this.activatedRoute.queryParams.subscribe((params) => {
            this.urlParams = params;
        });
        this.loginForm = this.fb.group({
            email: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].email]],
            password: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]],
        });
    }
    ngOnInit() {
        // loading startup india auth script
        const authScript = this._renderer2.createElement("script");
        authScript.type = `text/javascript`;
        authScript.src = "https://www.startupindia.gov.in/etc/designs/invest-india/investindialibs/js/siauthlogin.js";
        authScript.innerHTML = "console.log('auth script loaded')";
        this._renderer2.appendChild(this._document.body, authScript);
    }
    get loginFormControl() {
        return this.loginForm.controls;
    }
    logIn(form) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            try {
                this.isSubmitted = true;
                if (this.loginForm.valid) {
                    this.isLoading = true;
                    let response = yield this.auth.login({
                        email: this.loginForm.value.email,
                        password: this.loginForm.value.password,
                    });
                    this.isLoading = false;
                    if (response.status == true) {
                        if (response.data.role_seeker) {
                            // setting the loggedin user state(seeker)
                            this.store.dispatch(new _state_action_loggedinuser_action__WEBPACK_IMPORTED_MODULE_9__["SetLoggedInUser"]({
                                id: response.data.id,
                                email: response.data.email,
                                name: response.data.seeker[0].fullname,
                                userType: "seeker",
                                userTypeId: response.data.seeker[0].id,
                                avatar: `${this.server_url}` + response.data.seeker[0].avatar,
                                slug: response.data.seeker[0].slug,
                                isLoggedIn: true,
                            }));
                            this.loginSuccess(form, "seeker", response);
                        }
                        else if (response.data.role_provider) {
                            // setting the loggedin user state(innovator)
                            this.store.dispatch(new _state_action_loggedinuser_action__WEBPACK_IMPORTED_MODULE_9__["SetLoggedInUser"]({
                                id: response.data.id,
                                email: response.data.email,
                                name: response.data.provider[0].fullname,
                                userType: "provider",
                                userTypeId: response.data.provider[0].id,
                                avatar: `${this.server_url}` + response.data.provider[0].avatar,
                                slug: response.data.provider[0].slug,
                                isLoggedIn: true,
                            }));
                            this.loginSuccess(form, "provider", response);
                        }
                        else if (response.data.role_cwg) {
                            // localStorage.setItem('user_type', 'cwg')
                        }
                    }
                    else {
                        if (response.status == false && response.msg == "Invalid Email") {
                            this.loginForm.controls["email"].setErrors({ incorrect: true });
                        }
                        else if (response.status == false && response.msg == "Invalid Password") {
                            this.loginForm.controls["password"].setErrors({ incorrect: true });
                        }
                        else if (response.status == false && response.msg == "Account not activated") {
                            this.isSubmitted = false;
                            form.resetForm();
                            this.toastr.warning("", "Account not activated yet");
                        }
                        else if (response.status == false && response.msg == "Approval pending") {
                            this.isSubmitted = false;
                            form.resetForm();
                            this.toastr.warning("Your account is being reviewed by the Admin and is pending approval. You will receive an email once it is approved.", "Pending for Approval");
                        }
                    }
                }
                else {
                    this.toastr.error("", "Please provide the required fields to login");
                }
            }
            catch (err) {
                console.log(err);
                this.isLoading = false;
                this.toastr.error("", "Something went wrong please try again");
            }
        });
    }
    loginSuccess(loginForm, userType, loginResponse) {
        this.isSubmitted = false;
        loginForm.resetForm();
        this.toastr.success("", "Login successful");
        var post_data = {};
        if (this.urlParams.redirectURL) {
            this.router.navigate([this.urlParams.redirectURL]);
        }
        else {
            switch (userType) {
                case "seeker": {
                    post_data = {
                        filter: {
                            frg_seeker_id: loginResponse.data.seeker[0].id,
                        },
                    };
                    this._ls.getSelectedSectorListAPI("seeker", post_data).subscribe((response) => {
                        if (response.status == true && response.data.length) {
                            this.router.navigate(["/discover/providers"]);
                        }
                        else {
                            this.router.navigate(["/discover/select-sector"]);
                        }
                    });
                    break;
                }
                case "provider": {
                    post_data = {
                        filter: {
                            frg_provider_id: loginResponse.data.provider[0].id,
                        },
                    };
                    this._ls.getSelectedSectorListAPI("provider", post_data).subscribe((response) => {
                        if (response.status == true && response.data.length) {
                            this.router.navigate(["/discover/challenges"]);
                        }
                        else {
                            this.router.navigate(["/discover/select-sector"]);
                        }
                    });
                    break;
                }
                default: {
                    // this.router.navigate(['/discover/challenges']);
                    break;
                }
            }
        }
    }
    togglePassword() {
        this.passwordField = !this.passwordField;
    }
};
LoginComponent.ctorParameters = () => [
    { type: _login_service__WEBPACK_IMPORTED_MODULE_6__["LoginService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: ngx_toastr__WEBPACK_IMPORTED_MODULE_5__["ToastrService"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: Document, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["DOCUMENT"],] }] },
    { type: _ngxs_store__WEBPACK_IMPORTED_MODULE_8__["Store"] },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_10__["AuthService"] }
];
LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: "app-login",
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./login.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/users/login/login.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./login.component.css */ "./src/app/users/login/login.component.css")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](6, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_2__["DOCUMENT"]))
], LoginComponent);



/***/ }),

/***/ "./src/app/users/login/login.service.ts":
/*!**********************************************!*\
  !*** ./src/app/users/login/login.service.ts ***!
  \**********************************************/
/*! exports provided: LoginService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginService", function() { return LoginService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_4__);





let LoginService = class LoginService {
    constructor(http) {
        this.http = http;
        this.api_url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].api_url;
    }
    loginApi(data) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            let post_data = { data };
            return yield this.http.post(this.api_url + "/users/login", post_data).toPromise();
        });
    }
    getSelectedSectorListAPI(type, data) {
        if (type == "seeker") {
            return this.http.post(this.api_url + "/challenge_sectors_seekers/select_mul", data);
        }
        else if (type == "provider") {
            return this.http.post(this.api_url + "/challenge_sectors_and_providers/select_mul", data);
        }
    }
    getUserSelectedSectors(type, data) {
        var tmp_arr = [];
        return new Promise((resolve, reject) => {
            if (type == "seeker") {
                this.http.post(this.api_url + "/challenge_sectors_seekers/select_mul", data).subscribe((response) => {
                    if (response.data.length) {
                        lodash__WEBPACK_IMPORTED_MODULE_4__["each"](response.data, (itm, idx) => {
                            tmp_arr.push(itm.frg_challenge_sector_id);
                            if (response.data.length == idx + 1) {
                                resolve(tmp_arr);
                            }
                        });
                    }
                    else {
                        resolve(tmp_arr);
                    }
                });
            }
            else if (type == "provider") {
                this.http.post(this.api_url + "/challenge_sectors_and_providers/select_mul", data).subscribe((response) => {
                    if (response.data.length) {
                        lodash__WEBPACK_IMPORTED_MODULE_4__["each"](response.data, (itm, idx) => {
                            tmp_arr.push(itm.frg_challenge_sector_id);
                            if (response.data.length == idx + 1) {
                                resolve(tmp_arr);
                            }
                        });
                    }
                    else {
                        resolve(tmp_arr);
                    }
                });
            }
        });
    }
};
LoginService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
LoginService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: "root",
    })
], LoginService);



/***/ }),

/***/ "./src/app/users/select-challenge-sector/select-challenge-sector.component.css":
/*!*************************************************************************************!*\
  !*** ./src/app/users/select-challenge-sector/select-challenge-sector.component.css ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".select-challenge-sector-wrp{\r\n    min-height:100vh;\r\n}\r\n\r\n.challenge-sector-row{\r\n    max-width:1000px;\r\n    margin:auto;\r\n    display:-webkit-box;\r\n    display:flex;\r\n    -webkit-box-pack: justify;\r\n            justify-content: space-between;\r\n    flex-wrap: wrap;\r\n}\r\n\r\n.challenge-sector-card{\r\n    flex-basis:19%;\r\n}\r\n\r\n.challenge-sector-checkbox{\r\n    display:block;\r\n    margin-bottom:18px;\r\n}\r\n\r\n.challenge-sector-checkbox .challenge-sector{\r\n    display:block;\r\n    padding:30px 12px 18px 12px;\r\n    background-color:var(--white);\r\n    border: 1px solid #CDCDCD;\r\n    border-radius: 10px;\r\n}\r\n\r\n.challenge-sector-checkbox .challenge-sector,\r\n.challenge-sector-checkbox .challenge-sector *{\r\n    -webkit-transition:all 0.2s ease;\r\n    transition:all 0.2s ease;\r\n}\r\n\r\n.challenge-sector-checkbox .challenge-sector svg{\r\n    width:80px;\r\n    height:80px;\r\n}\r\n\r\n/* checkbox */\r\n\r\n.a-checkbox[type=\"checkbox\"] {\r\n    position: absolute;\r\n    opacity: 0;\r\n    width: 0;\r\n    height: 0;\r\n  }\r\n\r\n/* IMAGE STYLES */\r\n\r\n.a-checkbox[type=\"checkbox\"] + .challenge-sector {\r\n    cursor: pointer;\r\n\r\n  }\r\n\r\n/* CHECKED STYLES */\r\n\r\n.a-checkbox[type=\"checkbox\"]:checked + .challenge-sector,\r\n  .a-checkbox[type=\"checkbox\"]:hover + .challenge-sector {\r\n    background-color:#3B6FD4 !important;\r\n    border-color: #3B6FD4 !important;\r\n    -webkit-filter: drop-shadow(5px 5px 10px rgba(43, 100, 210, 0.2)) !important;\r\n            filter: drop-shadow(5px 5px 10px rgba(43, 100, 210, 0.2)) !important;\r\n  }\r\n\r\n.a-checkbox[type=\"checkbox\"]:checked + .challenge-sector svg path,\r\n  .a-checkbox[type=\"checkbox\"]:hover + .challenge-sector svg path {\r\n    fill: var(--white) !important;\r\n  }\r\n\r\n.a-checkbox[type=\"checkbox\"]:checked + .challenge-sector .a-cnt,\r\n  .a-checkbox[type=\"checkbox\"]:hover + .challenge-sector .a-cnt {\r\n    color: var(--white) !important;\r\n  }\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlcnMvc2VsZWN0LWNoYWxsZW5nZS1zZWN0b3Ivc2VsZWN0LWNoYWxsZW5nZS1zZWN0b3IuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLGdCQUFnQjtJQUNoQixXQUFXO0lBQ1gsbUJBQVk7SUFBWixZQUFZO0lBQ1oseUJBQThCO1lBQTlCLDhCQUE4QjtJQUM5QixlQUFlO0FBQ25COztBQUVBO0lBQ0ksY0FBYztBQUNsQjs7QUFFQTtJQUNJLGFBQWE7SUFDYixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxhQUFhO0lBQ2IsMkJBQTJCO0lBQzNCLDZCQUE2QjtJQUM3Qix5QkFBeUI7SUFDekIsbUJBQW1CO0FBQ3ZCOztBQUVBOztJQUVJLGdDQUF3QjtJQUF4Qix3QkFBd0I7QUFDNUI7O0FBRUE7SUFDSSxVQUFVO0lBQ1YsV0FBVztBQUNmOztBQUVBLGFBQWE7O0FBQ2I7SUFDSSxrQkFBa0I7SUFDbEIsVUFBVTtJQUNWLFFBQVE7SUFDUixTQUFTO0VBQ1g7O0FBRUEsaUJBQWlCOztBQUNqQjtJQUNFLGVBQWU7O0VBRWpCOztBQUVBLG1CQUFtQjs7QUFDbkI7O0lBRUUsbUNBQW1DO0lBQ25DLGdDQUFnQztJQUNoQyw0RUFBb0U7WUFBcEUsb0VBQW9FO0VBQ3RFOztBQUNBOztJQUVFLDZCQUE2QjtFQUMvQjs7QUFDQTs7SUFFRSw4QkFBOEI7RUFDaEMiLCJmaWxlIjoic3JjL2FwcC91c2Vycy9zZWxlY3QtY2hhbGxlbmdlLXNlY3Rvci9zZWxlY3QtY2hhbGxlbmdlLXNlY3Rvci5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNlbGVjdC1jaGFsbGVuZ2Utc2VjdG9yLXdycHtcclxuICAgIG1pbi1oZWlnaHQ6MTAwdmg7XHJcbn1cclxuXHJcbi5jaGFsbGVuZ2Utc2VjdG9yLXJvd3tcclxuICAgIG1heC13aWR0aDoxMDAwcHg7XHJcbiAgICBtYXJnaW46YXV0bztcclxuICAgIGRpc3BsYXk6ZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgIGZsZXgtd3JhcDogd3JhcDtcclxufVxyXG5cclxuLmNoYWxsZW5nZS1zZWN0b3ItY2FyZHtcclxuICAgIGZsZXgtYmFzaXM6MTklO1xyXG59XHJcblxyXG4uY2hhbGxlbmdlLXNlY3Rvci1jaGVja2JveHtcclxuICAgIGRpc3BsYXk6YmxvY2s7XHJcbiAgICBtYXJnaW4tYm90dG9tOjE4cHg7XHJcbn1cclxuXHJcbi5jaGFsbGVuZ2Utc2VjdG9yLWNoZWNrYm94IC5jaGFsbGVuZ2Utc2VjdG9ye1xyXG4gICAgZGlzcGxheTpibG9jaztcclxuICAgIHBhZGRpbmc6MzBweCAxMnB4IDE4cHggMTJweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6dmFyKC0td2hpdGUpO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI0NEQ0RDRDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbn1cclxuXHJcbi5jaGFsbGVuZ2Utc2VjdG9yLWNoZWNrYm94IC5jaGFsbGVuZ2Utc2VjdG9yLFxyXG4uY2hhbGxlbmdlLXNlY3Rvci1jaGVja2JveCAuY2hhbGxlbmdlLXNlY3RvciAqe1xyXG4gICAgdHJhbnNpdGlvbjphbGwgMC4ycyBlYXNlO1xyXG59XHJcblxyXG4uY2hhbGxlbmdlLXNlY3Rvci1jaGVja2JveCAuY2hhbGxlbmdlLXNlY3RvciBzdmd7XHJcbiAgICB3aWR0aDo4MHB4O1xyXG4gICAgaGVpZ2h0OjgwcHg7XHJcbn1cclxuXHJcbi8qIGNoZWNrYm94ICovXHJcbi5hLWNoZWNrYm94W3R5cGU9XCJjaGVja2JveFwiXSB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBvcGFjaXR5OiAwO1xyXG4gICAgd2lkdGg6IDA7XHJcbiAgICBoZWlnaHQ6IDA7XHJcbiAgfVxyXG4gIFxyXG4gIC8qIElNQUdFIFNUWUxFUyAqL1xyXG4gIC5hLWNoZWNrYm94W3R5cGU9XCJjaGVja2JveFwiXSArIC5jaGFsbGVuZ2Utc2VjdG9yIHtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuXHJcbiAgfVxyXG4gIFxyXG4gIC8qIENIRUNLRUQgU1RZTEVTICovXHJcbiAgLmEtY2hlY2tib3hbdHlwZT1cImNoZWNrYm94XCJdOmNoZWNrZWQgKyAuY2hhbGxlbmdlLXNlY3RvcixcclxuICAuYS1jaGVja2JveFt0eXBlPVwiY2hlY2tib3hcIl06aG92ZXIgKyAuY2hhbGxlbmdlLXNlY3RvciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiMzQjZGRDQgIWltcG9ydGFudDtcclxuICAgIGJvcmRlci1jb2xvcjogIzNCNkZENCAhaW1wb3J0YW50O1xyXG4gICAgZmlsdGVyOiBkcm9wLXNoYWRvdyg1cHggNXB4IDEwcHggcmdiYSg0MywgMTAwLCAyMTAsIDAuMikpICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIC5hLWNoZWNrYm94W3R5cGU9XCJjaGVja2JveFwiXTpjaGVja2VkICsgLmNoYWxsZW5nZS1zZWN0b3Igc3ZnIHBhdGgsXHJcbiAgLmEtY2hlY2tib3hbdHlwZT1cImNoZWNrYm94XCJdOmhvdmVyICsgLmNoYWxsZW5nZS1zZWN0b3Igc3ZnIHBhdGgge1xyXG4gICAgZmlsbDogdmFyKC0td2hpdGUpICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIC5hLWNoZWNrYm94W3R5cGU9XCJjaGVja2JveFwiXTpjaGVja2VkICsgLmNoYWxsZW5nZS1zZWN0b3IgLmEtY250LFxyXG4gIC5hLWNoZWNrYm94W3R5cGU9XCJjaGVja2JveFwiXTpob3ZlciArIC5jaGFsbGVuZ2Utc2VjdG9yIC5hLWNudCB7XHJcbiAgICBjb2xvcjogdmFyKC0td2hpdGUpICFpbXBvcnRhbnQ7XHJcbiAgfSJdfQ== */");

/***/ }),

/***/ "./src/app/users/select-challenge-sector/select-challenge-sector.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/users/select-challenge-sector/select-challenge-sector.component.ts ***!
  \************************************************************************************/
/*! exports provided: SelectChallengeSectorComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectChallengeSectorComponent", function() { return SelectChallengeSectorComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let SelectChallengeSectorComponent = class SelectChallengeSectorComponent {
    constructor() { }
    ngOnInit() {
    }
};
SelectChallengeSectorComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-select-challenge-sector',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./select-challenge-sector.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/users/select-challenge-sector/select-challenge-sector.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./select-challenge-sector.component.css */ "./src/app/users/select-challenge-sector/select-challenge-sector.component.css")).default]
    })
], SelectChallengeSectorComponent);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

const environment = {
    production: false,
    api_url: "https://apicityinx.niua.org/api/v1",
    server_url: "https://apicityinx.niua.org",
    firebase: {
        apiKey: "AIzaSyASEvyrTLYGC2eh29R5s7gHWFYr_-CN1yE",
        authDomain: "cityinx-forge.firebaseapp.com",
        projectId: "cityinx-forge",
        storageBucket: "cityinx-forge.appspot.com",
        messagingSenderId: "943041979938",
        appId: "1:943041979938:web:1d94b7317f0cab37270c7b",
    }
};
// staging
// export const environment = {
// 	production: false,
// 	api_url: "http://localhost:1337/api/v1",
// 	server_url: "http://localhost:1337",
// 	firebase: {
// 		apiKey: "AIzaSyA6YmjtvaOWvE3FERZgylFbnCmEOkFUoiI",
// 		authDomain: "cityinx-stage.firebaseapp.com",
// 		projectId: "cityinx-stage",
// 		storageBucket: "cityinx-stage.appspot.com",
// 		messagingSenderId: "267900392266",
// 		appId: "1:267900392266:web:4de9d3fd1a00bb933927b3"
// 	},
// };
// production
// export const environment = {
// 	production: false,
// 	api_url: "https://apicityinx.niua.org/api/v1",
// 	server_url: "https://apicityinx.niua.org",
// 	firebase:{
// 		apiKey: "AIzaSyASEvyrTLYGC2eh29R5s7gHWFYr_-CN1yE",
// 		authDomain: "cityinx-forge.firebaseapp.com",
// 		projectId: "cityinx-forge",
// 		storageBucket: "cityinx-forge.appspot.com",
// 		messagingSenderId: "943041979938",
// 		appId: "1:943041979938:web:1d94b7317f0cab37270c7b",
// 	}
// };
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\xampp\htdocs\forge_frontend\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map